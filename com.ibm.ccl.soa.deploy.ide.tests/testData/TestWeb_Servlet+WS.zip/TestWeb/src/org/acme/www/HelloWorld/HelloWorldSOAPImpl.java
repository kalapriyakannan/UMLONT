/**
 * HelloWorldSOAPImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package org.acme.www.HelloWorld;

public class HelloWorldSOAPImpl implements org.acme.www.HelloWorld.HelloWorld_PortType{
    public java.lang.String sayHello(java.lang.String in) throws java.rmi.RemoteException {
        return "Hello, " + in + "!";
    }

}

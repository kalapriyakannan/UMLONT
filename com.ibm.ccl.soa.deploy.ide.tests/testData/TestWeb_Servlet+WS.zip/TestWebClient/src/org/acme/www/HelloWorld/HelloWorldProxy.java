package org.acme.www.HelloWorld;

public class HelloWorldProxy implements org.acme.www.HelloWorld.HelloWorld_PortType {
  private String _endpoint = null;
  private org.acme.www.HelloWorld.HelloWorld_PortType helloWorld_PortType = null;
  
  public HelloWorldProxy() {
    _initHelloWorldProxy();
  }
  
  private void _initHelloWorldProxy() {
    try {
      helloWorld_PortType = (new org.acme.www.HelloWorld.HelloWorld_ServiceLocator()).getHelloWorldSOAP();
      if (helloWorld_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)helloWorld_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)helloWorld_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (helloWorld_PortType != null)
      ((javax.xml.rpc.Stub)helloWorld_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public org.acme.www.HelloWorld.HelloWorld_PortType getHelloWorld_PortType() {
    if (helloWorld_PortType == null)
      _initHelloWorldProxy();
    return helloWorld_PortType;
  }
  
  public java.lang.String sayHello(java.lang.String in) throws java.rmi.RemoteException{
    if (helloWorld_PortType == null)
      _initHelloWorldProxy();
    return helloWorld_PortType.sayHello(in);
  }
  
  
}
#!/bin/bash

testInput=TestStringForMQVerification

# Create and start a sample queue manager.
crtmqm -q msapTestQMgr
strmqm

# Create a queue on the queue manager.
echo "define qlocal (orange.queue)" | runmqsc

# Run the write-back sample.
cd /opt/mqm/samp/bin
echo "$testInput" | ./amqsput ORANGE.QUEUE

getResult=`./amqsget ORANGE.QUEUE`

# Stop the queue manager.
# The '-w' argument would lead to a more graceful stop, but that takes
# a long time to run.
endmqm -i msapTestQMgr

# The output should include the input message.
grepResult=`echo $getResult | grep "$testInput"`

if ( test -z "$grepResult" ) ; then
  echo Error:  Message retrieved from queue did not match that sent to the queue.
  echo Message sent to queue:  $testInput
  echo Message received from queue:  $getResult
  exit 1
else
  echo MQ setup verified.
  exit 0
fi

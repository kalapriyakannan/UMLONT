#!/bin/bash

# $1 = clear-text password for user mqm.


# Set mqm password
echo mqm:$2 | chpasswd

# Add user root to group mqm
cp /etc/group /etc/group.tmp
awk '{if ($l~/root/) print $0; else if (($l~/^mqm:/)&&($l~/:$/)) print $0"root"; else if ($l~/^mqm:/) print $0",root"; else print $0}' /etc/group.tmp > /etc/group

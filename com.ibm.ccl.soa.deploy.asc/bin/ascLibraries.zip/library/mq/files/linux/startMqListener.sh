#!/bin/bash

# $1 = qMgr
# $2 = port

# Invoked from a shell script so that we can launch it in the background.
# I couldn't find a way to get this running as a (simpler) command because
# of the ampersand.

runmqlsr -t tcp -m $1 -p $2 &

#!/bin/sh

wasHome=$1
installerDir=$2
fixpackID=$3

mkdir $wasHome/update
cp -r $installerDir/linux/* $wasHome/update


# Drive the WAS updater.
cd $wasHome/update

source ../bin/setupCmdLine.sh
./updateSilent.sh -fixpack -installDir $wasHome -fixpackDir fixpacks -install -fixpackID $fixpackID -skipIHS -skipMQ

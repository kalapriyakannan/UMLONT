#!/bin/sh

wasHome=$1
fixFile=$2
fixId=$3

mkdir $wasHome/update/fixes
cp $fixFile $wasHome/update/fixes


# Drive the WAS updater.
cd $wasHome/update

source ../bin/setupCmdLine.sh
./updateSilent.sh -fix -installDir $wasHome -fixDir fixes -install -fixes $fixId

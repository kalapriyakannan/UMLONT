package minibank.web;

import java.io.IOException;
import java.math.BigDecimal;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import minibank.ejb.Bankaccount;
import minibank.ejb.BankaccountFactory;
import minibank.ejb.BankaccountKey;
import minibank.ejb.Currency;
import minibank.ejb.CurrencyFactory;
import minibank.ejb.CurrencyKey;
import minibank.ejb.Customer;
import minibank.ejb.CustomerFactory;
import minibank.ejb.CustomerKey;
/**
 * Handles all login related requests for Minibank
 */
public class LoginServlet extends javax.servlet.http.HttpServlet {	
	
	/**
 	 * Process incoming HTTP POST requests 
 	 * 
	 * @param request Object that encapsulates the request to the servlet 
	 * @param response Object that encapsulates the response from the servlet
 	 */
	public void doPost( javax.servlet.http.HttpServletRequest request, 
								   javax.servlet.http.HttpServletResponse response) 
								   throws javax.servlet.ServletException, java.io.IOException {
		performTask(request, response);
	}// doPost
	
	
 	 /**
 	 * Process incoming HTTP Get requests 
 	 * 
	 * @param request Object that encapsulates the request to the servlet 
	 * @param response Object that encapsulates the response from the servlet
 	 */
	public void doGet( javax.servlet.http.HttpServletRequest request, 
								   javax.servlet.http.HttpServletResponse response) 
								   throws javax.servlet.ServletException, java.io.IOException {
		performTask(request, response);
	}// doGet
	
	/**
 	 * Process incoming requests for information
 	 * 
 	 * @param request - Object that encapsulates the request to the servlet 
 	 * @param response - Object that encapsulates the response from the servlet
 	 */
	public void performTask( javax.servlet.http.HttpServletRequest request, 
											javax.servlet.http.HttpServletResponse response) {

		try	{
			
			CustomerFactory aCustomerFactory = new CustomerFactory();
			BankaccountFactory aBankaccountFactory = new BankaccountFactory();
			CurrencyFactory aCurrencyFactory = new CurrencyFactory();
			Bankaccount aBankaccount;
			Customer aCustomer;	
			Currency aCurrency;
			
			HttpSession session = request.getSession();
			
			String page = new String();
			page = request.getParameter( "page" );
			
			//The user has chosen the welcome page
			if( page != null && page.equals( "welcome" ) ) {
				
				String accountID = request.getParameter( "customer_id1" ).trim().toUpperCase() + "-" + request.getParameter( "customer_id2" ).trim();
	
				try {
					
					aCustomer = aCustomerFactory.findByPrimaryKey(new CustomerKey(accountID));					
					aBankaccount = aBankaccountFactory.findByPrimaryKey(new BankaccountKey(accountID));
					aCurrency = aCurrencyFactory.findByPrimaryKey(new CurrencyKey(new Integer( request.getParameter( "customer_id2" ) ).intValue() ));
				
					//Add all the objects to the session
					session.setAttribute( "currencyObj", aCurrency );
					session.setAttribute( "customerObj", aCustomer );
					session.setAttribute( "bankaccountObj", aBankaccount );
												
					//Add the accountID to the session
					session.setAttribute( "accountID", accountID );	
					
					//Flag for the jsp to display a welcome message for the existing customer
					request.setAttribute( "newCustomer", "false" );
									
					this.doForward( request, response, "/mbWelcomeSummary.jsp" );
					
				} catch( javax.ejb.FinderException fe ) {
					fe.printStackTrace();
					request.setAttribute( "login_error", "invalid login id" );	
					
					//Forward back to the welcome page to display the error					
					this.doForward( request, response, "/mbWelcome.jsp" );		
						
				}// try
				
			//The user has chosen the new customer page
			} else if( page != null && page.equals( "new_customer" ) ) {
				
				//Kill the session if one exists, then create a new one
				session.invalidate(); 
				session = request.getSession();
							
				//Grab all the attributes from the request and trim off the white space
				String title = request.getParameter( "title" ).trim();
				String firstName = request.getParameter( "first_name" ).trim();
				String lastName = request.getParameter( "last_name" ).trim();			
				String currencyName = request.getParameter( "currency_name" ).trim();				
				
				//Validate the user's profile information
				if(  firstName.length() < 2 || lastName.length() < 2 || currencyName.length() < 2 ) {
					request.setAttribute( "profile_error", "Text fields are blank or less than two characters long." );	
					
					//Forward back to the new customer page page to display the error					
					this.doForward( request, response, "/mbNewCustomer.jsp" );					
				} else {				
					
					//Capitalize the first letter of the first and last
					StringBuffer fname = new StringBuffer( firstName );
					StringBuffer lname = new StringBuffer( lastName );
				
					fname.replace( 0, 1, firstName.toString().toUpperCase().substring( 0, 1 ) );
					lname.replace( 0, 1, lastName.toString().toUpperCase().substring( 0, 1 ) );
										
					//Create a unique account ID
					String accPrt1 = lname.toString().substring( 0, 2 ).toUpperCase() + "-";
					int accPrt2 = Math.abs((int) new Long(System.currentTimeMillis()).intValue());
					String accountID = accPrt1 + accPrt2;													;													
					
					//Create the Customer
					System.out.println( "Creating a new Minibank Customer..." );					
					aCustomer = aCustomerFactory.create( accountID );
					aCustomer.setName( new minibank.ejb.Name( title, fname.toString(), lname.toString() ) );					
//					aCustomer.commitCopyHelper();
					session.setAttribute( "customerObj", aCustomer );

					//Create the currency with the last part of the ID
					System.out.println( "Creating a new Minibank Currency..." );
					aCurrency = aCurrencyFactory.create( accPrt2 );
					aCurrency.setName( currencyName );
//					aCurrency.commitCopyHelper();
					session.setAttribute( "currencyObj", aCurrency );
					
					//Create the bankaccount with the customer id
					System.out.println( "Creating a new Bankaccount..." );
					aBankaccount = aBankaccountFactory.create( accountID );
					aBankaccount.setBalance( new BigDecimal( "0.00" ) );
//					aBankaccount.commitCopyHelper();
					session.setAttribute( "bankaccountObj", aBankaccount );

					//Add the accountID to the session
					session.setAttribute( "accountID", accountID );
					
					//Flag for the jsp to display a welcome message for the new customer
					request.setAttribute( "newCustomer", "true" );
					
					//Forward the new customer to the welcome summary page					
					this.doForward( request, response, "/mbWelcomeSummary.jsp" );
				}// if
			
			//The user has chosen to edit their profile
			} else if( page != null && page.equals( "edit_customer" ) ) {
				
				//Get the session objects and edit them as requested by the user
				aCustomer = (Customer)session.getAttribute( "customerObj" );			
				aCurrency = (Currency)session.getAttribute( "currencyObj" );
				
				//Grab all the attributes from the request and trim off the white space
				String title = request.getParameter( "title" ).trim();
				String firstName = request.getParameter( "first_name" ).trim();
				String lastName = request.getParameter( "last_name" ).trim();			
				String currencyName = request.getParameter( "currency_name" ).trim();				
				
				//Validate the user's profile information
				if(  firstName.length() < 2 || lastName.length() < 2 || currencyName.length() < 2 ) {
					request.setAttribute( "profile_error", "Text fields are blank or less than two characters long." );	
					
					//Forward back to the edit customer page page to display the error					
					this.doForward( request, response, "/mbEditCustomer.jsp" );		
				} else {
					
					//Make sure the first letter of the first and last name are in caps
					StringBuffer fname = new StringBuffer( firstName );
					StringBuffer lname = new StringBuffer( lastName );
				
					fname.replace( 0, 1, firstName.toString().toUpperCase().substring( 0, 1 ) );
					lname.replace( 0, 1, lastName.toString().toUpperCase().substring( 0, 1 ) );
					
					aCurrency.setName( currencyName );
//					aCurrency.commitCopyHelper();
					
					aCustomer.setName( new minibank.ejb.Name( title, fname.toString(), lname.toString() ) );					
//					aCustomer.commitCopyHelper();
					
					//Add all the objects to the session					
					session.setAttribute( "customerObj", aCustomer );
					session.setAttribute( "currencyObj", aCurrency );
					request.setAttribute( "changed", "true" );	
					
					//Forward back to the edit customer page to display the changes
					this.doForward( request, response, "/mbEditCustomer.jsp" );
				}// if								
			
			//The user has chosen to logout
			} else if( page != null && page.equals( "logout" ) ) {
								
				if( request.getParameter( "exit_button" ).trim().toLowerCase().equals( "yes" ) ) {
					
					//Kill the session
					session.invalidate();				
					
					//Forward to the welcome page					
					this.doForward( request, response, "/mbWelcome.jsp" );					
				} else {
					
					//Forward to the welcome summary page					
					this.doForward( request, response, "/mbWelcomeSummary.jsp" );														
					
				}//if				
				
			}// if

			//System.out.println( "minibank.web.LoginServlet::Servlet is done processing" );
		} catch( Exception e ) {
			e.printStackTrace();
		}// try
		
	}// performTask

	/**
	 * Forward the request
	 *
	 * @param request  - HTTP request
	 * @param response - HTTP response
	 * @param nextPage - the next page to forward too
	 */
	public void doForward(  HttpServletRequest request, 
							HttpServletResponse response, String nextPage ) {
			try {		    		
				getServletConfig().getServletContext().getRequestDispatcher( nextPage ).forward( request, response );            					   						
			} catch (IOException ioe) {
				System.out.println( "LoginServlet IOException Forwarding Request: " + ioe );
			} catch (ServletException se) {
				System.out.println( "LoginServlet ServletException Forwarding Request: " + se );
	 	    }// try		
						
	}// doForward

}
package minibank.web;

import java.io.*;
import java.math.BigDecimal;
import java.rmi.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

import minibank.ejb.*;

/**
 * Handles all transaction related requests for Minibank.
 */
public class TransServlet extends javax.servlet.http.HttpServlet {	
	
	/**
 	 * Process incoming HTTP POST requests 
 	 * 
	 * @param request Object that encapsulates the request to the servlet 
	 * @param response Object that encapsulates the response from the servlet
 	 */
	public void doPost( javax.servlet.http.HttpServletRequest request, 
								   javax.servlet.http.HttpServletResponse response) 
								   throws javax.servlet.ServletException, java.io.IOException {
		performTask(request, response);
	}// doPost	
	
  	/**
 	 * Process incoming HTTP Get requests 
 	 * 
	 * @param request Object that encapsulates the request to the servlet 
	 * @param response Object that encapsulates the response from the servlet
 	 */
	public void doGet( javax.servlet.http.HttpServletRequest request, 
								   javax.servlet.http.HttpServletResponse response) 
								   throws javax.servlet.ServletException, java.io.IOException {
		performTask(request, response);
	}// doGet
	
	/**
 	 * Process incoming requests for information
 	 * 
 	 * @param request - Object that encapsulates the request to the servlet 
 	 * @param response - Object that encapsulates the response from the servlet
 	 */
	public void performTask( javax.servlet.http.HttpServletRequest request, 
											javax.servlet.http.HttpServletResponse response) {

		BankaccountFactory aBankaccountFactory = new BankaccountFactory();
		Bankaccount aBankaccount;

			
		try	{			
			HttpSession session = request.getSession();
			
			String page = new String();
			BigDecimal newAmount = new BigDecimal( "0.00" );
			BigDecimal newBalance = new BigDecimal( "0.00" );
			
			page = request.getParameter( "page" );						
			
			//The user has chosen the transaction page
			if( page != null && page.equals( "transaction" ) ) {
				
				//Check for valid amount
				String amount = request.getParameter( "amount" ).trim();
				if( amount.equalsIgnoreCase( "" ) ) {
					
					request.setAttribute( "trans_error", "Missing transaction amount." );	
					
					//Forward back to the transaction page to display the error					
					this.doForward( request, response, "/mbMakeTransaction.jsp" );	

				} else if( amount.lastIndexOf( ',' ) != -1 ) {
					
					request.setAttribute( "trans_error", "Do not use commas in the transaction amount." );	
					
					//Forward back to the transaction page to display the error					
					this.doForward( request, response, "/mbMakeTransaction.jsp" );	
					
				} else if( amount.lastIndexOf( '.' ) == -1 ) {
					
					request.setAttribute( "trans_error", "Specify the decimal portion in the transaction amount." );	
					
					//Forward back to the transaction page to display the error					
					this.doForward( request, response, "/mbMakeTransaction.jsp" );	
				
				} else if( amount.charAt( amount.length() - 3 ) != '.' ) {
					
					request.setAttribute( "trans_error", "The decimal portion of the transaction amount must be two digits." );	
					
					//Forward back to the transaction page to display the error					
					this.doForward( request, response, "/mbMakeTransaction.jsp" );	
				
				} else if( amount.charAt( 0 ) == '-' ) {
					
					request.setAttribute( "trans_error", "Do not enter negative transaction amounts." );	
					
					//Forward back to the transaction page to display the error					
					this.doForward( request, response, "/mbMakeTransaction.jsp" );	
				
				} else {
					
					try {
						newAmount = new BigDecimal( amount );
					} catch (NumberFormatException nfe) {
						request.setAttribute( "trans_error", "Invalid transaction amount." );	
					
						//Forward back to the transaction page to display the error
						this.doForward( request, response, "/mbMakeTransaction.jsp" );
					}
					
					Vector transHistories = new Vector();	//History of transactions
					Vector amountHistories = new Vector();	//History of amounts
					Vector balanceHistories = new Vector();	//History of balances
					
					//Grab the back account from the session
				    aBankaccount = (Bankaccount)session.getAttribute( "bankaccountObj" );

					//Create or get amount histories					
					if( (Vector)session.getAttribute( "amountHistories" ) != null ) {
						amountHistories = (Vector)session.getAttribute( "amountHistories" );					
					} else {
						amountHistories = new Vector();													
						amountHistories.add( aBankaccount.getBalance() );
						session.setAttribute( "amountHistories", amountHistories );					
					}// if	
					
					//Create or get transaction histories
					if( (Vector)session.getAttribute( "transHistories" ) != null ) {
						transHistories = (Vector)session.getAttribute( "transHistories" );					   
					} else {
						transHistories = new Vector();													
						transHistories.add( "Initial Balance" );
						session.setAttribute( "transHistories", transHistories );					
					}// if					
					
					//If there is a record of balances get them, else create a new one with the last balance
					if( (Vector)session.getAttribute( "balanceHistories" ) != null ) {
						balanceHistories = (Vector)session.getAttribute( "balanceHistories" );
					} else {
						balanceHistories = new Vector();																		
						balanceHistories.add( aBankaccount.getBalance() );
						session.setAttribute( "balanceHistories", balanceHistories );
					}// if	

					//The user has submitted a withdrawal
					if( request.getParameter( "transaction_submit" ).equals( "Withdrawal" ) ) {
						
						//Subtract the new amount from the previous balance
						aBankaccount.setBalance( aBankaccount.getBalance().subtract( newAmount ) );
						
						//Create a new balance												
						newBalance = new BigDecimal( aBankaccount.getBalance().toString() );
						
						//Add histories to vectors
						transHistories.add( "Withdrawal" );
						amountHistories.add( newAmount );
						balanceHistories.add( newBalance );

						//Commit the new balance
						aBankaccount.setBalance( newBalance );
//						aBankaccount.commitCopyHelper();
					
						//Replace all the session objects with new ones 						
						session.setAttribute( "balanceHistories", balanceHistories );
						session.setAttribute( "amountHistories", amountHistories );
						session.setAttribute( "transHistories", transHistories );
						session.setAttribute( "bankaccountObj", aBankaccount );
						session.setAttribute( "did_transaction" , "true" );
		
						//Forward back to the transaction page			
						this.doForward( request, response, "/mbMakeTransaction.jsp" );	

					//The user has submitted a deposit
					} else {
						
						//Add the new amount to the previous balance						
						aBankaccount.setBalance( aBankaccount.getBalance().add( newAmount ) );
																														
						//Create a new balance												
						newBalance = new BigDecimal( aBankaccount.getBalance().toString() );
						
						//Add histories to vectors
						transHistories.add( "Deposit" );
						amountHistories.add( newAmount );
						balanceHistories.add( newBalance );						
												
						//Commit the new balance to the database
						aBankaccount.setBalance( newBalance );
//						aBankaccount.commitCopyHelper();
					
						//Replace all the session objects with new ones 							
						session.setAttribute( "balanceHistories", balanceHistories );
						session.setAttribute( "amountHistories", amountHistories );
						session.setAttribute( "transHistories", transHistories );
						session.setAttribute( "bankaccountObj", aBankaccount );											
						session.setAttribute( "did_transaction" , "true" );
						
						//Forward back to the transaction page
						this.doForward( request, response, "/mbMakeTransaction.jsp" );	
						
					}// if											
				}//if											
			}// if
								
			//System.out.println( "minibank.web.TransServlet::Servlet is done processing" );
		} catch( Exception e ) {
			e.printStackTrace();	
		}// try
		
	}// performTask

	/**
	 * Forward the request
	 *
	 * @param request  - HTTP request
	 * @param response - HTTP reponse
	 * @param nextPage - the next page to forward to
	 */
	public void doForward(  HttpServletRequest request, 
							HttpServletResponse response, String nextPage ) {
			try {		    		
				getServletConfig().getServletContext().getRequestDispatcher( nextPage ).forward( request, response );            					   						
			} catch (IOException ioe) {
				System.out.println( "TransServlet IOException Forwarding Request" + ioe );
			 } catch (ServletException se) {
				System.out.println( "TransServlet ServletException Forwarding Request" + se );
	 	    }// try		
						
	}// doForward
	
}
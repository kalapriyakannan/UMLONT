package minibank.ejb;
/**
 * Key class for Entity Bean: Customer
 */
public class CustomerKey implements java.io.Serializable {
	static final long serialVersionUID = 3206093459760846163L;
	/**
	 * Implemetation field for persistent attribute: customerid
	 */
	public java.lang.String customerid;
	/**
	 * Creates an empty key for Entity Bean: Customer
	 */
	public CustomerKey() {
	}
	/**
	 * Creates a key for Entity Bean: Customer
	 */
	public CustomerKey(java.lang.String customerid) {
		this.customerid = customerid;
	}
	/**
	 * Returns true if both keys are equal.
	 */
	public boolean equals(java.lang.Object otherKey) {
		if (otherKey instanceof minibank.ejb.CustomerKey) {
			minibank.ejb.CustomerKey o = (minibank.ejb.CustomerKey)otherKey;
			return ((this.customerid.equals(o.customerid)));
		}
		return false;
	}
	/**
	 * Returns the hash code for the key.
	 */
	public int hashCode() {
		return (customerid.hashCode());
	}
}

package minibank.ejb;
/**
 * Home interface for Enterprise Bean: Bankaccount
 */
public interface BankaccountHome extends javax.ejb.EJBHome {
	/**
	 * Creates an instance from a key for Entity Bean: Bankaccount
	 */
	public minibank.ejb.Bankaccount create(java.lang.String accountid) throws javax.ejb.CreateException, java.rmi.RemoteException;
	/**
	 * Finds an instance using a key for Entity Bean: Bankaccount
	 */
	public minibank.ejb.Bankaccount findByPrimaryKey(minibank.ejb.BankaccountKey primaryKey) throws javax.ejb.FinderException, java.rmi.RemoteException;

	public minibank.ejb.Bankaccount findByCustomerID(int id) throws java.rmi.RemoteException, javax.ejb.FinderException;

}

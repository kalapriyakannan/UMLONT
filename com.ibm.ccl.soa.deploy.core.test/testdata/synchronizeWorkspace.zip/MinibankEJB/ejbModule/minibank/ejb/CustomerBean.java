package minibank.ejb;
/**
 * Bean implementation class for Enterprise Bean: Customer
 */
public class CustomerBean implements javax.ejb.EntityBean, minibank.ejb.CustomerData.Store {



	private javax.ejb.EntityContext myEntityCtx;
	/**
	 * Implemetation field for persistent attribute: customerid
	 */
	public java.lang.String customerid;
	/**
	 * Implemetation field for persistent attribute: name
	 */
	public minibank.ejb.Name name;
	/**
	 * getEntityContext
	 */
	public javax.ejb.EntityContext getEntityContext() {
		return myEntityCtx;
	}
	/**
	 * setEntityContext
	 */
	public void setEntityContext(javax.ejb.EntityContext ctx) {
		myEntityCtx = ctx;
	}
	/**
	 * unsetEntityContext
	 */
	public void unsetEntityContext() {
		myEntityCtx = null;
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbCreate method for a CMP entity bean.
	 */
	public minibank.ejb.CustomerKey ejbCreate(java.lang.String customerid) throws javax.ejb.CreateException {
		_initLinks();
		this.customerid = customerid;
		return null;
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(java.lang.String customerid) throws javax.ejb.CreateException {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
	}
	/**
	 * This method was generated for supporting the associations.
	 */
	protected void _initLinks() {
	}
	/**
	 * This method was generated for supporting the associations.
	 */
	protected java.util.Vector _getLinks() {
		java.util.Vector links = new java.util.Vector();
		return links;
	}
	/**
	 * This method was generated for supporting the associations.
	 */
	protected void _removeLinks() throws java.rmi.RemoteException, javax.ejb.RemoveException {
		java.util.List links = _getLinks();
		for (int i = 0; i < links.size() ; i++) {
			try {
				((com.ibm.ivj.ejb.associations.interfaces.Link) links.get(i)).remove();
			} catch (javax.ejb.FinderException e) {} //Consume Finder error since I am going away
		}
	}
	/**
	 * Get accessor for persistent attribute: name
	 */
	public minibank.ejb.Name getName() {
		return name;
	}
	/**
	 * Set accessor for persistent attribute: name
	 */
	public void setName(minibank.ejb.Name newName) {
		name = newName;
	}
	/**
	 * getCustomerData
	 */
	public minibank.ejb.CustomerData getCustomerData() {
		return new minibank.ejb.CustomerData(this);
	}
	/**
	 * setCustomerData
	 */
	public void setCustomerData(minibank.ejb.CustomerData data) throws com.ibm.etools.ejb.client.runtime.FieldChangedException {
		data.copyTo(this);
		if ( !data.getIsnameDirty() ) {
			if ( this.getName() != null && data.getName() != null ) {
				if ( !this.getName().equals(data.getName()) )
					throw new com.ibm.etools.ejb.client.runtime.FieldChangedException();
			}
		}
	}
	/**
	 * syncCustomerData
	 */
	public minibank.ejb.CustomerData syncCustomerData(minibank.ejb.CustomerData data) {
		data.copyTo(this);
		return this.getCustomerData();
	}
	/**
	 * getPrimaryKey
	 */
	public Object getPrimaryKey() {
		return getEntityContext().getPrimaryKey();
	}
}

package minibank.ejb;
/**
 * EJSCMPCustomerHomeBean
 * @generated
 */
public class EJSCMPCustomerHomeBean
	extends minibank.ejb.EJSCMPCustomerHomeBean_efcc4527 {
	/**
	 * EJSCMPCustomerHomeBean
	 * @generated
	 */
	public EJSCMPCustomerHomeBean() throws java.rmi.RemoteException {
		super();
	}
}

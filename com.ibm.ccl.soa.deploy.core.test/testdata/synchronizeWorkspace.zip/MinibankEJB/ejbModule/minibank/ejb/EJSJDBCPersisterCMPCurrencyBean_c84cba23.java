package minibank.ejb;
import com.ibm.ejs.persistence.*;
import javax.ejb.EntityBean;
import java.sql.*;
import java.text.*;
import com.ibm.vap.converters.*;
import com.ibm.vap.converters.streams.*;
/**
 * EJSJDBCPersisterCMPCurrencyBean_c84cba23
 * @generated
 */
public class EJSJDBCPersisterCMPCurrencyBean_c84cba23
	extends EJSJDBCPersister
	implements minibank.ejb.EJSFinderCurrencyBean {
	/**
	 * @generated
	 */
	private static final String _createString =
		"INSERT INTO CURRENCY (CURRENCYID, NAME) VALUES (?, ?)";
	/**
	 * @generated
	 */
	private static final String _removeString =
		"DELETE FROM CURRENCY  WHERE CURRENCYID = ?";
	/**
	 * @generated
	 */
	private static final String _storeString =
		"UPDATE CURRENCY  SET NAME = ? WHERE CURRENCYID = ?";
	/**
	 * @generated
	 */
	private static final String _loadString =
		"SELECT T1.NAME, T1.CURRENCYID FROM CURRENCY  T1 WHERE T1.CURRENCYID = ?";
	/**
	 * @generated
	 */
	private static final String _loadForUpdateString =
		_loadString + " FOR UPDATE";
	/**
	 * @generated
	 */
	private byte[] serObj = null;
	/**
	 * EJSJDBCPersisterCMPCurrencyBean_c84cba23
	 * @generated
	 */
	public EJSJDBCPersisterCMPCurrencyBean_c84cba23()
		throws java.rmi.RemoteException {
		super();
	}
	/**
	 * postInit
	 * @generated
	 */
	public void postInit() {
	}
	/**
	 * _create
	 * @generated
	 */
	public void _create(EntityBean eb) throws Exception {
		Object objectTemp = null;
		CurrencyBean b = (CurrencyBean) eb;
		PreparedStatement pstmt;
		pstmt = getPreparedStatement(_createString);
		try {
			objectTemp =
				com
					.ibm
					.vap
					.converters
					.VapTrimStringConverter
					.singleton()
					.dataFrom(
					b.name);
			if (objectTemp == null) {
				pstmt.setNull(2, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(2, (java.lang.String) objectTemp);
			}
			pstmt.setInt(1, b.currencyId);
			pstmt.executeUpdate();
		} finally {
			returnPreparedStatement(pstmt);
		}
	}
	/**
	 * hydrate
	 * @generated
	 */
	public void hydrate(EntityBean eb, Object data, Object pKey)
		throws Exception {
		Object objectTemp = null;
		CurrencyBean b = (CurrencyBean) eb;
		minibank.ejb.CurrencyKey _primaryKey = (minibank.ejb.CurrencyKey) pKey;
		java.sql.ResultSet resultSet = (java.sql.ResultSet) data;
		b.currencyId = _primaryKey.currencyId;
		b.name =
			(java.lang.String) com
				.ibm
				.vap
				.converters
				.VapTrimStringConverter
				.singleton()
				.objectFrom(resultSet.getString(1));
	}
	/**
	 * load
	 * @generated
	 */
	public void load(EntityBean eb, Object pKey, boolean forUpdate)
		throws Exception {
		Object objectTemp = null;
		CurrencyBean b = (CurrencyBean) eb;
		minibank.ejb.CurrencyKey _primaryKey = (minibank.ejb.CurrencyKey) pKey;
		PreparedStatement pstmt;
		ResultSet resultSet = null;
		pstmt =
			(forUpdate)
				? getPreparedStatement(_loadForUpdateString)
				: getPreparedStatement(_loadString);
		try {
			pstmt.setInt(1, _primaryKey.currencyId);
			resultSet = pstmt.executeQuery();
			if (!(resultSet.next()))
				throw new javax.ejb.ObjectNotFoundException();
			hydrate(eb, resultSet, pKey);
		} finally {
			if (resultSet != null)
				resultSet.close();
			returnPreparedStatement(pstmt);
		}
	}
	/**
	 * refresh
	 * @generated
	 */
	public void refresh(EntityBean eb, boolean forUpdate) throws Exception {
		CurrencyBean b = (CurrencyBean) eb;
		minibank.ejb.CurrencyKey _primaryKey = new minibank.ejb.CurrencyKey();
		_primaryKey.currencyId = b.currencyId;
		load(b, _primaryKey, forUpdate);
	}
	/**
	 * store
	 * @generated
	 */
	public void store(EntityBean eb) throws Exception {
		Object objectTemp = null;
		CurrencyBean b = (CurrencyBean) eb;
		minibank.ejb.CurrencyKey _primaryKey = new minibank.ejb.CurrencyKey();
		_primaryKey.currencyId = b.currencyId;
		PreparedStatement pstmt;
		pstmt = getPreparedStatement(_storeString);
		try {
			pstmt.setInt(2, _primaryKey.currencyId);
			objectTemp =
				com
					.ibm
					.vap
					.converters
					.VapTrimStringConverter
					.singleton()
					.dataFrom(
					b.name);
			if (objectTemp == null) {
				pstmt.setNull(1, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(1, (java.lang.String) objectTemp);
			}
			pstmt.executeUpdate();
		} finally {
			returnPreparedStatement(pstmt);
		}
	}
	/**
	 * remove
	 * @generated
	 */
	public void remove(EntityBean eb) throws Exception {
		Object objectTemp = null;
		CurrencyBean b = (CurrencyBean) eb;
		minibank.ejb.CurrencyKey _primaryKey = new minibank.ejb.CurrencyKey();
		_primaryKey.currencyId = b.currencyId;
		PreparedStatement pstmt;
		pstmt = getPreparedStatement(_removeString);
		try {
			pstmt.setInt(1, _primaryKey.currencyId);
			pstmt.executeUpdate();
		} finally {
			returnPreparedStatement(pstmt);
		}
	}
	/**
	 * getPrimaryKey
	 * @generated
	 */
	public Object getPrimaryKey(Object data) throws Exception {
		minibank.ejb.CurrencyKey key = new minibank.ejb.CurrencyKey();
		java.sql.ResultSet resultSet = (java.sql.ResultSet) data;

		if (resultSet != null) {
			Object objectTemp = null;
			key.currencyId = resultSet.getInt(2);
			return key;
		}
		return null;
	}
	/**
	 * findByPrimaryKey
	 * @generated
	 */
	public minibank.ejb.Currency findByPrimaryKey(
		minibank.ejb.CurrencyKey primaryKey)
		throws java.rmi.RemoteException, javax.ejb.FinderException {
		return (minibank.ejb.Currency) home.activateBean(primaryKey);
	}
}

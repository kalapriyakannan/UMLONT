package minibank.ejb;
import com.ibm.etools.ejb.client.runtime.*;
/**
 * CustomerData
 * @generated
 */
public class CustomerData extends AbstractEntityData {
	/**
	 * @generated
	 */
	private minibank.ejb.Name name;
	/**
	 * @generated
	 */
	private boolean isnameDirty = false;
	/**
	 * getIsnameDirty
	 * @generated
	 */
	public boolean getIsnameDirty() {
		return this.isnameDirty;
	}
	/**
	 * getName
	 * @generated
	 */
	public minibank.ejb.Name getName() {
		return this.name;
	}
	/**
	 * setName
	 * @generated
	 */
	public void setName(minibank.ejb.Name value) {
		this.name = value;
		this.isnameDirty = true;
		this.isDirty = true;
	}
	/**
	 * Store
	 * @generated
	 */
	public interface Store extends AbstractEntityData.Store {
			/**
		 * getName
		 * @generated
		 */
		public minibank.ejb.Name getName();
		/**
		 * setName
		 * @generated
		 */
		public void setName(minibank.ejb.Name value);
}
	/**
	 * CustomerData
	 * @generated
	 */
	public CustomerData() {
		super();
	}
	/**
	 * CustomerData
	 * @generated
	 */
	public CustomerData(CustomerData.Store initializer) {
		super(initializer);
		initialize(initializer);
	}
	/**
	 * initialize
	 * @generated
	 */
	protected void initialize(CustomerData.Store initializer) {
		this.name = initializer.getName();
	}
	/**
	 * copyTo
	 * @generated
	 */
	public void copyTo(CustomerData.Store target) {
		if (!this.isDirty) return;
		if (this.isnameDirty ) target.setName(this.name);
	}
}

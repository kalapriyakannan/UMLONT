package minibank.ejb;
import javax.ejb.*;
import java.rmi.RemoteException;
import javax.naming.NamingException;
import com.ibm.etools.ejb.client.runtime.*;
/**
 * BankaccountFactory
 * @generated
 */
public class BankaccountFactory extends AbstractEJBFactory {
	/**
	 * BankaccountFactory
	 * @generated
	 */
	public BankaccountFactory() {
		super();
	}
	/**
	 * _acquireBankaccountHome
	 * @generated
	 */
	protected minibank.ejb.BankaccountHome _acquireBankaccountHome() throws java.rmi.RemoteException {
		return (minibank.ejb.BankaccountHome) _acquireEJBHome();
	}
	/**
	 * acquireBankaccountHome
	 * @generated
	 */
	public minibank.ejb.BankaccountHome acquireBankaccountHome() throws javax.naming.NamingException {
		return (minibank.ejb.BankaccountHome) acquireEJBHome();
	}
	/**
	 * getDefaultJNDIName
	 * @generated
	 */
	public String getDefaultJNDIName() {
		return "minibank/ejb/Bankaccount";
	}
	/**
	 * getHomeInterface
	 * @generated
	 */
	protected Class getHomeInterface() {
		return minibank.ejb.BankaccountHome.class;
	}
	/**
	 * resetBankaccountHome
	 * @generated
	 */
	public void resetBankaccountHome() {
		resetEJBHome();
	}
	/**
	 * setBankaccountHome
	 * @generated
	 */
	public void setBankaccountHome(minibank.ejb.BankaccountHome home) {
		setEJBHome(home);
	}
	/**
	 * findByPrimaryKey
	 * @generated
	 */
	public minibank.ejb.Bankaccount findByPrimaryKey(minibank.ejb.BankaccountKey primaryKey) throws FinderException, RemoteException {
		return _acquireBankaccountHome().findByPrimaryKey(primaryKey);
	}
	/**
	 * findByCustomerID
	 * @generated
	 */
	public minibank.ejb.Bankaccount findByCustomerID(int id) throws RemoteException, FinderException {
		return _acquireBankaccountHome().findByCustomerID(id);
	}
	/**
	 * create
	 * @generated
	 */
	public minibank.ejb.Bankaccount create(java.lang.String accountid) throws CreateException, RemoteException {
		return _acquireBankaccountHome().create(accountid);
	}
}

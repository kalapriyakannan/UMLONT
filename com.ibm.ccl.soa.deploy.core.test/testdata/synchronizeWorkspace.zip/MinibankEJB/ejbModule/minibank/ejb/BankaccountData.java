package minibank.ejb;
import com.ibm.etools.ejb.client.runtime.*;
/**
 * BankaccountData
 * @generated
 */
public class BankaccountData extends AbstractEntityData {
	/**
	 * @generated
	 */
	private java.math.BigDecimal balance;
	/**
	 * @generated
	 */
	private boolean isbalanceDirty = false;
	/**
	 * getIsbalanceDirty
	 * @generated
	 */
	public boolean getIsbalanceDirty() {
		return this.isbalanceDirty;
	}
	/**
	 * getBalance
	 * @generated
	 */
	public java.math.BigDecimal getBalance() {
		return this.balance;
	}
	/**
	 * setBalance
	 * @generated
	 */
	public void setBalance(java.math.BigDecimal value) {
		this.balance = value;
		this.isbalanceDirty = true;
		this.isDirty = true;
	}
	/**
	 * Store
	 * @generated
	 */
	public interface Store extends AbstractEntityData.Store {
			/**
		 * getBalance
		 * @generated
		 */
		public java.math.BigDecimal getBalance();
		/**
		 * setBalance
		 * @generated
		 */
		public void setBalance(java.math.BigDecimal value);
}
	/**
	 * BankaccountData
	 * @generated
	 */
	public BankaccountData() {
		super();
	}
	/**
	 * BankaccountData
	 * @generated
	 */
	public BankaccountData(BankaccountData.Store initializer) {
		super(initializer);
		initialize(initializer);
	}
	/**
	 * initialize
	 * @generated
	 */
	protected void initialize(BankaccountData.Store initializer) {
		this.balance = initializer.getBalance();
	}
	/**
	 * copyTo
	 * @generated
	 */
	public void copyTo(BankaccountData.Store target) {
		if (!this.isDirty) return;
		if (this.isbalanceDirty ) target.setBalance(this.balance);
	}
}

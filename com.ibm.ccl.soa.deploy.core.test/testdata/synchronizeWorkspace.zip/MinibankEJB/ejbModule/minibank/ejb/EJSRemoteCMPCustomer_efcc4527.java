package minibank.ejb;
import com.ibm.ejs.container.*;
import javax.ejb.*;
import java.rmi.RemoteException;
/**
 * EJSRemoteCMPCustomer_efcc4527
 * @generated
 */
public class EJSRemoteCMPCustomer_efcc4527
	extends EJSWrapper
	implements Customer {
	/**
	 * EJSRemoteCMPCustomer_efcc4527
	 * @generated
	 */
	public EJSRemoteCMPCustomer_efcc4527() throws java.rmi.RemoteException {
		super();
	}
	/**
	 * getCustomerData
	 * @generated
	 */
	public minibank.ejb.CustomerData getCustomerData()
		throws java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = new EJSDeployedSupport();
		minibank.ejb.CustomerData _EJS_result = null;
		try {
			minibank.ejb.CustomerBean beanRef =
				(minibank.ejb.CustomerBean) container.preInvoke(
					this,
					0,
					_EJS_s);
			_EJS_result = beanRef.getCustomerData();
		} catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		} catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new RemoteException(
				"bean method raised unchecked exception",
				ex);
		} finally {
			container.postInvoke(this, 0, _EJS_s);
		}
		return _EJS_result;
	}
	/**
	 * syncCustomerData
	 * @generated
	 */
	public minibank.ejb.CustomerData syncCustomerData(
		minibank.ejb.CustomerData data)
		throws java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = new EJSDeployedSupport();
		minibank.ejb.CustomerData _EJS_result = null;
		try {
			minibank.ejb.CustomerBean beanRef =
				(minibank.ejb.CustomerBean) container.preInvoke(
					this,
					1,
					_EJS_s);
			_EJS_result = beanRef.syncCustomerData(data);
		} catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		} catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new RemoteException(
				"bean method raised unchecked exception",
				ex);
		} finally {
			container.postInvoke(this, 1, _EJS_s);
		}
		return _EJS_result;
	}
	/**
	 * getName
	 * @generated
	 */
	public minibank.ejb.Name getName() throws java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = new EJSDeployedSupport();
		minibank.ejb.Name _EJS_result = null;
		try {
			minibank.ejb.CustomerBean beanRef =
				(minibank.ejb.CustomerBean) container.preInvoke(
					this,
					2,
					_EJS_s);
			_EJS_result = beanRef.getName();
		} catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		} catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new RemoteException(
				"bean method raised unchecked exception",
				ex);
		} finally {
			container.postInvoke(this, 2, _EJS_s);
		}
		return _EJS_result;
	}
	/**
	 * setCustomerData
	 * @generated
	 */
	public void setCustomerData(minibank.ejb.CustomerData data)
		throws
			java.rmi.RemoteException,
			com.ibm.etools.ejb.client.runtime.FieldChangedException {
		EJSDeployedSupport _EJS_s = new EJSDeployedSupport();

		try {
			minibank.ejb.CustomerBean beanRef =
				(minibank.ejb.CustomerBean) container.preInvoke(
					this,
					3,
					_EJS_s);
			beanRef.setCustomerData(data);
		} catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		} catch (com.ibm.etools.ejb.client.runtime.FieldChangedException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		} catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new RemoteException(
				"bean method raised unchecked exception",
				ex);
		} finally {
			container.postInvoke(this, 3, _EJS_s);
		}
		return;
	}
	/**
	 * setName
	 * @generated
	 */
	public void setName(minibank.ejb.Name newName)
		throws java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = new EJSDeployedSupport();

		try {
			minibank.ejb.CustomerBean beanRef =
				(minibank.ejb.CustomerBean) container.preInvoke(
					this,
					4,
					_EJS_s);
			beanRef.setName(newName);
		} catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		} catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new RemoteException(
				"bean method raised unchecked exception",
				ex);
		} finally {
			container.postInvoke(this, 4, _EJS_s);
		}
		return;
	}
}

package minibank.ejb;

// Licensed Material - Property of IBM 
// (C) Copyright IBM Corp. 1998, 2000 - All Rights Reserved 
// 
// DISCLAIMER: 
// The following [enclosed] code is sample code created by IBM 
// Corporation.  This sample code is not part of any standard IBM product 
// and is provided to you solely for the purpose of assisting you in the 
// development of your applications.  The code is provided 'AS IS', 
// without warranty or condition of any kind.  IBM shall not be liable for any damages 
// arising out of your use of the sample code, even if IBM has been 
// advised of the possibility of such damages.


/**
 * This class is used with NameComposer to map a name to
 * first, middle, and last in the db.
 */

 import java.util.StringTokenizer;
 
public class Name implements java.io.Serializable {

	private String title, firstnme, lastnme;
	
/**
 * The string fullName is delimited by '$'.
 * Set the title, firstName, and lastName using fullName.
 * @param fullName
 */
public Name(String fullName) {

	StringTokenizer st = new StringTokenizer(fullName, "$");
	int tokens = st.countTokens();
	if ((tokens > 2))
	   	setTitle(st.nextToken());
	if (st.hasMoreTokens()) setFirstName(st.nextToken());
	if (st.hasMoreTokens()) setLastName(st.nextToken());
	
}
/**
 * This method was created in VisualAgee
 */
public Name(String aTitle, String aFirst, String aLast) {

	title = aTitle;	
	firstnme = aFirst;
	lastnme = aLast;
}
/**
 * Return the full name
 */

public String fullName () {
	StringBuffer buffer = new StringBuffer();
	if (getTitle() != null) {
		buffer.append(getTitle());
		buffer.append('$');
	}
	buffer.append(getFirstName());
	buffer.append('$');
	buffer.append(getLastName());
	return buffer.toString();
}
/**
 * Get the value of the attribute firstName
 */

public String getFirstName () {
	return firstnme;
}
/**
 * Get the value of the attribute lastName
 */

public String getLastName () {
	return lastnme;
}
/**
 * Get the value of the attribute title
 */

public String getTitle () {
	return title;
}
/**
 * Set the value of the attribute firstName
 */

public void setFirstName (String aString) {

	firstnme = aString;
}
/**
 * Set the value of the attribute lastName
 */

public void setLastName (String aString) {

	lastnme = aString;
}
/**
 * Set the value of the attribute title
 */

public void setTitle (String aString) {

	title = aString;
}
/**
 * Return the full name
 */

public String toString () {
	return this.fullName();
}
}

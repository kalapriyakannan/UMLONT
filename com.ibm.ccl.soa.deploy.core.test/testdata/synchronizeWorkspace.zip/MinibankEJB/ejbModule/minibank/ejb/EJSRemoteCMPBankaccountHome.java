package minibank.ejb;
/**
 * EJSRemoteCMPBankaccountHome
 * @generated
 */
public class EJSRemoteCMPBankaccountHome
	extends minibank.ejb.EJSRemoteCMPBankaccountHome_89e03fc6
	implements minibank.ejb.BankaccountHome {
	/**
	 * EJSRemoteCMPBankaccountHome
	 * @generated
	 */
	public EJSRemoteCMPBankaccountHome() throws java.rmi.RemoteException {
		super();
	}
}

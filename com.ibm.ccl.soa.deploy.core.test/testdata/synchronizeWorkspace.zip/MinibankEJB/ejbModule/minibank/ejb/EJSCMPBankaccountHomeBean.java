package minibank.ejb;
/**
 * EJSCMPBankaccountHomeBean
 * @generated
 */
public class EJSCMPBankaccountHomeBean
	extends minibank.ejb.EJSCMPBankaccountHomeBean_89e03fc6 {
	/**
	 * EJSCMPBankaccountHomeBean
	 * @generated
	 */
	public EJSCMPBankaccountHomeBean() throws java.rmi.RemoteException {
		super();
	}
}

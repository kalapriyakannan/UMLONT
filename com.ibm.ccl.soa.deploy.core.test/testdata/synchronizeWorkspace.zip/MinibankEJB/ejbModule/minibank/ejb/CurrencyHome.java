package minibank.ejb;
/**
 * Home interface for Enterprise Bean: Currency
 */
public interface CurrencyHome extends javax.ejb.EJBHome {
	/**
	 * Creates an instance from a key for Entity Bean: Currency
	 */
	public minibank.ejb.Currency create(int currencyId) throws javax.ejb.CreateException, java.rmi.RemoteException;
	/**
	 * Finds an instance using a key for Entity Bean: Currency
	 */
	public minibank.ejb.Currency findByPrimaryKey(minibank.ejb.CurrencyKey primaryKey) throws javax.ejb.FinderException, java.rmi.RemoteException;
}

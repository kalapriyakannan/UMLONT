package minibank.ejb;
/**
 * EJSCMPCurrencyHomeBean
 * @generated
 */
public class EJSCMPCurrencyHomeBean
	extends minibank.ejb.EJSCMPCurrencyHomeBean_c84cba23 {
	/**
	 * EJSCMPCurrencyHomeBean
	 * @generated
	 */
	public EJSCMPCurrencyHomeBean() throws java.rmi.RemoteException {
		super();
	}
}

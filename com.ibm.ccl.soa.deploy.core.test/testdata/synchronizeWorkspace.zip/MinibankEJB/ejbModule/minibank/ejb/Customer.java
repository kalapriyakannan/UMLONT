package minibank.ejb;
/**
 * Remote interface for Enterprise Bean: Customer
 */
public interface Customer extends javax.ejb.EJBObject {
	/**
	 * Get accessor for persistent attribute: name
	 */
	public minibank.ejb.Name getName() throws java.rmi.RemoteException;
	/**
	 * Set accessor for persistent attribute: name
	 */
	public void setName(minibank.ejb.Name newName) throws java.rmi.RemoteException;
	/**
	 * getCustomerData
	 */
	public minibank.ejb.CustomerData getCustomerData() throws java.rmi.RemoteException;
	/**
	 * setCustomerData
	 */
	public void setCustomerData(minibank.ejb.CustomerData data) throws java.rmi.RemoteException, com.ibm.etools.ejb.client.runtime.FieldChangedException;
	/**
	 * syncCustomerData
	 */
	public minibank.ejb.CustomerData syncCustomerData(minibank.ejb.CustomerData data) throws java.rmi.RemoteException;
}

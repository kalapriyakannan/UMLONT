package minibank.ejb;
import javax.ejb.*;
import java.rmi.RemoteException;
import javax.naming.NamingException;
import com.ibm.etools.ejb.client.runtime.*;
/**
 * CustomerFactory
 * @generated
 */
public class CustomerFactory extends AbstractEJBFactory {
	/**
	 * CustomerFactory
	 * @generated
	 */
	public CustomerFactory() {
		super();
	}
	/**
	 * _acquireCustomerHome
	 * @generated
	 */
	protected minibank.ejb.CustomerHome _acquireCustomerHome() throws java.rmi.RemoteException {
		return (minibank.ejb.CustomerHome) _acquireEJBHome();
	}
	/**
	 * acquireCustomerHome
	 * @generated
	 */
	public minibank.ejb.CustomerHome acquireCustomerHome() throws javax.naming.NamingException {
		return (minibank.ejb.CustomerHome) acquireEJBHome();
	}
	/**
	 * getDefaultJNDIName
	 * @generated
	 */
	public String getDefaultJNDIName() {
		return "minibank/ejb/Customer";
	}
	/**
	 * getHomeInterface
	 * @generated
	 */
	protected Class getHomeInterface() {
		return minibank.ejb.CustomerHome.class;
	}
	/**
	 * resetCustomerHome
	 * @generated
	 */
	public void resetCustomerHome() {
		resetEJBHome();
	}
	/**
	 * setCustomerHome
	 * @generated
	 */
	public void setCustomerHome(minibank.ejb.CustomerHome home) {
		setEJBHome(home);
	}
	/**
	 * create
	 * @generated
	 */
	public minibank.ejb.Customer create(java.lang.String customerid) throws CreateException, RemoteException {
		return _acquireCustomerHome().create(customerid);
	}
	/**
	 * findByPrimaryKey
	 * @generated
	 */
	public minibank.ejb.Customer findByPrimaryKey(minibank.ejb.CustomerKey primaryKey) throws FinderException, RemoteException {
		return _acquireCustomerHome().findByPrimaryKey(primaryKey);
	}
}

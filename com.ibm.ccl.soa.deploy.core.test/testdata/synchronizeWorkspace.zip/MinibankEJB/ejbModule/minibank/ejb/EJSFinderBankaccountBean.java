package minibank.ejb;
import com.ibm.ejs.persistence.EJSFinder;
import javax.ejb.FinderException;
import java.rmi.RemoteException;
/**
 * EJSFinderBankaccountBean
 * @generated
 */
public interface EJSFinderBankaccountBean {
	/**
	 * findByCustomerID
	 * @generated
	 */
	public minibank.ejb.Bankaccount findByCustomerID(int id)
		throws javax.ejb.FinderException, java.rmi.RemoteException;
}

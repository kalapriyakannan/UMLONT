package minibank.ejb;
import com.ibm.ejs.persistence.EJSFinder;
import javax.ejb.FinderException;
import java.rmi.RemoteException;
/**
 * EJSFinderCustomerBean
 * @generated
 */
public interface EJSFinderCustomerBean {
}

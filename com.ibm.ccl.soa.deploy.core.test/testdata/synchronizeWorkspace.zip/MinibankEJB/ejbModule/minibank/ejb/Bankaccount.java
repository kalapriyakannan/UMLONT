package minibank.ejb;
/**
 * Remote interface for Enterprise Bean: Bankaccount
 */
public interface Bankaccount extends javax.ejb.EJBObject {
	/**
	 * Get accessor for persistent attribute: balance
	 */
	public java.math.BigDecimal getBalance() throws java.rmi.RemoteException;
	/**
	 * Set accessor for persistent attribute: balance
	 */
	public void setBalance(java.math.BigDecimal newBalance) throws java.rmi.RemoteException;
	/**
	 * getBankaccountData
	 */
	public minibank.ejb.BankaccountData getBankaccountData() throws java.rmi.RemoteException;
	/**
	 * setBankaccountData
	 */
	public void setBankaccountData(minibank.ejb.BankaccountData data) throws java.rmi.RemoteException, com.ibm.etools.ejb.client.runtime.FieldChangedException;
	/**
	 * syncBankaccountData
	 */
	public minibank.ejb.BankaccountData syncBankaccountData(minibank.ejb.BankaccountData data) throws java.rmi.RemoteException;
}

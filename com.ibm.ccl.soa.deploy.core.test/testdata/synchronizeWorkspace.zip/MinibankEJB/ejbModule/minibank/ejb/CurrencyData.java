package minibank.ejb;
import com.ibm.etools.ejb.client.runtime.*;
/**
 * CurrencyData
 * @generated
 */
public class CurrencyData extends AbstractEntityData {
	/**
	 * @generated
	 */
	private java.lang.String name;
	/**
	 * @generated
	 */
	private boolean isnameDirty = false;
	/**
	 * getIsnameDirty
	 * @generated
	 */
	public boolean getIsnameDirty() {
		return this.isnameDirty;
	}
	/**
	 * getName
	 * @generated
	 */
	public java.lang.String getName() {
		return this.name;
	}
	/**
	 * setName
	 * @generated
	 */
	public void setName(java.lang.String value) {
		this.name = value;
		this.isnameDirty = true;
		this.isDirty = true;
	}
	/**
	 * Store
	 * @generated
	 */
	public interface Store extends AbstractEntityData.Store {
			/**
		 * getName
		 * @generated
		 */
		public java.lang.String getName();
		/**
		 * setName
		 * @generated
		 */
		public void setName(java.lang.String value);
}
	/**
	 * CurrencyData
	 * @generated
	 */
	public CurrencyData() {
		super();
	}
	/**
	 * CurrencyData
	 * @generated
	 */
	public CurrencyData(CurrencyData.Store initializer) {
		super(initializer);
		initialize(initializer);
	}
	/**
	 * initialize
	 * @generated
	 */
	protected void initialize(CurrencyData.Store initializer) {
		this.name = initializer.getName();
	}
	/**
	 * copyTo
	 * @generated
	 */
	public void copyTo(CurrencyData.Store target) {
		if (!this.isDirty) return;
		if (this.isnameDirty ) target.setName(this.name);
	}
}

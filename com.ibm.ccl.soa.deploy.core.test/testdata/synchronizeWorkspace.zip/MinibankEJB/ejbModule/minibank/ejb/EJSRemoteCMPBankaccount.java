package minibank.ejb;
/**
 * EJSRemoteCMPBankaccount
 * @generated
 */
public class EJSRemoteCMPBankaccount
	extends minibank.ejb.EJSRemoteCMPBankaccount_89e03fc6
	implements Bankaccount {
	/**
	 * EJSRemoteCMPBankaccount
	 * @generated
	 */
	public EJSRemoteCMPBankaccount() throws java.rmi.RemoteException {
		super();
	}
}

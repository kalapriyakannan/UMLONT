package minibank.ejb;
/**
 * EJSJDBCPersisterCMPCustomerBean
 * @generated
 */
public class EJSJDBCPersisterCMPCustomerBean
	extends minibank.ejb.EJSJDBCPersisterCMPCustomerBean_efcc4527 {
	/**
	 * EJSJDBCPersisterCMPCustomerBean
	 * @generated
	 */
	public EJSJDBCPersisterCMPCustomerBean() throws java.rmi.RemoteException {
		super();
	}
}

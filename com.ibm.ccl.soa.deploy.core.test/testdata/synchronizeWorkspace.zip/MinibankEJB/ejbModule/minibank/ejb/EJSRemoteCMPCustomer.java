package minibank.ejb;
/**
 * EJSRemoteCMPCustomer
 * @generated
 */
public class EJSRemoteCMPCustomer
	extends minibank.ejb.EJSRemoteCMPCustomer_efcc4527
	implements Customer {
	/**
	 * EJSRemoteCMPCustomer
	 * @generated
	 */
	public EJSRemoteCMPCustomer() throws java.rmi.RemoteException {
		super();
	}
}

package minibank.ejb;
import com.ibm.ejs.persistence.*;
import javax.ejb.EntityBean;
import java.sql.*;
import java.text.*;
import com.ibm.vap.converters.*;
import com.ibm.vap.converters.streams.*;
/**
 * EJSJDBCPersisterCMPCustomerBean_efcc4527
 * @generated
 */
public class EJSJDBCPersisterCMPCustomerBean_efcc4527
	extends EJSJDBCPersister
	implements minibank.ejb.EJSFinderCustomerBean {
	/**
	 * @generated
	 */
	private static final String _createString =
		"INSERT INTO CUSTOMER (CUSTOMERID, FIRSTNAME, LASTNAME, TITLE) VALUES (?, ?, ?, ?)";
	/**
	 * @generated
	 */
	private static final String _removeString =
		"DELETE FROM CUSTOMER  WHERE CUSTOMERID = ?";
	/**
	 * @generated
	 */
	private static final String _storeString =
		"UPDATE CUSTOMER  SET FIRSTNAME = ?, LASTNAME = ?, TITLE = ? WHERE CUSTOMERID = ?";
	/**
	 * @generated
	 */
	private static final String _loadString =
		"SELECT T1.CUSTOMERID, T1.FIRSTNAME, T1.LASTNAME, T1.TITLE FROM CUSTOMER  T1 WHERE T1.CUSTOMERID = ?";
	/**
	 * @generated
	 */
	private static final String _loadForUpdateString =
		_loadString + " FOR UPDATE";
	/**
	 * @generated
	 */
	private byte[] serObj = null;
	/**
	 * EJSJDBCPersisterCMPCustomerBean_efcc4527
	 * @generated
	 */
	public EJSJDBCPersisterCMPCustomerBean_efcc4527()
		throws java.rmi.RemoteException {
		super();
	}
	/**
	 * postInit
	 * @generated
	 */
	public void postInit() {
	}
	/**
	 * _create
	 * @generated
	 */
	public void _create(EntityBean eb) throws Exception {
		Object objectTemp = null;
		CustomerBean b = (CustomerBean) eb;
		PreparedStatement pstmt;
		pstmt = getPreparedStatement(_createString);
		try {
			objectTemp =
				com
					.ibm
					.vap
					.converters
					.VapTrimStringConverter
					.singleton()
					.dataFrom(
					b.customerid);
			if (objectTemp == null) {
				pstmt.setNull(1, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(1, (java.lang.String) objectTemp);
			}
			Object[] CMPAttribute_6 =
				minibank.ejb.NameComposer.singleton().dataFrom(b.name);
			if (CMPAttribute_6[0] == null) {
				pstmt.setNull(2, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(2, (java.lang.String) CMPAttribute_6[0]);
			}
			if (CMPAttribute_6[1] == null) {
				pstmt.setNull(3, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(3, (java.lang.String) CMPAttribute_6[1]);
			}
			if (CMPAttribute_6[2] == null) {
				pstmt.setNull(4, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(4, (java.lang.String) CMPAttribute_6[2]);
			}
			pstmt.executeUpdate();
		} finally {
			returnPreparedStatement(pstmt);
		}
	}
	/**
	 * hydrate
	 * @generated
	 */
	public void hydrate(EntityBean eb, Object data, Object pKey)
		throws Exception {
		Object objectTemp = null;
		CustomerBean b = (CustomerBean) eb;
		minibank.ejb.CustomerKey _primaryKey = (minibank.ejb.CustomerKey) pKey;
		java.sql.ResultSet resultSet = (java.sql.ResultSet) data;
		b.customerid = _primaryKey.customerid;
		Object[] cCMPAttribute_6 = new Object[3];
		cCMPAttribute_6[0] = resultSet.getString(2);
		cCMPAttribute_6[1] = resultSet.getString(3);
		cCMPAttribute_6[2] = resultSet.getString(4);
		b.name =
			(minibank.ejb.Name) minibank
				.ejb
				.NameComposer
				.singleton()
				.objectFrom(
				cCMPAttribute_6);
	}
	/**
	 * load
	 * @generated
	 */
	public void load(EntityBean eb, Object pKey, boolean forUpdate)
		throws Exception {
		Object objectTemp = null;
		CustomerBean b = (CustomerBean) eb;
		minibank.ejb.CustomerKey _primaryKey = (minibank.ejb.CustomerKey) pKey;
		PreparedStatement pstmt;
		ResultSet resultSet = null;
		pstmt =
			(forUpdate)
				? getPreparedStatement(_loadForUpdateString)
				: getPreparedStatement(_loadString);
		try {
			objectTemp =
				com
					.ibm
					.vap
					.converters
					.VapTrimStringConverter
					.singleton()
					.dataFrom(
					_primaryKey.customerid);
			if (objectTemp == null) {
				pstmt.setNull(1, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(1, (java.lang.String) objectTemp);
			}
			resultSet = pstmt.executeQuery();
			if (!(resultSet.next()))
				throw new javax.ejb.ObjectNotFoundException();
			hydrate(eb, resultSet, pKey);
		} finally {
			if (resultSet != null)
				resultSet.close();
			returnPreparedStatement(pstmt);
		}
	}
	/**
	 * refresh
	 * @generated
	 */
	public void refresh(EntityBean eb, boolean forUpdate) throws Exception {
		CustomerBean b = (CustomerBean) eb;
		minibank.ejb.CustomerKey _primaryKey = new minibank.ejb.CustomerKey();
		_primaryKey.customerid = b.customerid;
		load(b, _primaryKey, forUpdate);
	}
	/**
	 * store
	 * @generated
	 */
	public void store(EntityBean eb) throws Exception {
		Object objectTemp = null;
		CustomerBean b = (CustomerBean) eb;
		minibank.ejb.CustomerKey _primaryKey = new minibank.ejb.CustomerKey();
		_primaryKey.customerid = b.customerid;
		PreparedStatement pstmt;
		pstmt = getPreparedStatement(_storeString);
		try {
			objectTemp =
				com
					.ibm
					.vap
					.converters
					.VapTrimStringConverter
					.singleton()
					.dataFrom(
					_primaryKey.customerid);
			if (objectTemp == null) {
				pstmt.setNull(4, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(4, (java.lang.String) objectTemp);
			}
			Object[] CMPAttribute_6 =
				minibank.ejb.NameComposer.singleton().dataFrom(b.name);
			if (CMPAttribute_6[0] == null) {
				pstmt.setNull(1, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(1, (java.lang.String) CMPAttribute_6[0]);
			}
			if (CMPAttribute_6[1] == null) {
				pstmt.setNull(2, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(2, (java.lang.String) CMPAttribute_6[1]);
			}
			if (CMPAttribute_6[2] == null) {
				pstmt.setNull(3, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(3, (java.lang.String) CMPAttribute_6[2]);
			}
			pstmt.executeUpdate();
		} finally {
			returnPreparedStatement(pstmt);
		}
	}
	/**
	 * remove
	 * @generated
	 */
	public void remove(EntityBean eb) throws Exception {
		Object objectTemp = null;
		CustomerBean b = (CustomerBean) eb;
		minibank.ejb.CustomerKey _primaryKey = new minibank.ejb.CustomerKey();
		_primaryKey.customerid = b.customerid;
		PreparedStatement pstmt;
		pstmt = getPreparedStatement(_removeString);
		try {
			objectTemp =
				com
					.ibm
					.vap
					.converters
					.VapTrimStringConverter
					.singleton()
					.dataFrom(
					_primaryKey.customerid);
			if (objectTemp == null) {
				pstmt.setNull(1, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(1, (java.lang.String) objectTemp);
			}
			pstmt.executeUpdate();
		} finally {
			returnPreparedStatement(pstmt);
		}
	}
	/**
	 * getPrimaryKey
	 * @generated
	 */
	public Object getPrimaryKey(Object data) throws Exception {
		minibank.ejb.CustomerKey key = new minibank.ejb.CustomerKey();
		java.sql.ResultSet resultSet = (java.sql.ResultSet) data;

		if (resultSet != null) {
			Object objectTemp = null;
			key.customerid =
				(java.lang.String) com
					.ibm
					.vap
					.converters
					.VapTrimStringConverter
					.singleton()
					.objectFrom(resultSet.getString(1));
			return key;
		}
		return null;
	}
	/**
	 * findByPrimaryKey
	 * @generated
	 */
	public minibank.ejb.Customer findByPrimaryKey(
		minibank.ejb.CustomerKey primaryKey)
		throws java.rmi.RemoteException, javax.ejb.FinderException {
		return (minibank.ejb.Customer) home.activateBean(primaryKey);
	}
}

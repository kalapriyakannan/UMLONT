package minibank.ejb;
import com.ibm.ejs.container.*;
import javax.ejb.*;
import java.rmi.RemoteException;
/**
 * EJSRemoteCMPCurrency_c84cba23
 * @generated
 */
public class EJSRemoteCMPCurrency_c84cba23
	extends EJSWrapper
	implements Currency {
	/**
	 * EJSRemoteCMPCurrency_c84cba23
	 * @generated
	 */
	public EJSRemoteCMPCurrency_c84cba23() throws java.rmi.RemoteException {
		super();
	}
	/**
	 * getName
	 * @generated
	 */
	public java.lang.String getName() throws java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = new EJSDeployedSupport();
		java.lang.String _EJS_result = null;
		try {
			minibank.ejb.CurrencyBean beanRef =
				(minibank.ejb.CurrencyBean) container.preInvoke(
					this,
					0,
					_EJS_s);
			_EJS_result = beanRef.getName();
		} catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		} catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new RemoteException(
				"bean method raised unchecked exception",
				ex);
		} finally {
			container.postInvoke(this, 0, _EJS_s);
		}
		return _EJS_result;
	}
	/**
	 * getCurrencyData
	 * @generated
	 */
	public minibank.ejb.CurrencyData getCurrencyData()
		throws java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = new EJSDeployedSupport();
		minibank.ejb.CurrencyData _EJS_result = null;
		try {
			minibank.ejb.CurrencyBean beanRef =
				(minibank.ejb.CurrencyBean) container.preInvoke(
					this,
					1,
					_EJS_s);
			_EJS_result = beanRef.getCurrencyData();
		} catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		} catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new RemoteException(
				"bean method raised unchecked exception",
				ex);
		} finally {
			container.postInvoke(this, 1, _EJS_s);
		}
		return _EJS_result;
	}
	/**
	 * syncCurrencyData
	 * @generated
	 */
	public minibank.ejb.CurrencyData syncCurrencyData(
		minibank.ejb.CurrencyData data)
		throws java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = new EJSDeployedSupport();
		minibank.ejb.CurrencyData _EJS_result = null;
		try {
			minibank.ejb.CurrencyBean beanRef =
				(minibank.ejb.CurrencyBean) container.preInvoke(
					this,
					2,
					_EJS_s);
			_EJS_result = beanRef.syncCurrencyData(data);
		} catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		} catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new RemoteException(
				"bean method raised unchecked exception",
				ex);
		} finally {
			container.postInvoke(this, 2, _EJS_s);
		}
		return _EJS_result;
	}
	/**
	 * setCurrencyData
	 * @generated
	 */
	public void setCurrencyData(minibank.ejb.CurrencyData data)
		throws
			java.rmi.RemoteException,
			com.ibm.etools.ejb.client.runtime.FieldChangedException {
		EJSDeployedSupport _EJS_s = new EJSDeployedSupport();

		try {
			minibank.ejb.CurrencyBean beanRef =
				(minibank.ejb.CurrencyBean) container.preInvoke(
					this,
					3,
					_EJS_s);
			beanRef.setCurrencyData(data);
		} catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		} catch (com.ibm.etools.ejb.client.runtime.FieldChangedException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		} catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new RemoteException(
				"bean method raised unchecked exception",
				ex);
		} finally {
			container.postInvoke(this, 3, _EJS_s);
		}
		return;
	}
	/**
	 * setName
	 * @generated
	 */
	public void setName(java.lang.String newName)
		throws java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = new EJSDeployedSupport();

		try {
			minibank.ejb.CurrencyBean beanRef =
				(minibank.ejb.CurrencyBean) container.preInvoke(
					this,
					4,
					_EJS_s);
			beanRef.setName(newName);
		} catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		} catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new RemoteException(
				"bean method raised unchecked exception",
				ex);
		} finally {
			container.postInvoke(this, 4, _EJS_s);
		}
		return;
	}
}

package minibank.ejb;
/**
 * EJSRemoteCMPCurrency
 * @generated
 */
public class EJSRemoteCMPCurrency
	extends minibank.ejb.EJSRemoteCMPCurrency_c84cba23
	implements Currency {
	/**
	 * EJSRemoteCMPCurrency
	 * @generated
	 */
	public EJSRemoteCMPCurrency() throws java.rmi.RemoteException {
		super();
	}
}

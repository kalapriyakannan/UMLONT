package minibank.ejb;
import javax.ejb.*;
import java.rmi.RemoteException;
import javax.naming.NamingException;
import com.ibm.etools.ejb.client.runtime.*;
/**
 * CurrencyFactory
 * @generated
 */
public class CurrencyFactory extends AbstractEJBFactory {
	/**
	 * CurrencyFactory
	 * @generated
	 */
	public CurrencyFactory() {
		super();
	}
	/**
	 * _acquireCurrencyHome
	 * @generated
	 */
	protected minibank.ejb.CurrencyHome _acquireCurrencyHome() throws java.rmi.RemoteException {
		return (minibank.ejb.CurrencyHome) _acquireEJBHome();
	}
	/**
	 * acquireCurrencyHome
	 * @generated
	 */
	public minibank.ejb.CurrencyHome acquireCurrencyHome() throws javax.naming.NamingException {
		return (minibank.ejb.CurrencyHome) acquireEJBHome();
	}
	/**
	 * getDefaultJNDIName
	 * @generated
	 */
	public String getDefaultJNDIName() {
		return "minibank/ejb/Currency";
	}
	/**
	 * getHomeInterface
	 * @generated
	 */
	protected Class getHomeInterface() {
		return minibank.ejb.CurrencyHome.class;
	}
	/**
	 * resetCurrencyHome
	 * @generated
	 */
	public void resetCurrencyHome() {
		resetEJBHome();
	}
	/**
	 * setCurrencyHome
	 * @generated
	 */
	public void setCurrencyHome(minibank.ejb.CurrencyHome home) {
		setEJBHome(home);
	}
	/**
	 * create
	 * @generated
	 */
	public minibank.ejb.Currency create(int currencyId) throws CreateException, RemoteException {
		return _acquireCurrencyHome().create(currencyId);
	}
	/**
	 * findByPrimaryKey
	 * @generated
	 */
	public minibank.ejb.Currency findByPrimaryKey(minibank.ejb.CurrencyKey primaryKey) throws FinderException, RemoteException {
		return _acquireCurrencyHome().findByPrimaryKey(primaryKey);
	}
}

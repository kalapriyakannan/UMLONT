package minibank.ejb;
import com.ibm.ejs.container.*;
import com.ibm.ejs.persistence.*;
import com.ibm.ejs.EJSException;
import javax.ejb.*;
import java.rmi.RemoteException;
/**
 * EJSCMPBankaccountHomeBean_89e03fc6
 * @generated
 */
public class EJSCMPBankaccountHomeBean_89e03fc6 extends EJSHome {
	/**
	 * EJSCMPBankaccountHomeBean_89e03fc6
	 * @generated
	 */
	public EJSCMPBankaccountHomeBean_89e03fc6()
		throws java.rmi.RemoteException {
		super();
	}
	/**
	 * findByPrimaryKey
	 * @generated
	 */
	public minibank.ejb.Bankaccount findByPrimaryKey(
		minibank.ejb.BankaccountKey primaryKey)
		throws javax.ejb.FinderException, java.rmi.RemoteException {
		return (
			(
				minibank
					.ejb
					.EJSJDBCPersisterCMPBankaccountBean_89e03fc6) persister)
					.findByPrimaryKey(
			primaryKey);
	}
	/**
	 * findByCustomerID
	 * @generated
	 */
	public minibank.ejb.Bankaccount findByCustomerID(int id)
		throws java.rmi.RemoteException, javax.ejb.FinderException {
		return (
			(
				minibank
					.ejb
					.EJSJDBCPersisterCMPBankaccountBean_89e03fc6) persister)
					.findByCustomerID(
			id);
	}
	/**
	 * create
	 * @generated
	 */
	public minibank.ejb.Bankaccount create(java.lang.String accountid)
		throws javax.ejb.CreateException, java.rmi.RemoteException {
		BeanO beanO = null;
		minibank.ejb.Bankaccount _EJS_result = null;
		boolean createFailed = false;
		try {
			beanO = super.createBeanO();
			minibank.ejb.BankaccountBean bean =
				(minibank.ejb.BankaccountBean) beanO.getEnterpriseBean();
			bean.ejbCreate(accountid);
			_EJS_result =
				(minibank.ejb.Bankaccount) super.postCreate(
					beanO,
					keyFromBean(bean));
			bean.ejbPostCreate(accountid);
		} catch (javax.ejb.CreateException ex) {
			createFailed = true;
			throw ex;
		} catch (java.rmi.RemoteException ex) {
			createFailed = true;
			throw ex;
		} catch (Throwable ex) {
			createFailed = true;
			throw new CreateFailureException(ex);
		} finally {
			if (createFailed) {
				super.createFailure(beanO);
			}
		}
		return _EJS_result;
	}
	/**
	 * keyFromBean
	 * @generated
	 */
	public Object keyFromBean(javax.ejb.EntityBean generalEJB) {
		minibank.ejb.BankaccountBean tmpEJB =
			(minibank.ejb.BankaccountBean) generalEJB;
		minibank.ejb.BankaccountKey keyClass =
			new minibank.ejb.BankaccountKey();
		keyClass.accountid = tmpEJB.accountid;
		return keyClass;
	}
	/**
	 * keyFromFields
	 * @generated
	 */
	public minibank.ejb.BankaccountKey keyFromFields(java.lang.String f0) {
		minibank.ejb.BankaccountKey keyClass =
			new minibank.ejb.BankaccountKey();
		keyClass.accountid = f0;
		return keyClass;
	}
}

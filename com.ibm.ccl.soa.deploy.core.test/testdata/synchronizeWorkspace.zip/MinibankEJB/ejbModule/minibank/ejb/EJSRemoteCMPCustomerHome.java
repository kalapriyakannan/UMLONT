package minibank.ejb;
/**
 * EJSRemoteCMPCustomerHome
 * @generated
 */
public class EJSRemoteCMPCustomerHome
	extends minibank.ejb.EJSRemoteCMPCustomerHome_efcc4527
	implements minibank.ejb.CustomerHome {
	/**
	 * EJSRemoteCMPCustomerHome
	 * @generated
	 */
	public EJSRemoteCMPCustomerHome() throws java.rmi.RemoteException {
		super();
	}
}

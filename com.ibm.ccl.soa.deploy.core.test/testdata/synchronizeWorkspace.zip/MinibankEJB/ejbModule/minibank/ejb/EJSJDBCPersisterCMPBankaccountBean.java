package minibank.ejb;
/**
 * EJSJDBCPersisterCMPBankaccountBean
 * @generated
 */
public class EJSJDBCPersisterCMPBankaccountBean
	extends minibank.ejb.EJSJDBCPersisterCMPBankaccountBean_89e03fc6 {
	/**
	 * EJSJDBCPersisterCMPBankaccountBean
	 * @generated
	 */
	public EJSJDBCPersisterCMPBankaccountBean()
		throws java.rmi.RemoteException {
		super();
	}
}

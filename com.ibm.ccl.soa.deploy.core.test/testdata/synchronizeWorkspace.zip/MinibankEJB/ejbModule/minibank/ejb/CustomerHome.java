package minibank.ejb;
/**
 * Home interface for Enterprise Bean: Customer
 */
public interface CustomerHome extends javax.ejb.EJBHome {
	/**
	 * Creates an instance from a key for Entity Bean: Customer
	 */
	public minibank.ejb.Customer create(java.lang.String customerid) throws javax.ejb.CreateException, java.rmi.RemoteException;
	/**
	 * Finds an instance using a key for Entity Bean: Customer
	 */
	public minibank.ejb.Customer findByPrimaryKey(minibank.ejb.CustomerKey primaryKey) throws javax.ejb.FinderException, java.rmi.RemoteException;
}

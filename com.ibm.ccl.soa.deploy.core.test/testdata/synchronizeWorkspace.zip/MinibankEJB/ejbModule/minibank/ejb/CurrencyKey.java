package minibank.ejb;
/**
 * Key class for Entity Bean: Currency
 */
public class CurrencyKey implements java.io.Serializable {
	static final long serialVersionUID = 3206093459760846163L;
	/**
	 * Implemetation field for persistent attribute: currencyId
	 */
	public int currencyId;
	/**
	 * Creates an empty key for Entity Bean: Currency
	 */
	public CurrencyKey() {
	}
	/**
	 * Creates a key for Entity Bean: Currency
	 */
	public CurrencyKey(int currencyId) {
		this.currencyId = currencyId;
	}
	/**
	 * Returns true if both keys are equal.
	 */
	public boolean equals(java.lang.Object otherKey) {
		if (otherKey instanceof minibank.ejb.CurrencyKey) {
			minibank.ejb.CurrencyKey o = (minibank.ejb.CurrencyKey)otherKey;
			return ((this.currencyId == o.currencyId));
		}
		return false;
	}
	/**
	 * Returns the hash code for the key.
	 */
	public int hashCode() {
		return ((new java.lang.Integer(currencyId).hashCode()));
	}
}

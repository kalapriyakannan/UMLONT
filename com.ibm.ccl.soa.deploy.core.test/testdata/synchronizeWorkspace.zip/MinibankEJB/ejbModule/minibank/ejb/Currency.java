package minibank.ejb;
/**
 * Remote interface for Enterprise Bean: Currency
 */
public interface Currency extends javax.ejb.EJBObject {
	/**
	 * Get accessor for persistent attribute: name
	 */
	public java.lang.String getName() throws java.rmi.RemoteException;
	/**
	 * Set accessor for persistent attribute: name
	 */
	public void setName(java.lang.String newName) throws java.rmi.RemoteException;
	/**
	 * getCurrencyData
	 */
	public minibank.ejb.CurrencyData getCurrencyData() throws java.rmi.RemoteException;
	/**
	 * setCurrencyData
	 */
	public void setCurrencyData(minibank.ejb.CurrencyData data) throws java.rmi.RemoteException, com.ibm.etools.ejb.client.runtime.FieldChangedException;
	/**
	 * syncCurrencyData
	 */
	public minibank.ejb.CurrencyData syncCurrencyData(minibank.ejb.CurrencyData data) throws java.rmi.RemoteException;
}

package minibank.ejb;
import com.ibm.ejs.persistence.*;
import javax.ejb.EntityBean;
import java.sql.*;
import java.text.*;
import com.ibm.vap.converters.*;
import com.ibm.vap.converters.streams.*;
/**
 * EJSJDBCPersisterCMPBankaccountBean_89e03fc6
 * @generated
 */
public class EJSJDBCPersisterCMPBankaccountBean_89e03fc6
	extends EJSJDBCPersister
	implements minibank.ejb.EJSFinderBankaccountBean {
	/**
	 * @generated
	 */
	private static final String _createString =
		"INSERT INTO BANKACCOUNT (ACCOUNTID, BALANCE) VALUES (?, ?)";
	/**
	 * @generated
	 */
	private static final String _removeString =
		"DELETE FROM BANKACCOUNT  WHERE ACCOUNTID = ?";
	/**
	 * @generated
	 */
	private static final String _storeString =
		"UPDATE BANKACCOUNT  SET BALANCE = ? WHERE ACCOUNTID = ?";
	/**
	 * @generated
	 */
	private static final String _loadString =
		"SELECT T1.BALANCE, T1.ACCOUNTID FROM BANKACCOUNT  T1 WHERE T1.ACCOUNTID = ?";
	/**
	 * @generated
	 */
	private static final String _loadForUpdateString =
		_loadString + " FOR UPDATE";
	/**
	 * @generated
	 */
	private byte[] serObj = null;
	/**
	 * EJSJDBCPersisterCMPBankaccountBean_89e03fc6
	 * @generated
	 */
	public EJSJDBCPersisterCMPBankaccountBean_89e03fc6()
		throws java.rmi.RemoteException {
		super();
	}
	/**
	 * postInit
	 * @generated
	 */
	public void postInit() {
	}
	/**
	 * _create
	 * @generated
	 */
	public void _create(EntityBean eb) throws Exception {
		Object objectTemp = null;
		BankaccountBean b = (BankaccountBean) eb;
		PreparedStatement pstmt;
		pstmt = getPreparedStatement(_createString);
		try {
			if (b.balance == null) {
				pstmt.setNull(2, java.sql.Types.DECIMAL);
			} else {
				pstmt.setBigDecimal(2, b.balance);
			}
			objectTemp =
				com
					.ibm
					.vap
					.converters
					.VapTrimStringConverter
					.singleton()
					.dataFrom(
					b.accountid);
			if (objectTemp == null) {
				pstmt.setNull(1, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(1, (java.lang.String) objectTemp);
			}
			pstmt.executeUpdate();
		} finally {
			returnPreparedStatement(pstmt);
		}
	}
	/**
	 * hydrate
	 * @generated
	 */
	public void hydrate(EntityBean eb, Object data, Object pKey)
		throws Exception {
		Object objectTemp = null;
		BankaccountBean b = (BankaccountBean) eb;
		minibank.ejb.BankaccountKey _primaryKey =
			(minibank.ejb.BankaccountKey) pKey;
		java.sql.ResultSet resultSet = (java.sql.ResultSet) data;
		b.accountid = _primaryKey.accountid;
		b.balance = resultSet.getBigDecimal(1);
	}
	/**
	 * load
	 * @generated
	 */
	public void load(EntityBean eb, Object pKey, boolean forUpdate)
		throws Exception {
		Object objectTemp = null;
		BankaccountBean b = (BankaccountBean) eb;
		minibank.ejb.BankaccountKey _primaryKey =
			(minibank.ejb.BankaccountKey) pKey;
		PreparedStatement pstmt;
		ResultSet resultSet = null;
		pstmt =
			(forUpdate)
				? getPreparedStatement(_loadForUpdateString)
				: getPreparedStatement(_loadString);
		try {
			objectTemp =
				com
					.ibm
					.vap
					.converters
					.VapTrimStringConverter
					.singleton()
					.dataFrom(
					_primaryKey.accountid);
			if (objectTemp == null) {
				pstmt.setNull(1, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(1, (java.lang.String) objectTemp);
			}
			resultSet = pstmt.executeQuery();
			if (!(resultSet.next()))
				throw new javax.ejb.ObjectNotFoundException();
			hydrate(eb, resultSet, pKey);
		} finally {
			if (resultSet != null)
				resultSet.close();
			returnPreparedStatement(pstmt);
		}
	}
	/**
	 * refresh
	 * @generated
	 */
	public void refresh(EntityBean eb, boolean forUpdate) throws Exception {
		BankaccountBean b = (BankaccountBean) eb;
		minibank.ejb.BankaccountKey _primaryKey =
			new minibank.ejb.BankaccountKey();
		_primaryKey.accountid = b.accountid;
		load(b, _primaryKey, forUpdate);
	}
	/**
	 * store
	 * @generated
	 */
	public void store(EntityBean eb) throws Exception {
		Object objectTemp = null;
		BankaccountBean b = (BankaccountBean) eb;
		minibank.ejb.BankaccountKey _primaryKey =
			new minibank.ejb.BankaccountKey();
		_primaryKey.accountid = b.accountid;
		PreparedStatement pstmt;
		pstmt = getPreparedStatement(_storeString);
		try {
			objectTemp =
				com
					.ibm
					.vap
					.converters
					.VapTrimStringConverter
					.singleton()
					.dataFrom(
					_primaryKey.accountid);
			if (objectTemp == null) {
				pstmt.setNull(2, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(2, (java.lang.String) objectTemp);
			}
			if (b.balance == null) {
				pstmt.setNull(1, java.sql.Types.DECIMAL);
			} else {
				pstmt.setBigDecimal(1, b.balance);
			}
			pstmt.executeUpdate();
		} finally {
			returnPreparedStatement(pstmt);
		}
	}
	/**
	 * remove
	 * @generated
	 */
	public void remove(EntityBean eb) throws Exception {
		Object objectTemp = null;
		BankaccountBean b = (BankaccountBean) eb;
		minibank.ejb.BankaccountKey _primaryKey =
			new minibank.ejb.BankaccountKey();
		_primaryKey.accountid = b.accountid;
		PreparedStatement pstmt;
		pstmt = getPreparedStatement(_removeString);
		try {
			objectTemp =
				com
					.ibm
					.vap
					.converters
					.VapTrimStringConverter
					.singleton()
					.dataFrom(
					_primaryKey.accountid);
			if (objectTemp == null) {
				pstmt.setNull(1, java.sql.Types.VARCHAR);
			} else {
				pstmt.setString(1, (java.lang.String) objectTemp);
			}
			pstmt.executeUpdate();
		} finally {
			returnPreparedStatement(pstmt);
		}
	}
	/**
	 * getPrimaryKey
	 * @generated
	 */
	public Object getPrimaryKey(Object data) throws Exception {
		minibank.ejb.BankaccountKey key = new minibank.ejb.BankaccountKey();
		java.sql.ResultSet resultSet = (java.sql.ResultSet) data;

		if (resultSet != null) {
			Object objectTemp = null;
			key.accountid =
				(java.lang.String) com
					.ibm
					.vap
					.converters
					.VapTrimStringConverter
					.singleton()
					.objectFrom(resultSet.getString(2));
			return key;
		}
		return null;
	}
	/**
	 * findByPrimaryKey
	 * @generated
	 */
	public minibank.ejb.Bankaccount findByPrimaryKey(
		minibank.ejb.BankaccountKey primaryKey)
		throws java.rmi.RemoteException, javax.ejb.FinderException {
		return (minibank.ejb.Bankaccount) home.activateBean(primaryKey);
	}
	/**
	 * findByCustomerID
	 * @generated
	 */
	public minibank.ejb.Bankaccount findByCustomerID(int id)
		throws javax.ejb.FinderException, java.rmi.RemoteException {
		ResultSet resultSet = null;
		PreparedStatement pstmt = null;
		minibank.ejb.Bankaccount result = null;

		EJSJDBCFinder tmpFinder = null;
		try {
			preFind();
			pstmt =
				getPreparedStatement("SELECT T1.BALANCE, T1.ACCOUNTID FROM BANKACCOUNT  T1 WHERE T1.Customer_customerid = ?");
			pstmt.setInt(1, id);
			resultSet = pstmt.executeQuery();
			tmpFinder = new EJSJDBCFinder(resultSet, this, pstmt);
			if (tmpFinder.hasMoreElements()) {
				result = (minibank.ejb.Bankaccount) tmpFinder.nextElement();
			}
		} catch (Exception ex) {
			throw new EJSPersistenceException("find failed:", ex);
		} finally {
			if (tmpFinder != null)
				tmpFinder.close();
		}
		if (result == null) {
			throw new javax.ejb.ObjectNotFoundException();
		}
		return result;
	}
}

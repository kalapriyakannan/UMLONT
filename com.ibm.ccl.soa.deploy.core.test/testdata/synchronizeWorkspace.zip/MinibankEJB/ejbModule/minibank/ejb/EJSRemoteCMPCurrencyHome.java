package minibank.ejb;
/**
 * EJSRemoteCMPCurrencyHome
 * @generated
 */
public class EJSRemoteCMPCurrencyHome
	extends minibank.ejb.EJSRemoteCMPCurrencyHome_c84cba23
	implements minibank.ejb.CurrencyHome {
	/**
	 * EJSRemoteCMPCurrencyHome
	 * @generated
	 */
	public EJSRemoteCMPCurrencyHome() throws java.rmi.RemoteException {
		super();
	}
}

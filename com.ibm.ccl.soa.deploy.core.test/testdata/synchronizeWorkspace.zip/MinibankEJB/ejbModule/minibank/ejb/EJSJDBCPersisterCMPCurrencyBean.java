package minibank.ejb;
/**
 * EJSJDBCPersisterCMPCurrencyBean
 * @generated
 */
public class EJSJDBCPersisterCMPCurrencyBean
	extends minibank.ejb.EJSJDBCPersisterCMPCurrencyBean_c84cba23 {
	/**
	 * EJSJDBCPersisterCMPCurrencyBean
	 * @generated
	 */
	public EJSJDBCPersisterCMPCurrencyBean() throws java.rmi.RemoteException {
		super();
	}
}

package minibank.ejb;
import com.ibm.ejs.persistence.EJSFinder;
import javax.ejb.FinderException;
import java.rmi.RemoteException;
/**
 * EJSFinderCurrencyBean
 * @generated
 */
public interface EJSFinderCurrencyBean {
}

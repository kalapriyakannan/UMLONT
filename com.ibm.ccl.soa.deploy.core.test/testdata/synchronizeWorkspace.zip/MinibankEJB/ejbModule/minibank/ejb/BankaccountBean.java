package minibank.ejb;
/**
 * Bean implementation class for Enterprise Bean: Bankaccount
 */
public class BankaccountBean implements javax.ejb.EntityBean, minibank.ejb.BankaccountData.Store {



	private javax.ejb.EntityContext myEntityCtx;
	/**
	 * Implemetation field for persistent attribute: balance
	 */
	public java.math.BigDecimal balance;
	/**
	 * Implemetation field for persistent attribute: accountid
	 */
	public java.lang.String accountid;
	/**
	 * getEntityContext
	 */
	public javax.ejb.EntityContext getEntityContext() {
		return myEntityCtx;
	}
	/**
	 * setEntityContext
	 */
	public void setEntityContext(javax.ejb.EntityContext ctx) {
		myEntityCtx = ctx;
	}
	/**
	 * unsetEntityContext
	 */
	public void unsetEntityContext() {
		myEntityCtx = null;
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbCreate method for a CMP entity bean.
	 */
	public minibank.ejb.BankaccountKey ejbCreate(java.lang.String accountid) throws javax.ejb.CreateException {
		_initLinks();
		this.accountid = accountid;
		return null;
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(java.lang.String accountid) throws javax.ejb.CreateException {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
	}
	/**
	 * This method was generated for supporting the associations.
	 */
	protected void _initLinks() {
	}
	/**
	 * This method was generated for supporting the associations.
	 */
	protected java.util.Vector _getLinks() {
		java.util.Vector links = new java.util.Vector();
		return links;
	}
	/**
	 * This method was generated for supporting the associations.
	 */
	protected void _removeLinks() throws java.rmi.RemoteException, javax.ejb.RemoveException {
		java.util.List links = _getLinks();
		for (int i = 0; i < links.size() ; i++) {
			try {
				((com.ibm.ivj.ejb.associations.interfaces.Link) links.get(i)).remove();
			} catch (javax.ejb.FinderException e) {} //Consume Finder error since I am going away
		}
	}
	/**
	 * Get accessor for persistent attribute: balance
	 */
	public java.math.BigDecimal getBalance() {
		return balance;
	}
	/**
	 * Set accessor for persistent attribute: balance
	 */
	public void setBalance(java.math.BigDecimal newBalance) {
		balance = newBalance;
	}
	/**
	 * getBankaccountData
	 */
	public minibank.ejb.BankaccountData getBankaccountData() {
		return new minibank.ejb.BankaccountData(this);
	}
	/**
	 * setBankaccountData
	 */
	public void setBankaccountData(minibank.ejb.BankaccountData data) throws com.ibm.etools.ejb.client.runtime.FieldChangedException {
		data.copyTo(this);
		if ( !data.getIsbalanceDirty() ) {
			if ( this.getBalance() != null && data.getBalance() != null ) {
				if ( !this.getBalance().equals(data.getBalance()) )
					throw new com.ibm.etools.ejb.client.runtime.FieldChangedException();
			}
		}
	}
	/**
	 * syncBankaccountData
	 */
	public minibank.ejb.BankaccountData syncBankaccountData(minibank.ejb.BankaccountData data) {
		data.copyTo(this);
		return this.getBankaccountData();
	}
	/**
	 * getPrimaryKey
	 */
	public Object getPrimaryKey() {
		return getEntityContext().getPrimaryKey();
	}
}

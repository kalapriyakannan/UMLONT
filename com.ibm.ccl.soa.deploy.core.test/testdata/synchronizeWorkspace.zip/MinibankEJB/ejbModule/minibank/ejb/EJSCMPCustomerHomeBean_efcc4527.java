package minibank.ejb;
import com.ibm.ejs.container.*;
import com.ibm.ejs.persistence.*;
import com.ibm.ejs.EJSException;
import javax.ejb.*;
import java.rmi.RemoteException;
/**
 * EJSCMPCustomerHomeBean_efcc4527
 * @generated
 */
public class EJSCMPCustomerHomeBean_efcc4527 extends EJSHome {
	/**
	 * EJSCMPCustomerHomeBean_efcc4527
	 * @generated
	 */
	public EJSCMPCustomerHomeBean_efcc4527() throws java.rmi.RemoteException {
		super();
	}
	/**
	 * findByPrimaryKey
	 * @generated
	 */
	public minibank.ejb.Customer findByPrimaryKey(
		minibank.ejb.CustomerKey primaryKey)
		throws javax.ejb.FinderException, java.rmi.RemoteException {
		return (
			(
				minibank
					.ejb
					.EJSJDBCPersisterCMPCustomerBean_efcc4527) persister)
					.findByPrimaryKey(
			primaryKey);
	}
	/**
	 * create
	 * @generated
	 */
	public minibank.ejb.Customer create(java.lang.String customerid)
		throws javax.ejb.CreateException, java.rmi.RemoteException {
		BeanO beanO = null;
		minibank.ejb.Customer _EJS_result = null;
		boolean createFailed = false;
		try {
			beanO = super.createBeanO();
			minibank.ejb.CustomerBean bean =
				(minibank.ejb.CustomerBean) beanO.getEnterpriseBean();
			bean.ejbCreate(customerid);
			_EJS_result =
				(minibank.ejb.Customer) super.postCreate(
					beanO,
					keyFromBean(bean));
			bean.ejbPostCreate(customerid);
		} catch (javax.ejb.CreateException ex) {
			createFailed = true;
			throw ex;
		} catch (java.rmi.RemoteException ex) {
			createFailed = true;
			throw ex;
		} catch (Throwable ex) {
			createFailed = true;
			throw new CreateFailureException(ex);
		} finally {
			if (createFailed) {
				super.createFailure(beanO);
			}
		}
		return _EJS_result;
	}
	/**
	 * keyFromBean
	 * @generated
	 */
	public Object keyFromBean(javax.ejb.EntityBean generalEJB) {
		minibank.ejb.CustomerBean tmpEJB =
			(minibank.ejb.CustomerBean) generalEJB;
		minibank.ejb.CustomerKey keyClass = new minibank.ejb.CustomerKey();
		keyClass.customerid = tmpEJB.customerid;
		return keyClass;
	}
	/**
	 * keyFromFields
	 * @generated
	 */
	public minibank.ejb.CustomerKey keyFromFields(java.lang.String f0) {
		minibank.ejb.CustomerKey keyClass = new minibank.ejb.CustomerKey();
		keyClass.customerid = f0;
		return keyClass;
	}
}

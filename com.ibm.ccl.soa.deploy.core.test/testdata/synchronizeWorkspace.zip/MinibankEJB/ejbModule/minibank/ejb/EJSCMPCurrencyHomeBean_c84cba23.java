package minibank.ejb;
import com.ibm.ejs.container.*;
import com.ibm.ejs.persistence.*;
import com.ibm.ejs.EJSException;
import javax.ejb.*;
import java.rmi.RemoteException;
/**
 * EJSCMPCurrencyHomeBean_c84cba23
 * @generated
 */
public class EJSCMPCurrencyHomeBean_c84cba23 extends EJSHome {
	/**
	 * EJSCMPCurrencyHomeBean_c84cba23
	 * @generated
	 */
	public EJSCMPCurrencyHomeBean_c84cba23() throws java.rmi.RemoteException {
		super();
	}
	/**
	 * create
	 * @generated
	 */
	public minibank.ejb.Currency create(int currencyId)
		throws javax.ejb.CreateException, java.rmi.RemoteException {
		BeanO beanO = null;
		minibank.ejb.Currency _EJS_result = null;
		boolean createFailed = false;
		try {
			beanO = super.createBeanO();
			minibank.ejb.CurrencyBean bean =
				(minibank.ejb.CurrencyBean) beanO.getEnterpriseBean();
			bean.ejbCreate(currencyId);
			_EJS_result =
				(minibank.ejb.Currency) super.postCreate(
					beanO,
					keyFromBean(bean));
			bean.ejbPostCreate(currencyId);
		} catch (javax.ejb.CreateException ex) {
			createFailed = true;
			throw ex;
		} catch (java.rmi.RemoteException ex) {
			createFailed = true;
			throw ex;
		} catch (Throwable ex) {
			createFailed = true;
			throw new CreateFailureException(ex);
		} finally {
			if (createFailed) {
				super.createFailure(beanO);
			}
		}
		return _EJS_result;
	}
	/**
	 * findByPrimaryKey
	 * @generated
	 */
	public minibank.ejb.Currency findByPrimaryKey(
		minibank.ejb.CurrencyKey primaryKey)
		throws javax.ejb.FinderException, java.rmi.RemoteException {
		return (
			(
				minibank
					.ejb
					.EJSJDBCPersisterCMPCurrencyBean_c84cba23) persister)
					.findByPrimaryKey(
			primaryKey);
	}
	/**
	 * keyFromBean
	 * @generated
	 */
	public Object keyFromBean(javax.ejb.EntityBean generalEJB) {
		minibank.ejb.CurrencyBean tmpEJB =
			(minibank.ejb.CurrencyBean) generalEJB;
		minibank.ejb.CurrencyKey keyClass = new minibank.ejb.CurrencyKey();
		keyClass.currencyId = tmpEJB.currencyId;
		return keyClass;
	}
	/**
	 * keyFromFields
	 * @generated
	 */
	public minibank.ejb.CurrencyKey keyFromFields(int f0) {
		minibank.ejb.CurrencyKey keyClass = new minibank.ejb.CurrencyKey();
		keyClass.currencyId = f0;
		return keyClass;
	}
}

//	Licensed Material - Property of IBM
//	(C) Copyright IBM Corp. 2006 - All Rights Reserved.
//	US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

var en_US = new Array();
en_US['TITLE'] = 'Common Base Event XML Viewer';
en_US['Time'] = 'Time';
en_US['LANG'] = 'English';
en_US['HELP'] = 'The Common Base Event XML Viewer displays several Common Base Event properties from Common Base Event XML documents in a tabular view.  Select the column header for an explanation of the Common Base Event property in that column.  The viewer also provides column-level sorting and hierarchal filtering (see Preferences).';
en_US['help#'] = 'The zero-based integer position of this Common Base Event XML fragment in the Common Base Event XML document.';
en_US['helpTime'] = 'The XSD dateTime creationTime attribute of this Common Base Event XML fragment in the Common Base Event XML document.';
en_US['helpSeverity'] = 'The integer severity attribute (0 - 70) of this Common Base Event XML fragment in the Common Base Event XML document.  The cells in this column use a colored gradient to denote increasing severity (0 or pink to 70 or red).';
en_US['helpMessage'] = 'The textual message attribute of this Common Base Event XML fragment in the Common Base Event XML document.';
en_US['helpSituation'] = 'The textual categoryName attribute of the situation element of this Common Base Event XML fragment in the Common Base Event XML document.';
en_US['helpComponent'] = 'The textual component attribute of the sourceComponentId element of this Common Base Event XML fragment in the Common Base Event XML document.';
en_US['helpLogger'] = 'The textual name of the logger that logged this Common Base Event XML fragment based on the extendedDataElement with a Logger_Name or CommonBaseEventLogRecord:loggerName name attribute in this Common Base Event XML fragment in the Common Base Event XML document.';
en_US['helpLogLevel'] = 'The textual name of the logging level of the logger that logged this Common Base Event XML fragment based on the extendedDataElement with a Logging_Level or CommonBaseEventLogRecord:level name attribute in this Common Base Event XML fragment in the Common Base Event XML document.';
en_US['XML Viewer Preferences'] = 'Common Base Event XML Viewer Preferences';
en_US['Severity'] = 'Severity';
en_US['Message'] = 'Message';
en_US['Situation'] = 'Situation';
en_US['Component'] = 'Component';
en_US['Logger'] = 'Logger';
en_US['Log Level'] = 'Log Level';
en_US['Preferences'] = 'Preferences';
en_US['Help'] = 'Help';
en_US['Sorting Order'] = 'Sorting Order'; 
en_US['Increasing'] = 'Increasing';
en_US['Decreasing'] = 'Decreasing';
en_US['Logger'] = 'Logger';
en_US['Filtering Rules'] = 'Filtering Rules';
en_US['any string'] = 'any string';
en_US['Add'] = 'Add'
en_US['Help'] = 'Help';
en_US['Save'] = 'Save';
en_US['Cancel'] = 'Cancel';
en_US['Include'] = 'Include';
en_US['Exclude'] = 'Exclude';
en_US['Remove'] = 'Remove';

//
//"This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own
//instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
//or for redistribution by customer, as part of such an application, in customer's own products. " 
//
//Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001,2002
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereclient;

import java.awt.*;
import javax.swing.JTabbedPane;
import javax.swing.JTextPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.*;
import java.util.*;
import java.text.DateFormat;
import com.ibm.websphere.samples.plantsbywebsphereejb.*;

/**
 * Main form for the Sample
 */
public class PBWSMain extends JFrame
{
    
    // Used for addNotify check.
    boolean fComponentsAdjusted = false;

    // Declare our controls for our UI
	javax.swing.JPanel pnlMain = new javax.swing.JPanel();
	javax.swing.JTabbedPane tabMain = new javax.swing.JTabbedPane();
	javax.swing.JPanel pnlCatalog = new javax.swing.JPanel();
	javax.swing.JPanel pnlCatButtonsLeft = new javax.swing.JPanel();
	javax.swing.JButton btnCatAdd = new javax.swing.JButton();
	javax.swing.JButton btnCatView = new javax.swing.JButton();
	javax.swing.JButton btnCatDelete = new javax.swing.JButton();
	javax.swing.JButton btnCatEmail = new javax.swing.JButton();
	javax.swing.JPanel pnlCatButtonsBottomFill = new javax.swing.JPanel();
	javax.swing.JLabel lblCatMainTable = new javax.swing.JLabel();
	javax.swing.JScrollPane sclCatMain = new javax.swing.JScrollPane();
	javax.swing.JTable tblCatMain = new javax.swing.JTable();
	javax.swing.JPanel pnlInventory = new javax.swing.JPanel();
	javax.swing.JTabbedPane tabInventory = new javax.swing.JTabbedPane();
	javax.swing.JPanel pnlInvUnassigned = new javax.swing.JPanel();
	javax.swing.JScrollPane sclInvItemsUnassigned = new javax.swing.JScrollPane();
	javax.swing.JTable tblInvItemsUnassigned = new javax.swing.JTable();
	javax.swing.JPanel pnlInvUnassignedTop = new javax.swing.JPanel();
	javax.swing.JLabel lblInvCategories = new javax.swing.JLabel();
	javax.swing.JComboBox cmbInvCategories = new javax.swing.JComboBox();
	javax.swing.JPanel pnlInvUnassignedBtm = new javax.swing.JPanel();
	javax.swing.JLabel lblInvUnasignedPsn = new javax.swing.JLabel();
	javax.swing.JComboBox cmbInvPersonnel = new javax.swing.JComboBox();
	javax.swing.JButton btnInvAssign = new javax.swing.JButton();
	javax.swing.JPanel pnlInvAssigned = new javax.swing.JPanel();
	javax.swing.JComboBox cmbInvUnPersonnel = new javax.swing.JComboBox();
	javax.swing.JLabel lblInvUnPersonnel = new javax.swing.JLabel();
	javax.swing.JScrollPane sclInvItemsAssigned = new javax.swing.JScrollPane();
	javax.swing.JTable tblInvItemsAssigned = new javax.swing.JTable();
	javax.swing.JPanel pnlInvAssignedBtm = new javax.swing.JPanel();
	javax.swing.JButton btnInvUnassign = new javax.swing.JButton();
	javax.swing.JButton btnInvComplete = new javax.swing.JButton();
	javax.swing.JPanel pnlReports = new javax.swing.JPanel();
	javax.swing.JLabel lblReports = new javax.swing.JLabel();
	javax.swing.JList lstReports = new javax.swing.JList();
	javax.swing.JButton btnReportView = new javax.swing.JButton();
	javax.swing.JPanel pnlReportFilters = new javax.swing.JPanel();
	javax.swing.JPanel pnlReportDateRange = new javax.swing.JPanel();
	javax.swing.JLabel lblRptDateRange = new javax.swing.JLabel();
	javax.swing.JPanel pnlRptDRFrom = new javax.swing.JPanel();
	javax.swing.JLabel lblRptFromDate = new javax.swing.JLabel();
	javax.swing.JTextField txtRptFromDate = new javax.swing.JTextField();
	javax.swing.JLabel lblRptToDate = new javax.swing.JLabel();
	javax.swing.JTextField txtRptToDate = new javax.swing.JTextField();
	javax.swing.JPanel pnlReportQuantity = new javax.swing.JPanel();
	javax.swing.JLabel lblRptLimits = new javax.swing.JLabel();
	javax.swing.JPanel pnlRptRows = new javax.swing.JPanel();
	javax.swing.JLabel lblRptRowsRtn = new javax.swing.JLabel();
	javax.swing.JTextField txtRptRowsRtn = new javax.swing.JTextField();
	javax.swing.JPanel pnlReportFill = new javax.swing.JPanel();
	javax.swing.JPanel pnlReportBot = new javax.swing.JPanel();
	javax.swing.JLabel lblRptFileName = new javax.swing.JLabel();
	javax.swing.JTextField txtRptFileName = new javax.swing.JTextField();
	javax.swing.JButton btnExit = new javax.swing.JButton();

    PBWSCatalogTableModel tblmdlCatalog = new PBWSCatalogTableModel();
    PBWSCatalogTableModel tblmdlInvItemsUnassigned = new PBWSCatalogTableModel();
    PBWSCatalogTableModel tblmdlInvItemsAssigned = new PBWSCatalogTableModel();
    
    /**
     * Default constructor.  Initializes the controls and registers listeners.
     */
    public PBWSMain()
    {
        // Initialize all controls
        setTitle("Plants by WebSphere - Catalog Manager");
        setDefaultCloseOperation(javax.swing.JFrame.DO_NOTHING_ON_CLOSE);
        getContentPane().setLayout(new GridLayout(1,1,0,0));
        setSize(405,305);
        setVisible(false);
        pnlMain.setLayout(new GridBagLayout());
        getContentPane().add(pnlMain);
        pnlMain.add(tabMain, new GridBagConstraints(0,0,1,1,1.0,1.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.BOTH,new Insets(5,5,5,5),0,0));
        pnlCatalog.setLayout(new GridBagLayout());
        tabMain.add(pnlCatalog);
        pnlCatalog.setBounds(2,24,390,238);
        pnlCatalog.setVisible(false);
        pnlCatButtonsLeft.setLayout(new GridBagLayout());
        pnlCatalog.add(pnlCatButtonsLeft, new GridBagConstraints(0,1,1,1,0.0,1.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.BOTH,new Insets(0,0,0,10),0,0));
        btnCatAdd.setText("Add New");
        btnCatAdd.setActionCommand("Add New");
		btnCatAdd.setMnemonic((int)'A');
        pnlCatButtonsLeft.add(btnCatAdd, new GridBagConstraints(0,0,1,1,1.0,0.0,java.awt.GridBagConstraints.NORTHEAST,java.awt.GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
        btnCatView.setText("View or Update");
        btnCatView.setActionCommand("View or Update");
		btnCatView.setMnemonic((int)'V');
        pnlCatButtonsLeft.add(btnCatView, new GridBagConstraints(0,1,1,1,1.0,0.0,java.awt.GridBagConstraints.EAST,java.awt.GridBagConstraints.BOTH,new Insets(0,0,1,0),0,0));
        btnCatDelete.setText("Delete");
        btnCatDelete.setActionCommand("Delete");
		btnCatDelete.setMnemonic((int)'D');
        pnlCatButtonsLeft.add(btnCatDelete, new GridBagConstraints(0,2,1,1,1.0,0.0,java.awt.GridBagConstraints.EAST,java.awt.GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
        btnCatEmail.setText("EMail");
        btnCatEmail.setActionCommand("EMail");
		btnCatEmail.setMnemonic((int)'E');
        pnlCatButtonsLeft.add(btnCatEmail, new GridBagConstraints(0,4,1,1,1.0,0.0,java.awt.GridBagConstraints.EAST,java.awt.GridBagConstraints.BOTH,new Insets(25,0,0,0),0,0));
        pnlCatButtonsBottomFill.setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
        pnlCatButtonsLeft.add(pnlCatButtonsBottomFill, new GridBagConstraints(0,5,1,1,1.0,1.0,java.awt.GridBagConstraints.SOUTH,java.awt.GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
        lblCatMainTable.setText("Catalog Items:");
        pnlCatalog.add(lblCatMainTable, new GridBagConstraints(1,0,0,1,0.0,0.0,java.awt.GridBagConstraints.SOUTHWEST,java.awt.GridBagConstraints.NONE,new Insets(5,0,0,0),0,0));
        sclCatMain.setOpaque(true);
        pnlCatalog.add(sclCatMain, new GridBagConstraints(1,1,1,1,1.0,1.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.BOTH,new Insets(0,0,5,5),0,0));
        tblCatMain.setGridColor(new java.awt.Color(153,153,153));
        sclCatMain.getViewport().add(tblCatMain);
        tblCatMain.setBounds(0,0,251,0);
        
        pnlInventory.setAlignmentY(0.495935F);
        pnlInventory.setLayout(new BoxLayout(pnlInventory,BoxLayout.X_AXIS));
        tabMain.add(pnlInventory);
        pnlInventory.setBounds(2,24,390,238);
        pnlInventory.setVisible(false);
        pnlInventory.add(tabInventory);
        pnlInvUnassigned.setLayout(new GridBagLayout());
        tabInventory.add(pnlInvUnassigned);
        pnlInvUnassigned.setBounds(2,24,385,211);
        pnlInvUnassigned.setVisible(false);
        sclInvItemsUnassigned.setOpaque(true);
        pnlInvUnassigned.add(sclInvItemsUnassigned, new GridBagConstraints(0,1,1,1,1.0,1.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.BOTH,new Insets(5,5,0,0),0,0));
        tblInvItemsUnassigned.setGridColor(new java.awt.Color(153,153,153));
        sclInvItemsUnassigned.getViewport().add(tblInvItemsUnassigned);
        tblInvItemsUnassigned.setBounds(0,0,377,0);
        pnlInvUnassignedTop.setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
        pnlInvUnassigned.add(pnlInvUnassignedTop, new GridBagConstraints(0,0,1,1,0.0,0.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.NONE,new Insets(0,0,0,0),0,0));
        lblInvCategories.setText("Category Filter:");
        pnlInvUnassignedTop.add(lblInvCategories);
        cmbInvCategories.setLightWeightPopupEnabled(false);
        pnlInvUnassignedTop.add(cmbInvCategories);
        pnlInvUnassignedBtm.setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
        pnlInvUnassigned.add(pnlInvUnassignedBtm, new GridBagConstraints(0,2,1,1,0.0,0.0,java.awt.GridBagConstraints.SOUTHWEST,java.awt.GridBagConstraints.NONE,new Insets(0,0,0,0),0,0));
        lblInvUnasignedPsn.setText("Assign to:");
        pnlInvUnassignedBtm.add(lblInvUnasignedPsn);
        pnlInvUnassignedBtm.add(cmbInvPersonnel);
        btnInvAssign.setText("Assign");
        btnInvAssign.setActionCommand("Assign");
		btnInvAssign.setMnemonic((int)'A');
        pnlInvUnassignedBtm.add(btnInvAssign);
        pnlInvAssigned.setLayout(new GridBagLayout());
        tabInventory.add(pnlInvAssigned);
        pnlInvAssigned.setBounds(2,24,385,211);
        pnlInvAssigned.setVisible(false);
        lblInvUnPersonnel.setText("Personnel:");
        pnlInvAssigned.add(lblInvUnPersonnel, new GridBagConstraints(0,0,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlInvAssigned.add(cmbInvUnPersonnel, new GridBagConstraints(1,0,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        sclInvItemsAssigned.setOpaque(true);
        pnlInvAssigned.add(sclInvItemsAssigned, new GridBagConstraints(0,1,2,1,1.0,1.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.BOTH,new Insets(5,5,0,0),0,0));
        tblInvItemsAssigned.setGridColor(new java.awt.Color(153,153,153));
        sclInvItemsAssigned.getViewport().add(tblInvItemsAssigned);
        tblInvItemsAssigned.setBounds(0,0,377,0);
        pnlInvAssignedBtm.setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
        pnlInvAssigned.add(pnlInvAssignedBtm, new GridBagConstraints(0,2,2,1,0.0,0.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));
        btnInvUnassign.setText("Unassign");
        btnInvUnassign.setActionCommand("Unassign");
		btnInvUnassign.setMnemonic((int)'U');
        pnlInvAssignedBtm.add(btnInvUnassign);
        btnInvComplete.setText("Complete");
        btnInvComplete.setActionCommand("Complete");
		btnInvComplete.setMnemonic((int)'C');
        pnlInvAssignedBtm.add(btnInvComplete);
        tabInventory.setSelectedIndex(0);
        tabInventory.setSelectedComponent(pnlInvUnassigned);
        tabInventory.setTitleAt(0,"Unassigned Items");
        tabInventory.setTitleAt(1,"Assigned Items");
        
        pnlReports.setLayout(new GridBagLayout());
        tabMain.add(pnlReports);
        pnlReports.setBounds(2,24,390,238);
        pnlReports.setVisible(false);
        pnlReportFilters.setLayout(new GridBagLayout());
        pnlReports.add(pnlReportFilters,new java.awt.GridBagConstraints(1,1,1,1,0.0,1.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.VERTICAL,new Insets(5,5,0,0),0,0));

		pnlReportDateRange.setLayout(new GridBagLayout());
		pnlReportFilters.add(pnlReportDateRange,new java.awt.GridBagConstraints(0,0,1,1,0.0,0.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));
		lblRptDateRange.setText("Date Range:");
		pnlReportDateRange.add(lblRptDateRange,new java.awt.GridBagConstraints(0,0,1,1,1.0,1.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
		pnlRptDRFrom.setLayout(new GridBagLayout());
		pnlReportDateRange.add(pnlRptDRFrom,new java.awt.GridBagConstraints(0,1,1,1,1.0,1.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.BOTH,new Insets(5,5,0,0),27,0));

		lblRptFromDate.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
		lblRptFromDate.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
		lblRptFromDate.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
		lblRptFromDate.setText("From:");
		pnlRptDRFrom.add(lblRptFromDate,new java.awt.GridBagConstraints(0,0,1,1,0.0,0.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.NONE,new Insets(0,0,0,0),2,4));
		pnlRptDRFrom.add(txtRptFromDate,new java.awt.GridBagConstraints(1,0,1,1,1.0,0.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),50,0));

		lblRptToDate.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
		lblRptToDate.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
		lblRptToDate.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
		lblRptToDate.setText("To:");
		pnlRptDRFrom.add(lblRptToDate,new java.awt.GridBagConstraints(0,1,1,1,0.0,0.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.NONE,new Insets(0,0,0,0),17,4));
		pnlRptDRFrom.add(txtRptToDate,new java.awt.GridBagConstraints(1,1,1,1,1.0,0.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),50,0));
		
		pnlReportQuantity.setLayout(new GridBagLayout());
		pnlReportFilters.add(pnlReportQuantity,new java.awt.GridBagConstraints(0,1,1,1,0.0,0.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.NONE,new Insets(5,0,0,0),0,0));
		lblRptLimits.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
		lblRptLimits.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
		lblRptLimits.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
		lblRptLimits.setText("Report Limits:");
		pnlReportQuantity.add(lblRptLimits,new java.awt.GridBagConstraints(0,0,1,1,1.0,1.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
		pnlRptRows.setLayout(new GridBagLayout());
		pnlReportQuantity.add(pnlRptRows,new java.awt.GridBagConstraints(0,1,1,1,1.0,1.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.BOTH,new Insets(5,5,0,0),0,0));
		lblRptRowsRtn.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
		lblRptRowsRtn.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
		lblRptRowsRtn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
		lblRptRowsRtn.setText("Row Limit:");
		pnlRptRows.add(lblRptRowsRtn, new java.awt.GridBagConstraints(0,0,1,1,0.0,0.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.NONE,new Insets(0,0,0,0),2,4));
		lblRptRowsRtn.setBackground(new java.awt.Color(204,204,204));
		pnlRptRows.add(txtRptRowsRtn, new java.awt.GridBagConstraints(1,0,1,1,1.0,0.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),50,0));
		
		pnlReportFill.setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
		pnlReportFilters.add(pnlReportFill,new java.awt.GridBagConstraints(0,2,1,1,1.0,1.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));

        lblReports.setText("Available Reports:");
        pnlReportFilters.add(lblReports, new java.awt.GridBagConstraints(0,0,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlReportFilters.add(lstReports, new java.awt.GridBagConstraints(0,1,1,1,1.0,1.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.BOTH,new Insets(5,5,0,0),0,0));
        lblReports.setText("Available Reports:");
        pnlReports.add(lblReports, new GridBagConstraints(0,0,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlReports.add(lstReports, new GridBagConstraints(0,1,1,1,1.0,1.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.BOTH,new Insets(5,5,0,0),0,0));


        btnReportView.setText("View Report");
        btnReportView.setActionCommand("View Report");
		btnReportView.setMnemonic((int)'V');
		pnlReportFill.add(btnReportView);
		
		pnlReportBot.setLayout(new GridBagLayout());
		pnlReports.add(pnlReportBot, new java.awt.GridBagConstraints(0,2,2,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.HORIZONTAL,new Insets(5,5,0,0),0,0));

		lblRptFileName.setText("Output Filename:");
		pnlReportBot.add(lblRptFileName,new java.awt.GridBagConstraints(0,0,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
		pnlReportBot.add(txtRptFileName,new java.awt.GridBagConstraints(1,0,1,2,1.0,1.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.HORIZONTAL,new Insets(0,5,0,0),0,0));

        tabMain.setSelectedIndex(0);
        tabMain.setSelectedComponent(pnlCatalog);
        tabMain.setTitleAt(0,"Catalog Management");
        tabMain.setTitleAt(1,"Inventory Management");
        tabMain.setTitleAt(2,"Reports");

        btnExit.setText("Exit");
        btnExit.setActionCommand("Exit");
		btnExit.setMnemonic((int)'X');
        pnlMain.add(btnExit, new GridBagConstraints(0,1,1,1,0.0,0.0,java.awt.GridBagConstraints.SOUTHWEST,java.awt.GridBagConstraints.NONE,new Insets(0,5,5,0),0,0));
		
        tblCatMain.setModel(tblmdlCatalog);
        tblInvItemsUnassigned.setModel(tblmdlInvItemsUnassigned);
        tblInvItemsAssigned.setModel(tblmdlInvItemsAssigned);

        // Register Listeners
        PBWSWindow aPBWSWindow = new PBWSWindow();
        this.addWindowListener(aPBWSWindow);
        PBWSAction lPBWSAction = new PBWSAction();
        btnExit.addActionListener(lPBWSAction);
        btnCatAdd.addActionListener(lPBWSAction);
        btnCatView.addActionListener(lPBWSAction);
        btnCatDelete.addActionListener(lPBWSAction);
        btnCatEmail.addActionListener(lPBWSAction);
        PBWSMouse aPBWSMouse = new PBWSMouse();
        tblCatMain.addMouseListener(aPBWSMouse);
		btnInvAssign.addActionListener(lPBWSAction);
		btnInvUnassign.addActionListener(lPBWSAction);
		btnInvComplete.addActionListener(lPBWSAction);
		PBWSItem lPBWSItem = new PBWSItem();
		cmbInvCategories.addItemListener(lPBWSItem);
		cmbInvUnPersonnel.addItemListener(lPBWSItem);
		btnReportView.addActionListener(lPBWSAction);
    }
    
    public PBWSMain(String title)
    {
        this();
        setTitle(title);
    }
    
    /**
     * Shows or hides the component depending on the boolean flag b.
     * @param b  if true, show the component; otherwise, hide the component.
     * @see java.awt.Component#isVisible
     */
    public void setVisible(boolean b)
    {
        if(b)
        {
            // Center me
            Dimension fd = getSize();
            Dimension sd = Toolkit.getDefaultToolkit().getScreenSize();

            int x = sd.width/2 - fd.width/2;
            int y = sd.height/2 - fd.height/2;
            setLocation(x>0 ? x : 0, y>0 ? y : 0);

            // Fill our text boxes with the available information.
            fillMainUI();
            
        }   
        super.setVisible(b);
    }
    
    /**
     * Fill in the various text fields in our user interface.
     */
    public void fillMainUI()
    {
        // Catalog Tab
        fillMainCatalog();
        
        Vector vCategories = PBWSBusinessObjects.getCategories();        
        for (Enumeration e = vCategories.elements();e.hasMoreElements();) {
            cmbInvCategories.addItem(((Category)e.nextElement()).m_catName);
        }
        
        
        // Inventory Tab
        
        String[] astrInvPersonnel = PBWSBusinessObjects.getInvPersonnel();
        for(int i=0;i<astrInvPersonnel.length;i++) {
            cmbInvPersonnel.addItem(astrInvPersonnel[i]);            
        }
        
        for(int i=0;i<astrInvPersonnel.length;i++) {
            cmbInvUnPersonnel.addItem(astrInvPersonnel[i]);            
        }
        
        // Reports Tab
        // All of the reports are essentially hard-coded.
        lstReports.setListData(new String[] 
            {PBWSBusinessObjects.Report_TopSellersForDates,
             PBWSBusinessObjects.Report_TopSellingZipsForDates});
        
        // Fill-in the report default information
        // Use the first day of this year for the FROM date
        // Use the current date for the TO date.
        DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);
        Calendar cal = df.getCalendar();
        cal.set(0,0,1);
        txtRptFromDate.setText(df.format(cal.getTime()));
        txtRptToDate.setText(df.format(new Date()));
        txtRptRowsRtn.setText("100");
        txtRptFileName.setText(PBWSConfig.getUserProperty(PBWSConfig.USERPROP_LASTREPORTFILE, ""));
    }
    
    /**
     * Entry point for the application.
     * @params args[] arguments for the application
     */
    static public void main(String args[])
    {
        try
        {
            // Configure user option defaults if not set.
            if (PBWSConfig.getUserProperty(PBWSConfig.USERPROP_DEFAULTFROMADDR, "NOTSET") == "NOTSET") {
                PBWSUtility.createDefaultConfig();
            }
            
            // Setup the look and feel
            setupLookAndFeel();

            // Initialize our Business Objects
            PBWSBusinessObjects.init();
            
            //Create a new instance of our application's frame, and make it visible.
            (new PBWSMain()).setVisible(true);
        }
        catch (Throwable t)
        {
            System.err.println(t);
            t.printStackTrace();
            //Ensure the application exits with an error condition.
            System.exit(1);
        }
    }

	/**
	 * Fill or refill the main catalog table.
	 */
	private void fillMainCatalog() {
		try {
			Catalog catalog = PBWSBusinessObjects.getCatalog();

	        Vector vItems = catalog.getItems();
	        
	        tblmdlCatalog.clearAllRows();
	        for(Enumeration e = vItems.elements();e.hasMoreElements();) {
	        	StoreItem curItem = (StoreItem)e.nextElement();
	        	tblmdlCatalog.addRow(curItem.getID(),curItem.getName(), curItem.getDescription(), PBWSBusinessObjects.getCategoryNameFromID(curItem.getCategory()));
	        }
	        
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

    /**
     * Update an item in the catalog table to the current value in the EJB.
     */
    private void updateMainCatalogItem(String itemID) {
		try {
			Catalog catalog = PBWSBusinessObjects.getCatalog();

	        StoreItem curItem = catalog.getItem(itemID);
            
            tblmdlCatalog.updateRow(curItem.getID(),curItem.getName(), curItem.getDescription(), PBWSBusinessObjects.getCategoryNameFromID(curItem.getCategory()));
	        
		} catch (Throwable e) {
			e.printStackTrace();
		}
    }
    
    /**
     * Add an item to the catalog from the current value in the EJB.
     */
    private void addMainCatalogItem(String itemID) {
		try {
			Catalog catalog = PBWSBusinessObjects.getCatalog();

	        StoreItem curItem = catalog.getItem(itemID);
            
            tblmdlCatalog.addRow(curItem.getID(),curItem.getName(), curItem.getDescription(), PBWSBusinessObjects.getCategoryNameFromID(curItem.getCategory()));
	        
		} catch (Throwable e) {
			e.printStackTrace();
		}
    }

	/**
	 * Fill or refill the table of assigned items for the given
	 * person.
	 */
	private void fillAssignedItems(String person) {
		Vector vItems = PBWSBusinessObjects.getAssignedInvItemsByPerson(person);

		tblmdlInvItemsAssigned.clearAllRows();			 
		if(vItems != null) {
			for(Enumeration e = vItems.elements();e.hasMoreElements();) {
				PBWSInvItemMsg itemMsg = (PBWSInvItemMsg) e.nextElement();
				StoreItem catItem = PBWSBusinessObjects.getCatalogItem(itemMsg.m_itemID);
				if(catItem != null) {
					tblmdlInvItemsAssigned.addRow(catItem.getID(), 
					                              catItem.getName(), 
					                              catItem.getDescription(), 
					                              PBWSBusinessObjects.getCategoryNameFromID(catItem.getCategory()));
				}
			}
		}
	}

	/**
	 * Fill or refill the table of unassigned items for the given 
	 * category id
	 */
	private void fillUnassignedItems(int categoryID) {
		Vector vItems = PBWSBusinessObjects.getUnassignedInvItemsByCategory(categoryID);
		
		tblmdlInvItemsUnassigned.clearAllRows();			 
		if(vItems != null) {
			for(Enumeration e = vItems.elements();e.hasMoreElements();) {
				PBWSInvItemMsg itemMsg = (PBWSInvItemMsg) e.nextElement();
				StoreItem catItem = PBWSBusinessObjects.getCatalogItem(itemMsg.m_itemID);
				if(catItem != null) {
					tblmdlInvItemsUnassigned.addRow(catItem.getID(), 
					                                catItem.getName(), 
					                                catItem.getDescription(), 
					                                PBWSBusinessObjects.getCategoryNameFromID(catItem.getCategory()));
				}
			}
		}
	}

    static void setupLookAndFeel() {
        String osName = System.getProperty("os.name");
        try {
            if (osName != null && osName.startsWith("Windows")) {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } else {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            }        
        }
        catch(Throwable e){
            e.printStackTrace();
        }
    }

    
    public void addNotify()
    {
        // Record the size of the window prior to calling parents addNotify.
        Dimension d = getSize();
        
        super.addNotify();
    
        if (fComponentsAdjusted)
            return;
    
        // Adjust components according to the insets
        setSize(getInsets().left + getInsets().right + d.width, getInsets().top + getInsets().bottom + d.height);
        Component components[] = getComponents();
        for (int i = 0; i < components.length; i++)
        {
            Point p = components[i].getLocation();
            p.translate(getInsets().left, getInsets().top);
            components[i].setLocation(p);
        }
        fComponentsAdjusted = true;
    }

    class PBWSAction implements java.awt.event.ActionListener
    {
        public void actionPerformed(java.awt.event.ActionEvent event)
        {
            Object object = event.getSource();
            if (object == btnExit)
                btnExit_actionPerformed(event);
            else if (object == btnCatAdd)
                btnCatAdd_actionPerformed(event);
            else if (object == btnCatView)
                btnCatView_actionPerformed(event);
            else if (object == btnCatDelete)
                btnCatDelete_actionPerformed(event);
            else if (object == btnCatEmail)
                btnCatEmail_actionPerformed(event);
			else if (object == btnInvAssign)
				btnInvAssign_actionPerformed(event);
			else if (object == btnInvUnassign)
				btnInvUnassign_actionPerformed(event);
			else if (object == btnInvComplete)
				btnInvComplete_actionPerformed(event);
			else if (object == btnReportView)
				btnReportView_actionPerformed(event);
        }
    }
    
    //****************************
    //*** App-level Events     ***
    //****************************
    class PBWSWindow extends java.awt.event.WindowAdapter
    {
        public void windowClosing(java.awt.event.WindowEvent event)
        {
            Object object = event.getSource();
            if (object == PBWSMain.this)
                PBWSMain_WindowClosing(event);
        }
    }
    
    void PBWSMain_WindowClosing(java.awt.event.WindowEvent event)
    {
        exitApp();
    }

    void btnExit_actionPerformed(java.awt.event.ActionEvent event)
    {
        exitApp();
    }

    /**
     * Exit the application with confirmation.
     */
    void exitApp() {
        try {
            // Show a confirmation window.
            if (JOptionPane.showConfirmDialog(this, "Do you really want to quit?", 
                   "Exit application", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
	            this.dispose();             // Free system resources
		        System.exit(0);             // close the application
            }
            //(new PBWSQuitDialog(this, true)).setVisible(true);
        } 
        catch (Exception e) {
        }
    }

    //****************************
    //*** Category Tab Events  ***
    //****************************

	/**
	 * Add a new Catalog Item to the database
	 */
    void btnCatAdd_actionPerformed(java.awt.event.ActionEvent event)
    {
		// Add a new inventory item
        PBWSInventoryItem invWindow = new PBWSInventoryItem(this);
        
        invWindow.init(PBWSInventoryItem.WINDOWTYPE_ADD,"");
        invWindow.setVisible(true);
        
        // If an item was added, refresh our catalog list and our list of 
        // unassigned items
        if(!invWindow.isCancelled()) {
	        String itemID = invWindow.getLastItemID();
	        if (itemID.compareTo("") != 0) {
	            addMainCatalogItem(itemID);
	        }
        }
    }

    /**
     * View the selected catalog item in detail.
     */
    void btnCatView_actionPerformed(java.awt.event.ActionEvent event)
    {
        PBWSInventoryItem invWindow = new PBWSInventoryItem(this);
        
        int iSelCatItem = tblCatMain.getSelectedRow();
        if (iSelCatItem != -1) {
            // Show the inventory window in update mode with the selected item.
            invWindow.setModal(true);
            invWindow.init(PBWSInventoryItem.WINDOWTYPE_UPDATE, (String)tblmdlCatalog.getValueAt(iSelCatItem, PBWSCatalogTableModel.COL_ITEM));
            invWindow.setVisible(true);
    
            // If the user updated the item, get the item's ID and update
            // the UI.
            if(!invWindow.isCancelled()) {
	            String itemID = invWindow.getLastItemID();
	            if (itemID.compareTo("") != 0) {
	                updateMainCatalogItem(itemID);
	            }
            }
        }
    }

	/**
	 * Delete a Catalog Item from the database and from the 
	 * appropriate UI screen.
	 */
    void btnCatDelete_actionPerformed(java.awt.event.ActionEvent event)
    {
        int iSelCatItem = tblCatMain.getSelectedRow();
        if (iSelCatItem != -1) {
        	try {
	        	Catalog catalog = PBWSBusinessObjects.getCatalog();
	        	String itemID = (String)tblmdlCatalog.getValueAt(iSelCatItem, PBWSCatalogTableModel.COL_ITEM);
	        	if(catalog.deleteItem(itemID)) {
	        		tblmdlCatalog.removeRow(iSelCatItem);
	        		PBWSBusinessObjects.clearInventoryQueueforItem(itemID);
	        	}
        	} catch(Throwable ex) {
        		ex.printStackTrace();
        	}
        }
             
    }

	/**
	 * Email the selected catalog items to someone.
	 */
    void btnCatEmail_actionPerformed(java.awt.event.ActionEvent event)
    {
		try {
			// Create the PBWSEmail with owner and show as modal initializing
			// with the currently selected catalog items.
			{
			    int iRows[] = tblCatMain.getSelectedRows();
			    Vector vItemIDs = new Vector(iRows.length);
			    for(int i=0;i<iRows.length;i++) {
	        	    vItemIDs.add((String)tblmdlCatalog.getValueAt(iRows[i], PBWSCatalogTableModel.COL_ITEM));
			    }
			    
				PBWSEmail emailWindow = new PBWSEmail(this);
				emailWindow.setModal(true);
				emailWindow.init(vItemIDs);
				emailWindow.setVisible(true);
			}
		} catch (java.lang.Exception e) {
		}
	}

    class PBWSMouse extends java.awt.event.MouseAdapter
    {
        public void mouseClicked(java.awt.event.MouseEvent event)
        {
            Object object = event.getSource();
            if (object == tblCatMain)
                tblCatMain_mouseClicked(event);
        }
    }

	/**
	 * Double-Clicking on a Catalog Item is the same as clicking the
	 * View button.
	 */
    void tblCatMain_mouseClicked(java.awt.event.MouseEvent event)
    {
        if (event.getClickCount() == 2) {
            btnCatView_actionPerformed(null);
        }
             
    }

    //****************************
    //*** Inventory Tab Events ***
    //****************************
	class PBWSItem implements java.awt.event.ItemListener
	{
		public void itemStateChanged(java.awt.event.ItemEvent event)
		{
			Object object = event.getSource();
			if (object == cmbInvCategories)
				cmbInvCategories_itemStateChanged(event);
			else if (object == cmbInvUnPersonnel)
				cmbInvUnPersonnel_itemStateChanged(event);
		}
	}

	/**
	 * Refresh/Filter the unassigned inventory items as the category changes. 
	 */
	void cmbInvCategories_itemStateChanged(java.awt.event.ItemEvent event)
	{
		if (event.getStateChange() == java.awt.event.ItemEvent.SELECTED) {
			fillUnassignedItems(PBWSBusinessObjects.getCatIdFromName((String)cmbInvCategories.getSelectedItem()));
		}
	}

	/**
	 * Refresh/Filter the assigned inventory items as the Person changes
	 */
	void cmbInvUnPersonnel_itemStateChanged(java.awt.event.ItemEvent event)
	{
		if (event.getStateChange() == java.awt.event.ItemEvent.SELECTED) {
			fillAssignedItems((String)cmbInvUnPersonnel.getSelectedItem());
		}
	}

	/**
	 * Assign the selected inventory item to the selected person.
	 */
	void btnInvAssign_actionPerformed(java.awt.event.ActionEvent event)
	{
        int iSelCatalogItem = tblInvItemsUnassigned.getSelectedRow();
		javax.swing.table.TableModel mdl = tblInvItemsUnassigned.getModel();        
		
        if (iSelCatalogItem != -1) {
        	String itemID = (String)mdl.getValueAt(iSelCatalogItem, PBWSCatalogTableModel.COL_ITEM);
        	String strPerson = (String)cmbInvPersonnel.getSelectedItem();
			boolean bAssigned = PBWSBusinessObjects.assignInvItemToPerson(itemID,strPerson);
			if(bAssigned) {
				// Remove it from the Unassigned table and refresh the assignment table if needed.
				tblmdlInvItemsUnassigned.removeRow(iSelCatalogItem);
				
				if((String)cmbInvUnPersonnel.getSelectedItem() == strPerson) {
					fillAssignedItems(strPerson);
				}
			}
        }
	}

	/**
	 * Unassign the selected inventory item from whomever it is assigned to.
	 */
	void btnInvUnassign_actionPerformed(java.awt.event.ActionEvent event)
	{
        int iSelCatalogItem = tblInvItemsAssigned.getSelectedRow();

        if (iSelCatalogItem != -1) {
        	String itemID = (String)tblmdlInvItemsAssigned.getValueAt(iSelCatalogItem, PBWSCatalogTableModel.COL_ITEM);
        	String category = (String)tblmdlInvItemsAssigned.getValueAt(iSelCatalogItem, PBWSCatalogTableModel.COL_CATEGORY);
			boolean bUnassigned = PBWSBusinessObjects.unassignInvItem(itemID);
			if(bUnassigned) {
				// Remove it from the Assigned table and refresh the unassigned table if needed.
				tblmdlInvItemsAssigned.removeRow(iSelCatalogItem);
				
				if(cmbInvCategories.getSelectedItem() == category) {
					fillUnassignedItems(PBWSBusinessObjects.getCatIdFromName(category));
				}
			}
        }			 
	}

	void btnInvComplete_actionPerformed(java.awt.event.ActionEvent event)
	{
        int iSelCatalogItem = tblInvItemsAssigned.getSelectedRow();

        if (iSelCatalogItem != -1) {
        	String itemID = (String)tblmdlInvItemsAssigned.getValueAt(iSelCatalogItem, PBWSCatalogTableModel.COL_ITEM);
        	String category = (String)tblmdlInvItemsAssigned.getValueAt(iSelCatalogItem, PBWSCatalogTableModel.COL_CATEGORY);
			boolean bUnassigned = PBWSBusinessObjects.completeInvItem(itemID);
			if(bUnassigned) {
				// Remove it from the Assigned table 
				tblmdlInvItemsAssigned.removeRow(iSelCatalogItem);
			}
        }			 
	}

    //****************************
    //*** Report Tab Events    ***
    //****************************
	void btnReportView_actionPerformed(java.awt.event.ActionEvent event)
	{
	    if (lstReports.getSelectedIndex() != -1) {
		    // Validate the input fields.
		    Date fromDate = null;
		    Date toDate = null;
		    int rows = 100;
    		
		    try {
		        if (txtRptFromDate.getText().trim() == "") {
		            Calendar dftBeginDate = Calendar.getInstance();
		            dftBeginDate.set(0,Calendar.JANUARY,1);
		            fromDate = dftBeginDate.getTime();
		        }
		        else {
		            DateFormat fromDF = DateFormat.getDateInstance(DateFormat.SHORT);
		            fromDate = fromDF.parse(txtRptFromDate.getText());
		        }
		    }
		    catch (java.text.ParseException ex) {
                JOptionPane.showMessageDialog(this, "The FROM date is invalid.  Please try again.", "Date format error", JOptionPane.ERROR_MESSAGE);
                return;
		    }
    			 
		    try {
		        if (txtRptToDate.getText().trim() == "") {
		            toDate = Calendar.getInstance().getTime();
		        }
		        else {
		            DateFormat toDF = DateFormat.getDateInstance(DateFormat.SHORT);
		            toDate = toDF.parse(txtRptToDate.getText());
		        }
		    }
		    catch (java.text.ParseException ex) {
                JOptionPane.showMessageDialog(this, "The TO date is invalid.  Please try again.", "Date format error", JOptionPane.ERROR_MESSAGE);
                return;
		    }
    			 
		    try {
		        if (txtRptRowsRtn.getText().trim() == "") {
		            rows = 100;
		        }
		        else {
		            rows= Integer.parseInt(txtRptRowsRtn.getText());
		        }
		    }
		    catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "The ROW LIMIT is invalid.  Please try again.", "Number format error", JOptionPane.ERROR_MESSAGE);
                return;
		    }
    		
		    String outFileName = txtRptFileName.getText().trim();
		    java.io.File outFile = new java.io.File(outFileName);
		    if (outFileName == "") {
                JOptionPane.showMessageDialog(this, "The Report Output File field is invalid.  Please try again.", "Invalid output file", JOptionPane.ERROR_MESSAGE);
                return;
		    }
            
		    // Store the report file name in our config file.
		    PBWSConfig.setUserProperty(PBWSConfig.USERPROP_LASTREPORTFILE, outFileName);

            try {
                PBWSBusinessObjects.runReport(lstReports.getSelectedValue().toString(),fromDate, toDate, rows, outFile);
            }
            catch (java.io.IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Unable to print to Report Output File.  Please verify the filepath.", "File error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            catch (Throwable ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Unable to run report.  Review the stack trace for details.", "Report error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            JOptionPane.showMessageDialog(this, "Your report has been saved to disk.", "Information", JOptionPane.INFORMATION_MESSAGE);
	    }
    }
}


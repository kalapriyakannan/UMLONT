//
//"This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own
//instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
//or for redistribution by customer, as part of such an application, in customer's own products. " 
//
//Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001,2002
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereclient;

import java.io.*;
import java.util.Properties;

/**
 * Configuration class that allows storing user-based properties in their
 * home directory.
 **/
public class PBWSConfig {
    // User property constants
    public final static String USERPROP_DEFAULTFROMADDR= "pbws.email.address.from";
    public final static String USERPROP_LASTFROMADDR= "pbws.email.address.from.lastused";
    public final static String USERPROP_DEFAULTTOADDR= "pbws.email.address.to";
    public final static String USERPROP_DEFAULTMESSAGE= "pbws.email.message";
    public final static String USERPROP_DEFAULTSUBJECT= "pbws.email.subject";
    public final static String USERPROP_LASTREPORTFILE= "pbws.report.filename.lastused";
    
    // Property file constants
    private final static String m_userPropsFileName = "pbws.prop";
    private final static String m_userPropsFileHeader = "PlantsByWebSphere User Properties";
    
    // Private local variables
    private static File m_userPropsFile = null;
    private static Properties m_userProps = new Properties();
    
    /**
     * Retrive a File object which the User Properties are stored.
     * The properties will be stored in the user's home directory.
     **/
    private synchronized static File getUserProperitesFile() {
        if (m_userPropsFile == null) {
            StringBuffer propFileName = new StringBuffer(System.getProperty("user.home"));
            propFileName.append(System.getProperty("file.separator"));
            propFileName.append(m_userPropsFileName);
            m_userPropsFile = new File(propFileName.toString());
        }
        return m_userPropsFile;
    }
    
    /**
     * Retrieve the current user's properties file.
     * @return Properties
     */
    public synchronized static Properties getUserProperties() {
        try {
            File f = getUserProperitesFile();
            if (f.exists()) {
                FileInputStream fs = new FileInputStream(f);
                m_userProps.load(fs);
            }
            return m_userProps;
        }
        catch (Throwable ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    /**
     * Set a property in the current user's personal configuration file.
     * @param String Property to set
     * @param String Value of the property
     * @return String The Value of the property that was set if successful.  Null if unsuccessful.
     */
    public synchronized static String setUserProperty(String key, String value) {
        try {
            Properties p = getUserProperties();
            p.setProperty(key, value);
            
            FileOutputStream fs = new FileOutputStream(getUserProperitesFile());
            p.store(fs, m_userPropsFileHeader);
            return value;
        }
        catch (Throwable ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    /**
     * Retrive a property from the current user's personal configuration file.
     * @param String Property to retrieve
     * @param String Default value to return if the property could not be retrieved.
     * @return String Returns the value of the property or the default value.
     */
    public synchronized static String getUserProperty(String key, String dftValue) {
        Properties p = getUserProperties();
        return p.getProperty(key,dftValue);
        
    }
}
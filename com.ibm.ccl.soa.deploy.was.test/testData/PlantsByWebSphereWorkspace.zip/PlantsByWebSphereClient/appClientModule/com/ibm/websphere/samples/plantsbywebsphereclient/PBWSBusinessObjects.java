//
//"This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own
//instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
//or for redistribution by customer, as part of such an application, in customer's own products. " 
//
//Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001,2002
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereclient;

import java.util.*;
import java.io.*;
import com.ibm.websphere.samples.plantsbywebsphereejb.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.jms.*;
import javax.mail.*;
import javax.mail.internet.*;

/**
 * Layer that retrieves information from the Business Object
 * layer.  
 */
public class PBWSBusinessObjects {
    // Public constants
    
    // Report names
    public final static String Report_TopSellersForDates = new String("Top Selling Items for a Date Range");
    public final static String Report_TopSellingZipsForDates= new String("Top Selling Zip Codes for a Date Range");


    // Private member variables
    private static CatalogHome m_catalogHome = null;
    private static ReportGeneratorHome m_reportGenHome = null;
    private static javax.mail.Session m_mailSession = null;
    private static Vector m_vCategories = null;

	/**
     *  Default Constructor
     */
    public PBWSBusinessObjects() {
		init();
	}
	
    /**
     * Initializes the Business Objects by finding the EJB home objects.
     */
    public static synchronized void init() {
        try {
            if(m_catalogHome == null) {
                m_catalogHome =
                    (CatalogHome) Util.getEJBHome(
                        "java:comp/env/ejb/Catalog",
                        Thread.currentThread().getContextClassLoader().loadClass(
                            "com.ibm.websphere.samples.plantsbywebsphereejb.CatalogHome"));
            }

            if(m_reportGenHome == null) {
                m_reportGenHome =
                    (ReportGeneratorHome) Util.getEJBHome(
                        "java:comp/env/ejb/ReportGenerator",
                        Thread.currentThread().getContextClassLoader().loadClass(
                            "com.ibm.websphere.samples.plantsbywebsphereejb.ReportGeneratorHome"));
            }
            Context ctx = Util.getInitialContext();
            if(m_mailSession == null) {
                m_mailSession = 
                    (javax.mail.Session) ctx.lookup("java:comp/env/mail/InvMailSession");
            }
            
        } catch (ClassNotFoundException e) {
        	e.printStackTrace();
        } catch (NamingException e) {
        	e.printStackTrace();
        }


        // Build the Categories
        if (m_vCategories == null) {
            Vector v = new Vector();
            Category c = new Category(0, "Flowers");
            v.add(c);
            v.add(new Category(1, "Fruits & Vegetables"));
            v.add(new Category(2, "Trees"));
            v.add(new Category(3, "Accessories"));
            m_vCategories = v;
        }
    }

    //************************
    //*****  Category  *******
    //************************


    /**
     * Returns a vector of Category objects for each available category.
     * @return Vector   Vector of Category objects
     */
    public static Vector getCategories() {
        return m_vCategories;
    }

    /**
     * Retrieves the Category ID from a Category Name.  Returns -1 if the Category Name is invalid or does not 
     * exist.
     * @param   String  Category Name
     * @return  int     Category ID or -1
     */
    public static int getCatIdFromName(String catName) {
    	Vector v = getCategories();
    	for(Enumeration e = v.elements();e.hasMoreElements();) {
    		Category c = (Category)e.nextElement();
    		if (c.m_catName.equals(catName)) {
    			return c.m_catID;
    		}
    	}
    	return -1;
    }
    
    /**
     * Retrieves the Category Name from a Category ID.  Returns an empty String if the Category ID is invalid or does not 
     * exist.
     * @param   int     Category ID
     * @return  String  Category Name or Empty String
     */
    public static String getCategoryNameFromID(int catID) {
    	Vector v = getCategories();
    	for(Enumeration e = v.elements();e.hasMoreElements();) {
    		Category c = (Category)e.nextElement();
    		if (c.m_catID == catID) {
    			return c.m_catName;
    		}
    	}
    	return "";
    }

    //************************
    //*****    EMail   *******
    //************************

    /**
     * Send an email to the designated email address.  Send a message as well
     * as information of specific Catalog Items.
     * @param String Email Address of the recipient.
     * @param String Email Address of the sender.
     * @param String Additional message text to send to the recipient.
     * @param Vector Item ID's of the catalog items to send to the recipient.
     * @exception MessagingException
     **/
    public static void sendEmail(String toAddr, String fromAddr, String subject, 
                                 String message, Vector vItemIDs) throws MessagingException {
        try
        {
            // Assemble the email message
	        MimeMessage msg = new MimeMessage(m_mailSession);
	        msg.setRecipient(javax.mail.Message.RecipientType.TO,new InternetAddress(toAddr));
	        msg.setFrom(new InternetAddress(fromAddr));
	        msg.setSubject(subject);
	        
	        // Build the message based on the catalog items and the message
	        // The resulting message will look like:
	        StringBuffer totalMessage = new StringBuffer(message);
	        String lineSep = System.getProperty("line.separator");
	        
	        if (!(vItemIDs == null || vItemIDs.size() == 0)) {
	            totalMessage.append(lineSep);
	            totalMessage.append(lineSep);
	            totalMessage.append("Catalog Items (Item ID, Name, Package, Price):");
	            totalMessage.append(lineSep);
    	        
	            for (Enumeration e = vItemIDs.elements();e.hasMoreElements();) {
	                String curItemID = (String)e.nextElement();
	                StoreItem curItem = PBWSBusinessObjects.getCatalogItem(curItemID);
	                totalMessage.append(curItem.getID());
	                totalMessage.append(", ");
	                totalMessage.append(curItem.getName());
	                totalMessage.append(", ");
	                totalMessage.append(curItem.getPkginfo());
	                totalMessage.append(", ");
	                totalMessage.append(curItem.getPrice());
	                totalMessage.append(lineSep);
	            }
            }	        
	        
	        msg.setText(totalMessage.toString());
	        
	        // Send the message
	        Transport.send(msg);
	        
        } catch (MessagingException ex) {
            
            ex.printStackTrace();
            throw ex;
        }
   
    }

    //************************
    //*****  Inventory *******
    //************************
	
    /**
     * Get a list of Inventory Personnel names.  These are stored
     * in a properties file: pbws.properties.
     * @return String[] An array of user id's.
     */
    public static String[] getInvPersonnel() {
        Properties p = new Properties();
        String result[] = { "" };
        try {
        	
            //p.load(new FileInputStream("pbws.properties"));
            p.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("pbws.properties"));
            result =
                PBWSUtility.readTokens(
                    p.getProperty("com.ibm.websphere.samples.storefront.mgr.invpersonnel"),
                    ",");
        } catch (Throwable ex) {
            ex.printStackTrace();
        }
        return result;
    }
    
	/**
	 * Add a new Unassigned Item to the inventory queue.
     * @param String The Catalog item ID to create.
     * @param String The Category ID of the item.
     * @return boolean True if successful.
	 */
    public static boolean createUnassignedInvItem(String itemID, int categoryID) {
     	try {
     		PBWSInvQCF myQCF = new PBWSInvQCF();
     		myQCF.start();
     		

	        QueueSession session;
	        session = myQCF.getSession();
	
	        javax.jms.Queue q = myQCF.getQ();
	
	        QueueSender queueSender = session.createSender(q);
	        TextMessage outMessage = session.createTextMessage();
	
	        outMessage.setStringProperty("ASSIGNED","NONE");
	        outMessage.setStringProperty("ITEMID",itemID);
	        outMessage.setStringProperty("CATEGORYID",Integer.toString(categoryID));
	        String msg = "Creating Unassigned item " + itemID + " for category " + categoryID;
	        outMessage.setText(msg);

	        queueSender.send(outMessage);

	        myQCF.close();
	        
	        return true;
	        
     	} catch (Throwable ex) {
     		ex.printStackTrace();
     	}

        return false;
    	
    }

	/**
	 * Unassign the given item from whomever it's current assigned to.
	 * @param String The Catalog item ID to unassign.
	 * @return boolean True if successful.
	 */    
    public static boolean unassignInvItem(String itemID) {
     	try {
     		PBWSInvQCF myQCF = new PBWSInvQCF();
     		myQCF.start();
     		

	        QueueSession session;
	        session = myQCF.getSession();
	
	        javax.jms.Queue q = myQCF.getQ();
	
			String messageSelector = "ITEMID = '" + itemID + "'";
			QueueReceiver queueReceiver = session.createReceiver(q, messageSelector);
			
			// Retrieve the message for the given ITEMID.  There can be only one.
			javax.jms.Message inMessage = null;
			inMessage = queueReceiver.receive(100);
	
			if(inMessage == null) {
				return false;
			}		
	
	        QueueSender queueSender = session.createSender(q);
	        TextMessage outMessage = session.createTextMessage();
	
	        outMessage.setStringProperty("ASSIGNED", "NONE");
	        outMessage.setStringProperty("ITEMID",itemID);
	        outMessage.setStringProperty("CATEGORYID",inMessage.getStringProperty("CATEGORYID"));
	        String msg = "Unassigning item " + itemID + " from " + inMessage.getStringProperty("ASSIGNED");
	        outMessage.setText(msg);

	        queueSender.send(outMessage);
	
	        myQCF.close();
	        
	        return true;
	        
     	} catch (Throwable ex) {
     		ex.printStackTrace();
     	}

        return false;
    
    }
    
    /**
     * Assign a given inventory item to the specified person.  
     * @param String The Catalog item ID to assign.
     * @param String The user id of the person to assign to.
     * @return boolean True if successful.
     */
    public static boolean assignInvItemToPerson(String itemID, String person) {
     
     	try {
     		PBWSInvQCF myQCF = new PBWSInvQCF();
     		myQCF.start();
     		

	        QueueSession session;
	        session = myQCF.getSession();
	
	        javax.jms.Queue q = myQCF.getQ();

			// Consume the given message from the queue and re-add it with the 
			// new assigned person
			String messageSelector = "ITEMID = '" + itemID + "' AND ASSIGNED = 'NONE'";
			QueueReceiver queueReceiver = session.createReceiver(q, messageSelector);
			
			// Consume the message from the queue for the selector
			javax.jms.Message inMessage = null;
			inMessage = queueReceiver.receive(100);

			if(inMessage == null) {
				return false;
			}		
			
	        QueueSender queueSender = session.createSender(q);
	        TextMessage outMessage = session.createTextMessage();
	
	        outMessage.setStringProperty("ASSIGNED",person);
	        outMessage.setStringProperty("ITEMID",itemID);
	        outMessage.setStringProperty("CATEGORYID",inMessage.getStringProperty("CATEGORYID"));
	        String msg = "Assigning item " + itemID + " to " + person;
	        outMessage.setText(msg);

	        queueSender.send(outMessage);

	
	        myQCF.close();
	        
	        return true;
	        
     	} catch (Throwable ex) {
     		ex.printStackTrace();
     	}

        return false;
    }
    
    /**
     * Retrieve all of the unassigned inventory items for the given category.
     * @param int The category to retrieve unassigned items for.
	 * @return Vector A vector of PBWSInvItemMsg objects.  
     */
    public static Vector getUnassignedInvItemsByCategory(int categoryID) {
     	try {
     		PBWSInvQCF myQCF = new PBWSInvQCF();
     		myQCF.start();
     		

	        QueueSession session;
	        session = myQCF.getSession();
	
	        javax.jms.Queue q = myQCF.getQ();
	
	        String messageSelector = "CATEGORYID = '" + categoryID + "' AND ASSIGNED = 'NONE'";
	        QueueBrowser queueBrowser = session.createBrowser(q, messageSelector);
	        
			Vector vReturn = new Vector();
			for(java.util.Enumeration e = queueBrowser.getEnumeration();e.hasMoreElements();) {
				javax.jms.TextMessage msg = (javax.jms.TextMessage) e.nextElement();
				try {
					vReturn.addElement(new PBWSInvItemMsg(msg.getStringProperty("ASSIGNED"), 
					                                  msg.getStringProperty("ITEMID"),
					                                  Integer.parseInt(msg.getStringProperty("CATEGORYID"))));
				} catch(Throwable ex) {
					System.out.println("Unable to retrieve message: " + msg.toString());
				}
			}
	
	        myQCF.close();
	        
	        return vReturn;
	        
     	} catch (Throwable ex) {
     		ex.printStackTrace();
     	}

        return null;
    	
    }
    
	/**
	 * Retrieve all assigned items for a given person.
	 * @param String The id of the person to retreive the assigned items for.
	 * @return Vector A vector of PBWSInvItemMsg objects.  
	 */
    public static Vector getAssignedInvItemsByPerson(String person) {
     	try {
     		PBWSInvQCF myQCF = new PBWSInvQCF();
     		myQCF.start();
     		

	        QueueSession session;
	        session = myQCF.getSession();
	
	        javax.jms.Queue q = myQCF.getQ();
	
	        String messageSelector = "ASSIGNED = '" + person + "'";
	        QueueBrowser queueBrowser = session.createBrowser(q, messageSelector);
	        
			Vector vReturn = new Vector();
			for(java.util.Enumeration e = queueBrowser.getEnumeration();e.hasMoreElements();) {
				javax.jms.TextMessage msg = (javax.jms.TextMessage) e.nextElement();				
				try {
					vReturn.addElement(new PBWSInvItemMsg(msg.getStringProperty("ASSIGNED"), 
					                                  msg.getStringProperty("ITEMID"),
					                                  Integer.parseInt(msg.getStringProperty("CATEGORYID"))));
				} catch(Throwable ex) {
					System.out.println("Unable to retrieve message: " + msg.toString());
				}
			}
	
	        myQCF.close();
	        
	        return vReturn;
	        
     	} catch (Throwable ex) {
     		ex.printStackTrace();
     	}
        return null;
    	
    }

	/**
	 * Complete the inventory item
	 * @param String The Catalog item ID
	 * @return boolean True if the the item was completed.
	 */
	public static boolean completeInvItem(String itemID) {
		return clearInventoryQueueforItem(itemID);
	}

	/**
	 * Clear-out the JMS Inventory Queue for an Item.
	 * @param String The Catalog item ID
	 * @return boolean True if the the item was cleared from the queue.
	 */
    public static boolean clearInventoryQueueforItem(String itemID) {
     	try {
     		PBWSInvQCF myQCF = new PBWSInvQCF();
     		myQCF.start();
     		

	        QueueSession session;
	        session = myQCF.getSession();
	
	        javax.jms.Queue q = myQCF.getQ();

			String messageSelector = "ITEMID = '" + itemID + "'";
			QueueReceiver queueReceiver = session.createReceiver(q, messageSelector);
			
			// Consume all of the messages from the queue
			javax.jms.Message inMessage = null;
			inMessage = queueReceiver.receive(100);
			
			while(inMessage != null) {
				inMessage = queueReceiver.receive(100);
			}

	        myQCF.close();
	        
	        return true;
	        
     	} catch (Throwable e) {
     		e.printStackTrace();
     	}
        return false;

    }
    
	/**
	 * Clear-out the JMS Inventory Queue
	 */
    public static boolean clearInventoryQueue() {
     	try {
     		PBWSInvQCF myQCF = new PBWSInvQCF();
     		myQCF.start();
     		

	        QueueSession session;
	        session = myQCF.getSession();
	
	        javax.jms.Queue q = myQCF.getQ();

			QueueReceiver queueReceiver = session.createReceiver(q);
			
			// Consume all of the messages from the queue
			javax.jms.Message inMessage = null;
			inMessage = queueReceiver.receive(100);
			
			while(inMessage != null) {
				inMessage = queueReceiver.receive(100);
			}

	        myQCF.close();
	        
	        return true;
	        
     	} catch (Throwable ex) {
     		ex.printStackTrace();
     	}
        return false;

    }

    //************************
    //*****  Catalog   *******
    //************************
    public static Catalog getCatalog()
        throws
            javax.ejb.CreateException,
            java.rmi.RemoteException {
        
        Catalog ejb = null;
        if (m_catalogHome != null) {
            ejb= m_catalogHome.create();
        }

        return ejb;

    }

    /**
     * Retrieve an item from the catalog from it's Item ID
     */
    public static StoreItem getCatalogItem(String itemID) {
    	try {
	    	Catalog catalog = getCatalog();
	    	if (catalog != null) {
	    	    return catalog.getItem(itemID);
	    	}
	    	else {
	    	    return null;
	    	}
    	} catch (Throwable ex) {
    		ex.printStackTrace();
    	}
    	return null;
    }

    /**
     * Sets a catalog item's image for a given item to an array of bytes.
     * CDJTODO This is a stub
     * @param String The catalog Item ID
     * @param byte[] An array of bytes representing the image.
     */
    public static void setCatalogItemImageBytes(String itemID, byte[] imgBytes) {
       try {
           Catalog c = getCatalog();
           c.setItemImageBytes(itemID, imgBytes);
    	} catch (Throwable ex) {
    		ex.printStackTrace();
    	}

    }
    
    /**
     * Retrieves a catalog item's image for a given item into an array of bytes.
     * CDJTODO This is a stub
     * @param String The catalog Item ID
     * @return byte[] An array of bytes representing the image.
     */
    public static byte[] getCatalogItemImageBytes(String itemID) {
	   try {
           Catalog c = getCatalog();
           return c.getItemImageBytes(itemID);
    	} catch (Throwable ex) {
    		ex.printStackTrace();
    	}
        
        return null;
    }
    
    /**
     * Sets a catalog item's image for a given item for an input file on the local
     * user's hard drive.
     * @param String The catalog Item ID
     * @param File An existing image file.
     */
    public static void setCatalogItemImageByFile(String itemID, File imgFile) 
        throws FileNotFoundException, IOException {
       
        // Open the input file as a stream of bytes
        FileInputStream fis = new FileInputStream(imgFile);
        DataInputStream dis = new DataInputStream(fis);

        int dataSize = dis.available();
            
        byte[] data = new byte[dataSize];
        dis.readFully(data);
            
        setCatalogItemImageBytes(itemID, data);
    }
    
    /**
     * Retrieves a catalog item's image for a given item and places it into 
     * a file with the specified name and path on the local hard drive.
     * @param String The catalog Item ID
     * @param File The image file to create
     */
    public static void getCatalogItemImageByFile(String itemID, File imgDestFile)
        throws FileNotFoundException, IOException {

        // Open the file for output and stream our item's byte array to it.
        FileOutputStream fos = new FileOutputStream(imgDestFile);
        DataOutputStream dos = new DataOutputStream(fos);
        dos.write(getCatalogItemImageBytes(itemID));
    }

    //************************
    //*****  Reports   *******
    //************************
    
    /**
     * Retrieves a ReportGenerator remote object.
     * @return ReportGenerator A ReportGenerator EJB.
     */
    public static ReportGenerator getReportGenerator() 
    	throws
    		javax.ejb.CreateException,
    		java.rmi.RemoteException {
        ReportGenerator ejb = null;
        if (m_reportGenHome != null) {
    	    ejb = m_reportGenHome.create();
    	}
		return ejb;
    }

    /**
     * Run a report and store the results in an input file.  The resulting report
     * is returned to the user when complete.
     * @param rptName The name of the report to run.
     * @param fromDate The beginning date to run from.
     * @param toDate The end date to run to.
     * @param maxRows The maximum number of rows of data to return.
     * @param outFile The file to write the report results to.
     * @return Report The Report object that contains the report results.
     */
    public static Report runReport(String rptName, Date fromDate, Date toDate, int maxRows, File outFile) 
        throws IOException, Throwable {
        FileWriter outFW = null;
        outFW = new FileWriter(outFile);

        // Run the report based on the input parameters
        // Store the report to a text file delimited by commas.
        Report rpt = null;
        ReportGenerator rg = getReportGenerator();
        if (rptName.equals(Report_TopSellersForDates)) {
            rpt = rg.getTopSellersForDates(fromDate, toDate, maxRows, new ReportFormat());
        }
        else if (rptName.equals(Report_TopSellingZipsForDates)) {
            rpt = rg.getTopSellingZipsForDates(fromDate, toDate, maxRows, new ReportFormat());
        }        

        // Write the report to a file.
        String eol = System.getProperty("line.separator");
        outFW.write(rptName + eol);
        outFW.write("----------------------------------------------------" + eol);
        outFW.write("Field Definition: ");
        outFW.write("Item ID, Item Name, Profits" + eol);
        outFW.write("----------------------------------------------------" + eol);
	    if (rpt != null) {
	        int iTotRows = rpt.getRowCount();
	        for(int i=0;i<iTotRows;i++) {
	            StringBuffer formattedRow = new StringBuffer();
	            formattedRow.append(rpt.getReportFieldByRow(Report.ORDER_INVENTORY_ID ,i));
	            formattedRow.append(", ");
	            formattedRow.append(rpt.getReportFieldByRow(Report.ORDER_INVENTORY_NAME ,i));
	            formattedRow.append(", ");
	            formattedRow.append(rpt.getReportFieldByRow(Report.PROFITS, i));
	            formattedRow.append(eol);
                outFW.write(formattedRow.toString());
            }
   	    }
   	    else {
            outFW.write("No Records Available.");   	            
   	    }
		outFW.close();

        return rpt;
    }
    
}

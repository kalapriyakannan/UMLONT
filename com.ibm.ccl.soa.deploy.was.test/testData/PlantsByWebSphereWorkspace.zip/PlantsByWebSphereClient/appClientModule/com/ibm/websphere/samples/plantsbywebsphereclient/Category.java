//
//"This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own
//instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
//or for redistribution by customer, as part of such an application, in customer's own products. " 
//
//Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001,2002
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereclient;

/**
 * A Catalog Category structure.  It contains a Category ID and Name.
 */
public class Category {
    /**
     * Category ID which maps to the category tabs on the Plants By WebSphere
     * web application
     */
    public int m_catID;

    /**
     * Category Description or Name.
     */
    public String m_catName;

    /**
     * Constructor
     * @param catID Category ID
     * @param catName Category Name
     */
    Category(int catID, String catName) {
        m_catID = catID;
        m_catName = catName;
    }
}
//
//"This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own
//instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
//or for redistribution by customer, as part of such an application, in customer's own products. " 
//
//Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001,2002
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereclient;

import java.awt.*;
import javax.swing.*;
import java.util.*;
import com.ibm.websphere.samples.plantsbywebsphereejb.*;

/**
 * The Send Email window that is displayed when the user
 * clicks on the Email button on the Catalog Management tab
 * on the main window.
 **/
public class PBWSEmail extends javax.swing.JDialog
{
    // Used by addNotify
    boolean frameSizeAdjusted = false;

    // Declare our controls
    javax.swing.JPanel pnlMain = new javax.swing.JPanel();
    javax.swing.JLabel lblEmailAddr = new javax.swing.JLabel();
    javax.swing.JTextField txtEmailAddr = new javax.swing.JTextField();
    javax.swing.JLabel lblEmailFromAddr = new javax.swing.JLabel();
    javax.swing.JTextField txtEmailFromAddr = new javax.swing.JTextField();
    javax.swing.JLabel lblEmailSubject= new javax.swing.JLabel();
    javax.swing.JTextField txtEmailSubject = new javax.swing.JTextField();
    javax.swing.JLabel lblEmailCatalogItems = new javax.swing.JLabel();
    javax.swing.JScrollPane sclEmailCatalogItems = new javax.swing.JScrollPane();
    javax.swing.JTable tblEmailCatalogItems = new javax.swing.JTable();
    javax.swing.JLabel lblEmailMsg = new javax.swing.JLabel();
    javax.swing.JTextArea txtEmailMsg = new javax.swing.JTextArea();
    javax.swing.JScrollPane sclEmailMsg = new javax.swing.JScrollPane();
    javax.swing.JPanel pnlMainBot = new javax.swing.JPanel();
    javax.swing.JButton btnSend = new javax.swing.JButton();
    javax.swing.JButton btnCancel = new javax.swing.JButton();
    PBWSCatalogTableModel tblmdlItemList = new PBWSCatalogTableModel();

    // Catalog item ID's to send to the email recipient.
    private Vector vCatalogItemIDs = null;

    public PBWSEmail(Frame parent)
    {
        super(parent);
        
        setTitle("Plants by WebSphere - Send Email");

        getContentPane().setLayout(new GridBagLayout());
        setSize(405,305);
        setVisible(false);
        pnlMain.setLayout(new GridBagLayout());
        getContentPane().add(pnlMain,new GridBagConstraints(0,0,1,1,1.0,1.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.BOTH,new Insets(5,5,5,5),0,0));

        lblEmailAddr.setText("To Address:");
        pnlMain.add(lblEmailAddr, new GridBagConstraints(0,0,1,1,0.0,0.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlMain.add(txtEmailAddr, new GridBagConstraints(1,0,1,1,1.0,0.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.HORIZONTAL,new Insets(5,5,0,0),0,0));

        lblEmailFromAddr.setText("From Address:");
        pnlMain.add(lblEmailFromAddr, new GridBagConstraints(0,1,1,1,0.0,0.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlMain.add(txtEmailFromAddr, new GridBagConstraints(1,1,1,1,1.0,0.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.HORIZONTAL,new Insets(5,5,0,0),0,0));

        lblEmailSubject.setText("Subject:");
        pnlMain.add(lblEmailSubject, new GridBagConstraints(0,2,1,1,0.0,0.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlMain.add(txtEmailSubject, new GridBagConstraints(1,2,1,1,1.0,0.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.HORIZONTAL,new Insets(5,5,0,0),0,0));

        lblEmailCatalogItems.setText("Items to Email:");
        pnlMain.add(lblEmailCatalogItems, new GridBagConstraints(0,3,1,1,0.0,0.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        sclEmailCatalogItems.setOpaque(true);
        pnlMain.add(sclEmailCatalogItems, new GridBagConstraints(1,3,1,1,1.0,1.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.BOTH,new Insets(5,5,0,0),0,0));
        tblEmailCatalogItems.setGridColor(new java.awt.Color(153,153,153));
        sclEmailCatalogItems.getViewport().add(tblEmailCatalogItems);
        tblEmailCatalogItems.setRowSelectionAllowed(false);
        tblEmailCatalogItems.setBounds(0,0,268,0);
        
        lblEmailMsg.setText("Additional Message:");
        pnlMain.add(lblEmailMsg, new GridBagConstraints(0,4,1,1,0.0,0.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        sclEmailMsg.setAutoscrolls(true);
        pnlMain.add(sclEmailMsg, new GridBagConstraints(1,4,1,2,1.0,1.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.BOTH,new Insets(5,5,0,0),0,0));
        sclEmailMsg.getViewport().add(txtEmailMsg);
        pnlMainBot.setLayout(new GridLayout(1,1,5,5));
        pnlMain.add(pnlMainBot, new GridBagConstraints(0,99,4,1,1.0,0.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.NONE,new Insets(5,0,0,0),0,0));
        
        btnSend.setText("Send Email");
        btnSend.setActionCommand("Send Email");
        btnSend.setSelected(true);
        btnSend.setMnemonic((int)'S');
        pnlMainBot.add(btnSend);
        btnCancel.setText("Cancel");
        btnCancel.setActionCommand("Cancel");
        btnCancel.setMnemonic((int)'C');
        pnlMainBot.add(btnCancel);

        // Custom Control Initialization
        tblEmailCatalogItems.setModel(tblmdlItemList);
    
        // RegisterListeners
        PBWSAction lPBWSAction = new PBWSAction();
        btnCancel.addActionListener(lPBWSAction);
        btnSend.addActionListener(lPBWSAction);

    }

    public PBWSEmail()
    {
        this((Frame)null);
    }

    public PBWSEmail(String sTitle)
    {
        this();
        setTitle(sTitle);
    }

    public void setVisible(boolean b)
    {
        if (b) {
            Rectangle bounds = getParent().getBounds();
            Rectangle abounds = getBounds();
    
            setLocation(bounds.x + (bounds.width - abounds.width)/ 2,
                 bounds.y + (bounds.height - abounds.height)/2);
        }
        super.setVisible(b);
    }

    static public void main(String args[])
    {
        (new PBWSEmail()).setVisible(true);
    }

    public void addNotify()
    {
        // Record the size of the window prior to calling parents addNotify.
        Dimension size = getSize();

        super.addNotify();

        if (frameSizeAdjusted)
            return;
        frameSizeAdjusted = true;

        // Adjust size of frame according to the insets
        Insets insets = getInsets();
        setSize(insets.left + insets.right + size.width, insets.top + insets.bottom + size.height);
    }

    class PBWSAction implements java.awt.event.ActionListener
    {
        public void actionPerformed(java.awt.event.ActionEvent event)
        {
            Object object = event.getSource();
            if (object == btnCancel)
                btnCancel_actionPerformed(event);
            else if (object == btnSend)
                btnSend_actionPerformed(event);
        }
    }

    void btnCancel_actionPerformed(java.awt.event.ActionEvent event)
    {
        try {
            // Hide the PBWSEmail window
            this.setVisible(false);
        } catch (java.lang.Exception e) {
        }
    }
    
    /**
     * The Send button has been pressed.  Send an email to the 
     * recipient with the message and catalog items in it.
     **/
    void btnSend_actionPerformed(java.awt.event.ActionEvent event)
    {
        try {
            String toEmail = txtEmailAddr.getText();
            String fromEmail = txtEmailFromAddr.getText();
            String message = txtEmailMsg.getText();
            String subject = txtEmailSubject.getText();
            
            // Validate the email address.
            if (PBWSUtility.verifyEmail(toEmail) == false) {
                JOptionPane.showMessageDialog(this, "Please enter a valid email address.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Store the FROM email address in the user's property file.
            PBWSConfig.setUserProperty(PBWSConfig.USERPROP_LASTFROMADDR, fromEmail);
            
            // Send the message
            PBWSBusinessObjects.sendEmail(toEmail, fromEmail, subject, message, vCatalogItemIDs);

            JOptionPane.showMessageDialog(this, "The message has been sent.", "Information", JOptionPane.INFORMATION_MESSAGE);
            
            // Hide the PBWSEmail window
            this.setVisible(false);
        } catch (java.lang.Exception e) {
            JOptionPane.showMessageDialog(this, "Unable to send email.  Check the stack trace for details.", "Error sending email", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Fill or refill the main catalog table.
     */
    private void fillItemsTable(Vector vItemIDs) {
        try {
            Catalog catalog = PBWSBusinessObjects.getCatalog();
            
            tblmdlItemList.clearAllRows();
            for(Enumeration e = vItemIDs.elements();e.hasMoreElements();) {
                String curItemID = (String)e.nextElement();
                StoreItem curItem = catalog.getItem(curItemID);
                tblmdlItemList.addRow(curItem.getID(),curItem.getName(), curItem.getDescription(), PBWSBusinessObjects.getCategoryNameFromID(curItem.getCategory()));
            }
            
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    /**
     * Initialize the email window with the selected catalog item id's from the
     * catalog tab on the main form.
     * @param Vector A Vector of Item ID's.
     **/
    public void init(Vector vItemIDs) {
        vCatalogItemIDs = vItemIDs;
        
        // Fill the to, from and message boxes
        txtEmailAddr.setText(PBWSConfig.getUserProperty(PBWSConfig.USERPROP_DEFAULTTOADDR, ""));
        txtEmailFromAddr.setText(PBWSConfig.getUserProperty(PBWSConfig.USERPROP_LASTFROMADDR, 
                                   PBWSConfig.getUserProperty(PBWSConfig.USERPROP_DEFAULTFROMADDR, "")));
        txtEmailMsg.setText(PBWSConfig.getUserProperty(PBWSConfig.USERPROP_DEFAULTMESSAGE, ""));
        txtEmailSubject.setText(PBWSConfig.getUserProperty(PBWSConfig.USERPROP_DEFAULTSUBJECT, ""));
        
        // Fill the catalog table
        fillItemsTable(vItemIDs);
        
    }
}
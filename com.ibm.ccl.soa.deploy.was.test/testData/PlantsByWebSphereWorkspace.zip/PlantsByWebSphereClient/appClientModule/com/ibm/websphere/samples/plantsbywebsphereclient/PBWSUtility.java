//
//"This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own
//instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
//or for redistribution by customer, as part of such an application, in customer's own products. " 
//
//Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001,2002
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereclient;

import java.util.StringTokenizer;
import java.text.*;
import java.awt.Toolkit;


/**
 * Various utility functions for the Sample.
 */
public class PBWSUtility {
 
    /**
     * Convert a delimited string into an array of Strings.
     */
    public static String[ ] readTokens(String text, String token) {
        StringTokenizer parser = new StringTokenizer(text, token);
        int numTokens=parser.countTokens( );
        String[ ] list = new String[numTokens];

        for (int i=0; i < numTokens; i++) {
            list[i] = parser.nextToken( );
        }
    
        return list;
    }

	/**
	 * Format a given String with a currency-format without the 
	 * currency symbols.   If the string is an invalid
	 * number, then return 0.00.
	 */
	public static String getMoneyFormat(String s) {
		NumberFormat nf = NumberFormat.getNumberInstance();
		nf.setMinimumFractionDigits(2);
		String result;
		try {
			result = nf.format(nf.parse(s).doubleValue());
		} catch (ParseException e) {
			Toolkit.getDefaultToolkit().beep();
			return "0.00";
		}
		return result;
	}
	
	/**
	 * Validate that an email address is of the proper format.
	 * @param String The email address to validate.
	 * @return boolean True if the input string has a valid email address format.
	 */
	public static boolean verifyEmail(String s) {
	    javax.mail.internet.InternetAddress ia = new javax.mail.internet.InternetAddress();
	    
	    try {
	        ia.parse(s, false);
	        return true;
	    }
	    catch(javax.mail.internet.AddressException ex) {
	        return false;
	    }
    }
    
    /**
     * Set the user defaults.
     **/
    public static void createDefaultConfig() {
        // Setup the user properties for an email session
        PBWSConfig.setUserProperty(PBWSConfig.USERPROP_DEFAULTFROMADDR, "inventory_dept@plantsbywebsphere.com");
        PBWSConfig.setUserProperty(PBWSConfig.USERPROP_DEFAULTTOADDR, "graphics_dept@plantsbywebsphere.com");
        PBWSConfig.setUserProperty(PBWSConfig.USERPROP_DEFAULTSUBJECT, "Request for graphics.");
    }
    

}

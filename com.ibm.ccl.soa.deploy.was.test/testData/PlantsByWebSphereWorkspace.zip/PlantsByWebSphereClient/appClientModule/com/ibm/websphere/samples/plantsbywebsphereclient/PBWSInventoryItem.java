//
//"This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own
//instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
//or for redistribution by customer, as part of such an application, in customer's own products. " 
//
//Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001,2002
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereclient;

import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.io.File;
import com.ibm.websphere.samples.plantsbywebsphereejb.*;

/**
 * Window for adding and updating an inventory item to the catalog.
 **/
public class PBWSInventoryItem extends javax.swing.JDialog
{
    // Used by addNotify
    boolean frameSizeAdjusted = false;

    // All GUI controls
    javax.swing.JPanel pnlMain = new javax.swing.JPanel();
    javax.swing.JLabel lblItemID = new javax.swing.JLabel();
    javax.swing.JTextField txtItemID = new javax.swing.JTextField();
    javax.swing.JLabel lblItemShortName = new javax.swing.JLabel();
    javax.swing.JTextField txtItemShortName = new javax.swing.JTextField();
    javax.swing.JLabel lblItemHeading = new javax.swing.JLabel();
    javax.swing.JTextField txtItemHeading = new javax.swing.JTextField();
    javax.swing.JLabel lblItemDescription = new javax.swing.JLabel();
    javax.swing.JScrollPane sclItemDescription = new javax.swing.JScrollPane();
    javax.swing.JTextPane txtItemDescription = new javax.swing.JTextPane();
    javax.swing.JLabel lblItemCategory = new javax.swing.JLabel();
    javax.swing.JComboBox cmbItemCategory = new javax.swing.JComboBox();
    javax.swing.JLabel lblItemPackage = new javax.swing.JLabel();
    javax.swing.JTextField txtItemPackage = new javax.swing.JTextField();
    javax.swing.JLabel lblItemCost = new javax.swing.JLabel();
    javax.swing.JPanel pnlItemSpacer1 = new javax.swing.JPanel();
    javax.swing.JPanel pnlItemCost = new javax.swing.JPanel();
    javax.swing.JLabel lblItemCostD = new javax.swing.JLabel();
    javax.swing.JTextField txtItemCost = new javax.swing.JTextField();
    javax.swing.JLabel lblItemPrice = new javax.swing.JLabel();
    javax.swing.JPanel pnlItemPrice = new javax.swing.JPanel();
    javax.swing.JLabel lblItemPriceD = new javax.swing.JLabel();
    javax.swing.JTextField txtItemPrice = new javax.swing.JTextField();
    javax.swing.JLabel lblItemInventory = new javax.swing.JLabel();
    javax.swing.JTextField txtItemInventory = new javax.swing.JTextField();
    javax.swing.JPanel pnlItemGraphic = new javax.swing.JPanel();
    javax.swing.JButton btnItemImage = new javax.swing.JButton();
    javax.swing.ImageIcon imageItem = new javax.swing.ImageIcon();
    javax.swing.JLabel lblItemImage = new javax.swing.JLabel();
    javax.swing.JLabel lblItemIsPublic = new javax.swing.JLabel();
    javax.swing.JCheckBox cbxItemIsPublic = new javax.swing.JCheckBox();
    javax.swing.JLabel lblItemNotes = new javax.swing.JLabel();
    javax.swing.JScrollPane sclItemNotes = new javax.swing.JScrollPane();
    javax.swing.JTextPane txtItemNotes = new javax.swing.JTextPane();
    javax.swing.JPanel pnlMainBot = new javax.swing.JPanel();
    javax.swing.JButton btnItemAddUpdate = new javax.swing.JButton();
    javax.swing.JButton btnCancel = new javax.swing.JButton();

    // File Chooser info
    private File m_lastFCDirectory = null;
    
    // Inventory Item info
    private boolean m_isImageDirty = false;
    private File m_localImage = null;

    // Valid Window types
    public static final int WINDOWTYPE_ADD = 1;
    public static final int WINDOWTYPE_UPDATE = 2;
    
    // This window type
    private int m_windowType = WINDOWTYPE_ADD;
    
    // Window state
    private boolean m_isCancelled = true;
    
    // Form Field Properties - Used only for window initialization.
    private String m_itemID = "";
    private String m_shortName = "";
    private String m_heading = "";
    private String m_description = "";
    private int m_categoryID = 0;
    private String m_package = "";
    private float m_cost = 0;
    private float m_price = 0;
    private int m_inventory = 0;
    private boolean m_isPublic = false;
    private String m_notes = "";

    public PBWSInventoryItem(Frame parent)
    {
        super(parent);

        // Initialize the GUI controls
        setModal(true);
        getContentPane().setLayout(new GridBagLayout());
        setSize(425,398);
        setVisible(false);
        pnlMain.setLayout(new GridBagLayout());
        getContentPane().add(pnlMain,new GridBagConstraints(0,0,1,1,1.0,1.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.BOTH,new Insets(5,5,5,5),0,0));

        lblItemID.setText("Item ID:");
        pnlMain.add(lblItemID, new GridBagConstraints(0,0,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlMain.add(txtItemID, new GridBagConstraints(1,0,3,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),75,0));
        txtItemID.setForeground(java.awt.Color.red);
        txtItemID.setFont(new Font("Dialog", Font.BOLD, 12));

        lblItemShortName.setText("Short Name:");
        pnlMain.add(lblItemShortName, new GridBagConstraints(0,1,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlMain.add(txtItemShortName, new GridBagConstraints(1,1,3,1,1.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.HORIZONTAL,new Insets(5,5,0,0),0,0));

        lblItemHeading.setText("Heading:");
        pnlMain.add(lblItemHeading, new GridBagConstraints(0,2,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlMain.add(txtItemHeading, new GridBagConstraints(1,2,3,1,1.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.HORIZONTAL,new Insets(5,5,0,0),0,0));

        lblItemDescription.setText("Description:");
        pnlMain.add(lblItemDescription, new GridBagConstraints(0,3,1,1,0.0,0.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlMain.add(sclItemDescription, new GridBagConstraints(1,3,3,2,1.0,0.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.BOTH,new Insets(5,5,0,0),0,25));
        sclItemDescription.getViewport().add(txtItemDescription);
        txtItemDescription.setBounds(0,0,320,46);

        lblItemCategory.setText("Category:");
        pnlMain.add(lblItemCategory, new GridBagConstraints(0,5,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlMain.add(cmbItemCategory, new GridBagConstraints(1,5,3,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));

        lblItemPackage.setText("Package:");
        pnlMain.add(lblItemPackage, new GridBagConstraints(0,6,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlMain.add(txtItemPackage, new GridBagConstraints(1,6,3,1,1.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),80,0));

        lblItemCost.setText("Current Cost:");
        pnlMain.add(lblItemCost, new GridBagConstraints(0,7,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlItemSpacer1.setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
        pnlMain.add(pnlItemSpacer1, new GridBagConstraints(2,7,1,1,1.0,0.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));
        pnlItemCost.setLayout(new GridBagLayout());
        pnlMain.add(pnlItemCost, new GridBagConstraints(1,7,1,1,0.0,0.0,java.awt.GridBagConstraints.NORTHEAST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),50,0));

        lblItemCostD.setText("$");
        pnlItemCost.add(lblItemCostD, new GridBagConstraints(0,0,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(0,0,0,0),0,0));
        txtItemCost.setText("0");
        txtItemCost.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        pnlItemCost.add(txtItemCost, new GridBagConstraints(1,0,1,1,1.0,1.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));

        lblItemPrice.setText("Web Price:");
        pnlMain.add(lblItemPrice, new GridBagConstraints(0,8,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlItemPrice.setLayout(new GridBagLayout());
        pnlMain.add(pnlItemPrice, new GridBagConstraints(1,8,1,1,0.0,0.0,java.awt.GridBagConstraints.NORTHEAST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),50,0));

        lblItemPriceD.setText("$");
        pnlItemPrice.add(lblItemPriceD, new GridBagConstraints(0,0,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(0,0,0,0),0,0));
        txtItemPrice.setText("0");
        txtItemPrice.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        pnlItemPrice.add(txtItemPrice, new GridBagConstraints(1,0,1,1,1.0,1.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));

        lblItemInventory.setText("Inventory:");
        pnlMain.add(lblItemInventory, new GridBagConstraints(0,9,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        txtItemInventory.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        pnlMain.add(txtItemInventory, new GridBagConstraints(1,9,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),80,0));

        pnlItemGraphic.setLayout(new GridBagLayout());
        pnlMain.add(pnlItemGraphic, new GridBagConstraints(3,5,1,6,0.0,0.0,java.awt.GridBagConstraints.NORTHEAST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        btnItemImage.setText("Choose Image");
        btnItemImage.setMnemonic((int)'I');
        pnlItemGraphic.add(btnItemImage,new GridBagConstraints(0,0,1,1,0.0,0.0,java.awt.GridBagConstraints.NORTHWEST,java.awt.GridBagConstraints.NONE,new Insets(0,0,0,0),0,0));
        
        lblItemImage.setText("No Image");
        lblItemImage.setHorizontalAlignment(JLabel.CENTER);
        lblItemImage.setVerticalAlignment(JLabel.CENTER);
        lblItemImage.setVerticalTextPosition(JLabel.CENTER);
        lblItemImage.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLoweredBevelBorder(),BorderFactory.createEmptyBorder(5,5,5,5)));
        lblItemImage.setPreferredSize(new Dimension(80,95));
        
        pnlItemGraphic.add(lblItemImage,new GridBagConstraints(0,1,1,1,0.0,0.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.NONE,new java.awt.Insets(5,5,5,5),0,0));

        lblItemIsPublic.setText("Is Public:");
        pnlMain.add(lblItemIsPublic, new GridBagConstraints(0,10,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlMain.add(cbxItemIsPublic, new GridBagConstraints(1,10,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));

        lblItemNotes.setText("Internal Notes:");
        pnlMain.add(lblItemNotes, new GridBagConstraints(0,11,1,1,0.0,0.0,java.awt.GridBagConstraints.WEST,java.awt.GridBagConstraints.NONE,new Insets(5,5,0,0),0,0));
        pnlMain.add(sclItemNotes, new GridBagConstraints(1,11,3,2,1.0,1.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.BOTH,new Insets(5,5,0,0),0,0));
        sclItemNotes.getViewport().add(txtItemNotes);
        txtItemNotes.setBounds(0,0,320,126);

        pnlMainBot.setLayout(new GridLayout(1,1,5,5));
        pnlMain.add(pnlMainBot, new GridBagConstraints(0,99,4,1,1.0,0.0,java.awt.GridBagConstraints.CENTER,java.awt.GridBagConstraints.NONE,new Insets(5,0,0,0),0,0));

        btnItemAddUpdate.setText("Add / Update");
        btnItemAddUpdate.setSelected(true);
        btnItemAddUpdate.setMnemonic((int)'A');
        pnlMainBot.add(btnItemAddUpdate);

        btnCancel.setText("Cancel");
        btnCancel.setMnemonic((int)'C');
        pnlMainBot.add(btnCancel);

        // Register the listeners for the controls
        PBWSAction lPBWSAction = new PBWSAction();
        btnCancel.addActionListener(lPBWSAction);
        btnItemAddUpdate.addActionListener(lPBWSAction);
        btnItemImage.addActionListener(lPBWSAction);

        PBWSFocus lPBWSFocus = new PBWSFocus();
        txtItemCost.addFocusListener(lPBWSFocus);
        txtItemPrice.addFocusListener(lPBWSFocus);

    }

    public PBWSInventoryItem()
    {
        this((Frame)null);
    }

    public PBWSInventoryItem(String sTitle)
    {
        this();
        setTitle(sTitle);
    }

    public void setVisible(boolean b)
    {
        if (b) {
            fillMainUI();
            
            Rectangle bounds = getParent().getBounds();
            Rectangle abounds = getBounds();
    
            setLocation(bounds.x + (bounds.width - abounds.width)/ 2,
                 bounds.y + (bounds.height - abounds.height)/2);
        }
        super.setVisible(b);
    }

    /**
     * Fill in the various text fields in our user interface.
     */
    public void fillMainUI()
    {
        // Set the window title
        if (m_windowType == WINDOWTYPE_ADD) {
            setTitle("Plants by WebSphere - Add Item");
            btnItemAddUpdate.setText("Add");
            btnItemAddUpdate.setMnemonic((int)'A');
        }
        else {
            setTitle("Plants by WebSphere - View or Update Item");
            btnItemAddUpdate.setText("Update");
            btnItemAddUpdate.setMnemonic((int)'U');
        }

        Vector vCategories = PBWSBusinessObjects.getCategories();        
        for (Enumeration e = vCategories.elements();e.hasMoreElements();) {
            cmbItemCategory.addItem(((Category)e.nextElement()).m_catName);
        }
        
        // Fill the form based on our member variables.
        txtItemID.setText(m_itemID);
        txtItemShortName.setText(m_shortName);
        txtItemHeading.setText(m_heading);
        txtItemDescription.setText(m_description);
        cmbItemCategory.setSelectedIndex(m_categoryID);
        txtItemPackage.setText(m_package);
        txtItemCost.setText(PBWSUtility.getMoneyFormat(String.valueOf(m_cost)));
        txtItemPrice.setText(PBWSUtility.getMoneyFormat(String.valueOf(m_price)));
        txtItemInventory.setText(String.valueOf(m_inventory));
        cbxItemIsPublic.setSelected(m_isPublic);
        txtItemNotes.setText(m_notes);
        
        // Get the image, if any
        if (m_windowType != WINDOWTYPE_ADD) { // Only for update        
           byte[] byteImage = PBWSBusinessObjects.getCatalogItemImageBytes(m_itemID);
           if (byteImage != null) {
               imageItem.setImage(new ImageIcon(byteImage).getImage().getScaledInstance(80,95,Image.SCALE_DEFAULT));
               lblItemImage.setIcon(imageItem);
           }
           else {
               lblItemImage.setIcon(null);
           }
        }
    }

    public void addNotify()
    {
        // Record the size of the window prior to calling parents addNotify.
        Dimension size = getSize();

        super.addNotify();

        if (frameSizeAdjusted)
            return;
        frameSizeAdjusted = true;

        // Adjust size of frame according to the insets
        Insets insets = getInsets();
        setSize(insets.left + insets.right + size.width, insets.top + insets.bottom + size.height);
    }

    class PBWSAction implements java.awt.event.ActionListener
    {
        public void actionPerformed(java.awt.event.ActionEvent event)
        {
            Object object = event.getSource();
            if (object == btnCancel)
                btnCancel_actionPerformed(event);
            else if (object == btnItemAddUpdate)
                btnItemAddUpdate_actionPerformed(event);
            else if (object == btnItemImage)
                btnItemImage_actionPerformed(event);
        }
    }
    
    void btnItemImage_actionPerformed(java.awt.event.ActionEvent event) 
    {
        // Get an updated image from the user.
        
        // Show a image chooser.
        final JFileChooser fc = new JFileChooser();
        class ImageFileFilter extends javax.swing.filechooser.FileFilter {
            public boolean accept(File f) {
                if (f.isDirectory()) {
                    return true;
                }
                String s = f.getName();
                int i = s.lastIndexOf('.');
                String ext = "";
                if (i > 0 && i < s.length()-1) {
                    ext = s.substring(i+1).toLowerCase();
                }
                
                if(ext.equals("jpg") ||
                   ext.equals("jpeg") || 
                   ext.equals("gif")) {
                    return true;
                }
                else {
                    return false;
                }
            }
            public String getDescription() {
                return "JPEG and GIF Images";
            }
        }
        
        final ImageFileFilter iff = new ImageFileFilter();

        fc.setFileFilter(iff);
        if (m_lastFCDirectory != null) {
            fc.setCurrentDirectory(m_lastFCDirectory);
        }
        
        int rc = fc.showOpenDialog(this);
        m_lastFCDirectory = fc.getCurrentDirectory();

        if (rc == JFileChooser.APPROVE_OPTION) {
            java.io.File file = fc.getSelectedFile();
 
            // If an image was selected, set the dirty bit
            m_isImageDirty = true;
            m_localImage = file;
            
            // Display the image.
            try {
                imageItem.setImage(new ImageIcon(file.toURL()).getImage().getScaledInstance(80,95,Image.SCALE_DEFAULT));
                lblItemImage.setIcon(imageItem);
            } catch(java.net.MalformedURLException ex) {
                ex.printStackTrace();
            }
        }
        
    }

    void btnCancel_actionPerformed(java.awt.event.ActionEvent event)
    {
        try {
            // PBWSInventoryItem Hide the PBWSInventoryItem
            m_isCancelled = true;
            setVisible(false);
        } catch (java.lang.Exception e) {
        }
    }
    
    /**
     * Update or Add a new catalog item.
     */
    void btnItemAddUpdate_actionPerformed(java.awt.event.ActionEvent event)
    {
        // If we are in "add" mode, then add this new item to our 
        // Unassigned queue for the inventory folks and add it to our database.
        if(m_windowType == WINDOWTYPE_ADD) {
            try {           
                // Add the new catalog item to the catalog
                Catalog catalog = PBWSBusinessObjects.getCatalog();
                StoreItem item = new StoreItem(
                    txtItemID.getText(),                //id - - id of this store item.
                    txtItemShortName.getText(),         //name - - name of this store item.
                    txtItemHeading.getText(),           //heading - - description heading of this store item.
                    txtItemDescription.getText(),       //desc - - description of this store item.
                    txtItemPackage.getText(),           //pkginfo - - package info of this store item.
                    "",                                 //image - - image name of this store item.
                    Float.parseFloat(txtItemPrice.getText()),    //price - - price of this store item.
                    Float.parseFloat(txtItemCost.getText()),     //cost - - cost of this store item.
                    Integer.parseInt(txtItemInventory.getText()),//quantity - - quantity of this store item.
                    cmbItemCategory.getSelectedIndex(), //category - - category of this store item.
                    txtItemNotes.getText(),             //notes - - notes of this store item.
                    cbxItemIsPublic.isSelected());      //isPublic - - isPublic flag of this store item.
    
                catalog.addItem(item);
                
                // Now add the image, if there is one.
                if(m_isImageDirty && m_localImage != null) {
                    PBWSBusinessObjects.setCatalogItemImageByFile(item.getID(), m_localImage);
                }
    
                // Create an unassigned record for the Inventory people.            
                PBWSBusinessObjects.createUnassignedInvItem(txtItemID.getText(), cmbItemCategory.getSelectedIndex());
                
            } catch (Throwable ex) {
                ex.printStackTrace();
            }
        }

        // If we are in update mode, then refresh the fields of this item.
        else {
            try {  
                Catalog catalog = PBWSBusinessObjects.getCatalog();
                String itemId = txtItemID.getText();
                catalog.setItemName(itemId, txtItemShortName.getText());
                catalog.setItemHeading(itemId, txtItemHeading.getText());
                catalog.setItemDescription(itemId, txtItemDescription.getText());
                catalog.setItemPkginfo(itemId, txtItemPackage.getText());
                catalog.setItemPrice(itemId, Float.parseFloat(txtItemPrice.getText()));
                catalog.setItemCost(itemId, Float.parseFloat(txtItemCost.getText()));
                catalog.setItemQuantity(itemId, Integer.parseInt(txtItemInventory.getText()));
                catalog.setItemCategory(itemId, cmbItemCategory.getSelectedIndex());
                catalog.setItemNotes(itemId, txtItemNotes.getText());
                catalog.setItemPrivacy(itemId, cbxItemIsPublic.isSelected());
                
                // Now update the image, if there is one.
                if(m_isImageDirty && m_localImage != null) {
                    PBWSBusinessObjects.setCatalogItemImageByFile(itemId, m_localImage);
                }
                
            } catch (Throwable ex) {
                ex.printStackTrace();
            }

        }

        
        m_isCancelled = false;
        
        setVisible(false);
             
    }
    
    class PBWSFocus extends java.awt.event.FocusAdapter
    {
        public void focusLost(java.awt.event.FocusEvent event)
        {
            Object object = event.getSource();
            if (object == txtItemCost)
                txtItemCost_focusLost(event);
            else if (object == txtItemPrice)
                txtItemPrice_focusLost(event);
        }
    }

    void txtItemCost_focusLost(java.awt.event.FocusEvent event)
    {
        // Format the text correctly.
        txtItemCost.setText(PBWSUtility.getMoneyFormat(txtItemCost.getText()));
    }   
    
    void txtItemPrice_focusLost(java.awt.event.FocusEvent event)
    {
        // Format the text correctly.
        txtItemPrice.setText(PBWSUtility.getMoneyFormat(txtItemPrice.getText()));
    }   

    /**
     * Initializes the inventory window for Add or Update.
     * @param int The Type of Inventory window to show WINDOWTYPE_UPDATE or WINDOWTYPE_ADD
     * @param int The Item ID or Inventory ID to display if the window is WINDOWTYPE_UPDATE
     */
    public void init(int windowType, String itemID) {
        
        m_windowType = windowType;
        
        if(windowType == WINDOWTYPE_UPDATE) {
            // Get a Catalog item from our Business Objects interface
            // and setup our private data.  When the frame is displayed
            // it will use the private data as default.
            try {
                Catalog catalog = PBWSBusinessObjects.getCatalog();
                StoreItem item = catalog.getItem(itemID);
                
                m_itemID = itemID;
                m_shortName = item.getName();
                m_heading = item.getHeading();
                m_description = item.getDescription();
                m_categoryID = item.getCategory();
                m_package = item.getPkginfo();
                m_cost = item.getCost();
                m_price = item.getPrice();
                m_inventory = item.getQuantity();
                m_isPublic = item.isPublic();
                m_notes = item.getNotes(); 
                m_isImageDirty = false;
                m_localImage = null;
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            // Update the GUI
            txtItemID.setEnabled(false);
            btnItemAddUpdate.setText("Update");
        }       
        else {
            // Update the GUI
            txtItemID.setEnabled(true);
            btnItemAddUpdate.setText("Add");
        }
    }
    
    /**
     *  Retrieve the current item ID for the item if it was updated or added.
     *  @return String Item ID last displayed on the inventory window.
     **/
    public String getLastItemID() {
        return txtItemID.getText();
    }
    
    /**
     * True if the Cancel button was clicked instead of the Add or Update button.
     * @return boolean True if the Cancel button was clicked.
     **/
    public boolean isCancelled() {
        return m_isCancelled;
    }
    
}
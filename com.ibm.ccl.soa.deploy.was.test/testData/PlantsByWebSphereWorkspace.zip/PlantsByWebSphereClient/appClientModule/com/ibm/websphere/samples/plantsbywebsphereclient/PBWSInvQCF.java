//
//"This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own
//instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
//or for redistribution by customer, as part of such an application, in customer's own products. " 
//
//Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001,2002
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereclient;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.jms.*;

/**
 * Inventory Queue Connection Factory helper class.
 * Used to connect peer-to-peer to a JMS queue.
 */
public class PBWSInvQCF {
    QueueConnection m_connection = null;
    Context m_initCtx = null;
    
    PBWSInvQCF() {}
    
    public void start() throws 
            javax.naming.NamingException,
            javax.jms.JMSException {
        m_initCtx= new InitialContext();
     
        javax.jms.QueueConnectionFactory qcf =
            (javax.jms.QueueConnectionFactory) m_initCtx.lookup(
                "java:comp/env/jms/InvPersonQConnectionFactory");

        
        m_connection = qcf.createQueueConnection();
        m_connection.start();
    }
    
    public javax.jms.Queue getQ() throws 
            javax.naming.NamingException {
        javax.jms.Queue q = (javax.jms.Queue) m_initCtx.lookup("java:comp/env/jms/InvPersonQueue");
        return q;
    }
    
    public QueueSession getSession() throws
            javax.jms.JMSException {
        QueueSession session;
        boolean transacted = false;
        session = m_connection.createQueueSession(transacted, Session.AUTO_ACKNOWLEDGE);
        return session;
    }
    
    public void close() throws
            javax.jms.JMSException {
        m_connection.close();
    }
}
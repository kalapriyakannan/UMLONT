//
//"This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own
//instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
//or for redistribution by customer, as part of such an application, in customer's own products. " 
//
//Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001,2002
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereclient;

import javax.swing.table.AbstractTableModel;
import java.util.Vector;
import java.util.Hashtable;

/**
 * Table model for our graphical interface for the Catalog.
 */
public class PBWSCatalogTableModel extends AbstractTableModel {

    private Vector m_vRows = new Vector();
    
    private final static int COLUMNS = 4;
    public final static int COL_ITEM = 0;
    public final static int COL_NAME = 1;
    public final static int COL_DESC = 2;
    public final static int COL_CATEGORY = 3;
    
    public final static String[] COL_NAMES = {"Item", "Name", "Description", "Category"};
    
    public int getRowCount() {
        return m_vRows.size();
    }
  
    public int getColumnCount() {
        return COLUMNS;
    }
    
    public String getColumnName(int col) {
        return COL_NAMES[col];
    }

    public Class getColumnClass(int c) {
        return getValueAt(0, c).getClass();
    }
  
    public Object getValueAt(int row, int column) {
        return ((Vector)m_vRows.get(row)).get(column);
    }

    public Vector getRowByItemID(String itemID) {
        java.util.Enumeration e = null;
        for (e = m_vRows.elements();e.hasMoreElements();) {
            Vector v = (Vector) e.nextElement();
            if(((String)v.elementAt(COL_ITEM)).compareTo(itemID) == 0) {
                return v;
            }
        }
        return null;
    }

    public int findRowByItemID(String itemID) {
        Vector v = getRowByItemID(itemID);
        if (v != null) {
            return m_vRows.indexOf(v);
        }
        return -1;
    }
    
    public void updateRow(String strItem, String strName, String strDesc, String strCategory) {
        Vector v = getRowByItemID(strItem);
        if (v != null) {
            v.setElementAt(strName, COL_NAME);
            v.setElementAt(strDesc, COL_DESC);
            v.setElementAt(strCategory, COL_CATEGORY);
            int iRowUpdated = m_vRows.indexOf(v);
            
            // Notify the listeners that we've updated a row.
            this.fireTableRowsUpdated(iRowUpdated, iRowUpdated);
        }
        
    }
    
    public void addRow(String strItem, String strName, String strDesc, String strCategory) {
        // Add a new row to our Vector
        Vector v = new Vector(3);
        v.add(COL_ITEM, strItem);
        v.add(COL_NAME, strName);
        v.add(COL_DESC, strDesc);
        v.add(COL_CATEGORY, strCategory);
        m_vRows.add(v);

        int iRowAdded = m_vRows.indexOf(v);
        
        // Notify the listeners that we've added a new row.
        fireTableRowsInserted(iRowAdded,iRowAdded);
    }
    
    public void removeRow(int r) {
    	m_vRows.remove(r);
    	
    	this.fireTableRowsDeleted(r, r);
    }
    
    public void clearAllRows() {
    	int iRows = getRowCount();

		m_vRows.clear();
    	
    	this.fireTableRowsDeleted(1, iRows);
    }
}
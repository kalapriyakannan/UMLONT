package com.ibm.websphere.samples.plantsbywebsphereejb;
/**
 * Local Home interface for Enterprise Bean: IdGenerator
 */
public interface IdGeneratorHome extends javax.ejb.EJBLocalHome 
{
    /**
     * Creates an instance from a key for Entity Bean: IdGenerator
     */
    public IdGenerator create(String idName) throws javax.ejb.CreateException;
   /**
    * Creates an instance from a key for Entity Bean: IdGenerator
    */
   public IdGenerator create(String idName, int idValue) throws javax.ejb.CreateException;
   /**
    * Finds an instance using a key for Entity Bean: IdGenerator
    */
   public IdGenerator findByPrimaryKey(IdGeneratorKey primaryKey)
      throws javax.ejb.FinderException;
}

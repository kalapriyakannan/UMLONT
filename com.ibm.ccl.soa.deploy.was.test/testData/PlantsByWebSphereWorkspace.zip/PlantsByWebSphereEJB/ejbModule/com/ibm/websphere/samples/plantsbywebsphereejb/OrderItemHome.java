package com.ibm.websphere.samples.plantsbywebsphereejb;
/**
 * Local Home interface for Enterprise Bean: OrderItem
 */
public interface OrderItemHome extends javax.ejb.EJBLocalHome 
{
    /**
	 * Creates an instance from a key for Entity Bean: OrderItem
	 */
	public com.ibm.websphere.samples.plantsbywebsphereejb.OrderItem create(
		java.lang.String inventoryID)
		throws javax.ejb.CreateException;

   /**
    * Creates an instace from a key for Entity Bean: OrderItem
    */
   public OrderItem create(Order order, String orderID, String inventoryID, 
                        String name, String pkgInfo, float price, float cost, 
                        int quantity, int category, String sellDate)
      throws javax.ejb.CreateException;
      
   /**
    * Finds an instance using a key for Entity Bean: OrderItem
    */
   public OrderItem findByPrimaryKey(OrderItemKey primaryKey) throws javax.ejb.FinderException;
}

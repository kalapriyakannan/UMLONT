package com.ibm.websphere.samples.plantsbywebsphereejb;
/**
 * Local interface for Enterprise Bean: OrderItem
 */
public interface OrderItem extends javax.ejb.EJBLocalObject {
   /**
    * Get accessor for persistent attribute: inventoryID
    */
   public java.lang.String getInventoryID();
   /**
    * Set accessor for persistent attribute: inventoryID
    */
   public void setInventoryID(java.lang.String newInventoryID);
	/**
	 * Get accessor for persistent attribute: name
	 */
	public java.lang.String getName();
	/**
	 * Set accessor for persistent attribute: name
	 */
	public void setName(java.lang.String newName);
	/**
	 * Get accessor for persistent attribute: pkginfo
	 */
	public java.lang.String getPkginfo();
	/**
	 * Set accessor for persistent attribute: pkginfo
	 */
	public void setPkginfo(java.lang.String newPkginfo);
	/**
	 * Get accessor for persistent attribute: price
	 */
	public float getPrice();
	/**
	 * Set accessor for persistent attribute: price
	 */
	public void setPrice(float newPrice);
	/**
	 * Get accessor for persistent attribute: cost
	 */
	public float getCost();
	/**
	 * Set accessor for persistent attribute: cost
	 */
	public void setCost(float newCost);
	/**
	 * Get accessor for persistent attribute: category
	 */
	public int getCategory();
	/**
	 * Set accessor for persistent attribute: category
	 */
	public void setCategory(int newCategory);
	/**
	 * Get accessor for persistent attribute: quantity
	 */
	public int getQuantity();
	/**
	 * Set accessor for persistent attribute: quantity
	 */
	public void setQuantity(int newQuantity);
	/**
	 * Get accessor for persistent attribute: sellDate
	 */
	public java.lang.String getSellDate();
	/**
	 * Set accessor for persistent attribute: sellDate
	 */
	public void setSellDate(java.lang.String newSellDate);
	/**
	 * This method was generated for supporting the relationship role named order.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public com.ibm.websphere.samples.plantsbywebsphereejb.Order getOrder();
	/**
	 * This method was generated for supporting the relationship role named order.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public void setOrder(
		com.ibm.websphere.samples.plantsbywebsphereejb.Order anOrder);
}

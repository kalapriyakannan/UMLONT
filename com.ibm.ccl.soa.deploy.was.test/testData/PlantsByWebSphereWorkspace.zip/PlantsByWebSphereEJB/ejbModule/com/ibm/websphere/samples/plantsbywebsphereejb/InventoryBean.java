//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2003
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;
import java.util.*;
import javax.ejb.*;
import java.lang.Math;

/**
 * InventoryBean is the implementation class for the {@link Inventory} entity
 * EJB.  InventoryBean implements each of the business methods in the <code>Inventory</code>
 * EJB local interface and each of the EJB lifecycle methods in the javax.ejb.EntityBean
 * interface.
 * 
 * @see Inventory
 * @see InventoryHome
 * @see InventoryKey
 */

public abstract class InventoryBean implements EntityBean
{
   private javax.ejb.EntityContext myEntityCtx;

   /** 
    * Create a new Inventory.
    *
    * @param key InventoryKey
    * @param name Name of inventory item.
    * @param heading Description heading of inventory item.
    * @param desc Description of inventory item.
    * @param pkginfo Package info of inventory item.
    * @param image Image of inventory item.
    * @param price Price of inventory item.
    * @param cost Cost of inventory item.
    * @param quantity Quantity of inventory items in stock.
    * @param category Category of inventory item.
    * @param notes Notes of inventory item.
    * @param isPublic Access permission of inventory item.
    */
   public InventoryKey ejbCreate(
      InventoryKey key,
      String name,
      String heading,
      String desc,
      String pkginfo,
      String image,
      float price,
      float cost,
      int quantity,
      int category,
      String notes,
      int isPublic)
      throws CreateException
   {
      this.setInventoryID(key.inventoryID);
      Util.debug("ejbCreate(), inventoryid=" + this.getInventoryID());
      this.setName(name);
      this.setHeading(heading);
      this.setDescription(desc);
      this.setPkginfo(pkginfo);
      this.setImage(image);
      this.setPrice(price);
      this.setCost(cost);
      this.setQuantity(quantity);
      this.setCategory(category);
      this.setNotes(notes);
      this.setIsPublic(isPublic);
      return null;
   }

   /** 
    * Create a new Inventory.
    *
    * @param item StoreItem to use to make a new inventory item.
    */
   public InventoryKey ejbCreate(StoreItem item) throws CreateException
   {
      this.setInventoryID(item.getID());
      this.setName(item.getName());
      this.setHeading(item.getHeading());
      this.setDescription(item.getDescription());
      this.setPkginfo(item.getPkginfo());
      this.setImage(item.getImage());
      this.setPrice(item.getPrice());
      this.setCost(item.getCost());
      this.setQuantity(item.getQuantity());
      this.setCategory(item.getCategory());
      this.setNotes(item.getNotes());

      if (item.isPublic())
         this.setIsPublic(1);
      else
         this.setIsPublic(0);

      return null;
   }

   /**
    * Entity EJB lifecycle callback method. This method is empty for this CMP Inventory EJB.
    *
    */
   public void ejbPostCreate(InventoryKey key, String name, String heading, String desc, String pkginfo, String image, float price, float cost, int quantity, int category, String notes, int isPublic)
   {
   }

   /**
    * Entity EJB lifecycle callback method. This method is empty for this CMP Inventory EJB.
    *
    */
   public void ejbPostCreate(StoreItem item)
   {
   }

   /*** Get the inventory ID.
    * @return String The inventory ID. */
   public String getID()
   {
      return this.getInventoryID();
   }

   /*** Get the inventory ID.
    * @return String The inventory ID. */
   public abstract String getInventoryID();
   /*** Get the inventory item name.
    * @return The inventory item name. */
   public abstract String getName();
   /*** Get the inventory item description heading.
    * @return The inventory item description heading. */
   public abstract String getHeading();
   /*** Get the inventory item description.
    * @return The inventory item description. */
   public abstract String getDescription();
   /*** Get the inventory item package info.
    * @return The inventory item package info. */
   public abstract String getPkginfo();
   /*** Get the inventory item image.
    * @return The inventory item image. */
   public abstract String getImage();
   /*** Get the inventory item image binary data.
    * @return The inventory item image binary data. */
   public abstract byte[] getImgbytes();
   /*** Get the inventory item price.
    * @return The inventory item price. */
   public abstract float getPrice();
   /*** Get the inventory item cost.
    * @return The inventory item cost. */
   public abstract float getCost();
   /*** Get the inventory category.
    * @return The inventory category. */
   public abstract int getCategory();
   /*** Get the quantity of inventory in stock.
    * @return The quantity of inventory in stock. */
   public abstract int getQuantity();
   /*** Get the notes of inventory in stock.
    * @return The inventory notes. */
   public abstract String getNotes();

   public abstract int getIsPublic();

   /** 
    * Is this inventory item viewable by the public?
    *
    * @return True, if the public can view this inventory item.
    */
   public boolean isPublic()
   {
      if (this.getIsPublic() == 1)
         return true;
      else
         return false;
   }

   /** Set the inventory item's ID. */
   public abstract void setInventoryID(String inventoryID);
   /** Set the inventory item's name. */
   public abstract void setName(String name);
   /** Set the inventory item's description heading. */
   public abstract void setHeading(String heading);
   /** Set the inventory item's description. */
   public abstract void setDescription(String description);
   /** Set the inventory item's package info. */
   public abstract void setPkginfo(String pkginfo);
   /** Set the inventory item's image. */
   public abstract void setImage(String image);
   /** Set the inventory item's image binary data. */
   public abstract void setImgbytes(byte[] imgbytes);
   /** Set the inventory item's price. */
   public abstract void setPrice(float price);
   /** Set the inventory item's cost. */
   public abstract void setCost(float cost);
   /** Set the inventory item's quantity in stock. */
   public abstract void setQuantity(int quantity);
   /** Set the inventory item's category. */
   public abstract void setCategory(int category);
   /** Set the inventory item's notes. */
   public abstract void setNotes(String notes);
   /** Set the inventory item's public flag. */
   public abstract void setIsPublic(int isPublic);

   /** Set the inventory item's public availability. */
   public void setPrivacy(boolean isPublic)
   {
      if (isPublic)
         this.setIsPublic(1);
      else
         this.setIsPublic(0);
   }

   /**
    * Increase the quantity of this inventory item.
    * @param quantity The number to increase the inventory by.
    */
   public void increaseInventory(int quantity)
   {
      this.setQuantity(this.getQuantity() + quantity);
   }

   /**
    * Create a BackOrder of this inventory item.
    * @param quantity The number of the inventory item to be backordered
    */
   private void backOrder(int amountToOrder)
   {

      try
      {
         BackOrderStockHome backOrderStockHome = (BackOrderStockHome) Util.getEJBHome("java:comp/env/ejb/BackOrderStock", com.ibm.websphere.samples.plantsbywebsphereejb.BackOrderStockHome.class);
         BackOrderStock backOrderStock = backOrderStockHome.create();
         backOrderStock.createBackOrder(this.getInventoryID(), amountToOrder, this.getMaxThreshold());
         backOrderStock.remove();
      }
      catch (Exception e)
      {
         Util.debug("InventoryBean.backOrder() - Exception: " + e);
      }
   }
   /**
    * Decrease the quantity of this inventory item.
    * @param quantity The number to decrease the inventory by.
    * @return The number of inventory items removed.
    */
   public int decreaseInventory(int quantity)
   {
      int minimumItems = this.getMinThreshold();

      int amountToOrder = 0;
      Util.debug("InventoryBean.decreaseInventory() - Decreasing inventory item");
      int quantityNotFilled = 0;
      if (this.getQuantity() < 1)
      {
         quantityNotFilled = quantity;
      }
      else
         if (this.getQuantity() < quantity)
         {
            quantityNotFilled = quantity - this.getQuantity();
         }

      // When quantity becomes < 0, this will be to determine the
      // quantity of unfilled orders due to insufficient stock.
      this.setQuantity(this.getQuantity() - quantity);

      //  Check to see if more inventory needs to be ordered from the supplier
      //  based on a set minimum Threshold
      if (this.getQuantity() < minimumItems)
      {
         // Calculate the amount of stock to order from the supplier
         // to get the inventory up to the maximum.
         amountToOrder = quantityNotFilled;
         backOrder(amountToOrder);
      }
      return quantity;
   }

   /** ejbLoad Session EJB lifecycle callback method.*/
   public void ejbLoad()
   {
   }
   /** ejbStore Session EJB lifecycle callback method.*/
   public void ejbStore()
   {
   }
   /** ejbRemove Session EJB lifecycle callback method.*/
   public void ejbRemove()
   {
   }
   /** ejbActivate Session EJB lifecycle callback method.*/
   public void ejbActivate()
   {
   }
   /** ejbPassivate Session EJB lifecycle callback method.*/
   public void ejbPassivate()
   {
   }
   /**
    * setEntityContext Entity EJB lifecycle callback method to set the EJB entityContext for this EJB.
    *
    * @param ctx javax.ejb.EntityContext The context for this entity EJB.
    */
   public void setEntityContext(EntityContext ctx)
   {
      myEntityCtx = ctx;
   }
   /**
    * getEntityContext
    */
   public javax.ejb.EntityContext getEntityContext()
   {
      return myEntityCtx;
   }
   /**
    * unsetEntityContext Entity EJB lifecycle callback method to unset the EJB entityContext for this EJB.
    */
   public void unsetEntityContext()
   {
      myEntityCtx = null;
   }
   /**
    * ejbCreate
    */
   public com.ibm.websphere.samples.plantsbywebsphereejb.InventoryKey ejbCreate(java.lang.String inventoryID) throws javax.ejb.CreateException
   {
      setInventoryID(inventoryID);
      return null;
   }
   /**
    * ejbPostCreate
    */
   public void ejbPostCreate(java.lang.String inventoryID) throws javax.ejb.CreateException
   {
   }
   /**
    * Method getMinThreshold.
    * @return int
    */
   /**
    * Get accessor for persistent attribute: minThreshold
    */
   public abstract int getMinThreshold();
   /**
    * Method setMinThreshold.
    * @param newMinThreshold
    */
   /**
    * Set accessor for persistent attribute: minThreshold
    */
   public abstract void setMinThreshold(int newMinThreshold);
   /**
    * Method getMaxThreshold.
    * @return int
    */
   /**
    * Get accessor for persistent attribute: maxThreshold
    */
   public abstract int getMaxThreshold();
   /**
    * Method setMaxThreshold.
    * @param newMaxThreshold
    */
   /**
    * Set accessor for persistent attribute: maxThreshold
    */
   public abstract void setMaxThreshold(int newMaxThreshold);
}

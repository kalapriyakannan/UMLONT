//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

/**
 * MailerAppException extends the standard Exception.
 * This is thrown by the mailer component when there is some
 * failure sending the mail.
 */
public class MailerAppException extends Exception {

    public MailerAppException() {}

    public MailerAppException(String str) {
        super(str);
    }
}

//
// "This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
// instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
// or for redistribution by customer, as part of such an application, in customer's own products. " 
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2003,2003
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;


/**
 * Remote interface for Enterprise Bean: BackOrder
 */
public interface BackOrder extends javax.ejb.EJBObject
{
   /**
    * Method getBackOrderID.
    * @return String
    * @throws RemoteException
    */
   public java.lang.String getBackOrderID() throws RemoteException;
   /**
    * Method setBackOrderID.
    * @param newBackOrderID
    * @throws RemoteException
    */
   public void setBackOrderID(java.lang.String newBackOrderID) throws RemoteException;
   /**
    * Method getName.
    * @return String
    * @throws RemoteException
    */
   public java.lang.String getName() throws RemoteException;

   /**
    * Method getQuantity.
    * @return int
    * @throws RemoteException
    */
   public int getQuantity() throws RemoteException;
   /**
    * Method setQuantity.
    * @param newQuantity
    * @throws RemoteException
    */
   public void setQuantity(int newQuantity) throws RemoteException;

   /**
    * Method getInventoryQuantity
    * @return int
    */
   public int getInventoryQuantity() throws RemoteException;
   /**
    * Method getStatus.
    * @return String
    * @throws RemoteException
    */
   public java.lang.String getStatus() throws RemoteException;
   /**
    * Method setStatus.
    * @param newStatus
    * @throws RemoteException
    */
   public void setStatus(java.lang.String newStatus) throws RemoteException;
   /**
    * Method getInventoryID.
    * @return String
    * @throws RemoteException
    */
   public java.lang.String getInventoryID() throws RemoteException;
   /**
    * Method setInventoryID.
    * @param newInventoryID
    * @throws RemoteException
    */
   public void setInventoryID(java.lang.String newInventoryID) throws RemoteException;
   /**
    * Method getLowDate.
    * @return long
    * @throws RemoteException
    */
   /**
    * Get accessor for persistent attribute: lowDate
    */
   public long getLowDate() throws java.rmi.RemoteException;
   /**
    * Method setLowDate.
    * @param newLowDate
    * @throws RemoteException
    */
   /**
    * Set accessor for persistent attribute: lowDate
    */
   public void setLowDate(long newLowDate) throws java.rmi.RemoteException;
   /**
    * Get accessor for persistent attribute: orderDate
    */
   public long getOrderDate() throws java.rmi.RemoteException;
   /**
    * Method setOrderDate.
    * @param newOrderDate
    * @throws RemoteException
    */
   /**
    * Set accessor for persistent attribute: orderDate
    */
   public void setOrderDate(long newOrderDate) throws java.rmi.RemoteException;
}

//
//"This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
//instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
//or for redistribution by customer, as part of such an application, in customer's own products. " 
//
//Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2003,2003
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;
import java.util.Collection;

import javax.ejb.EJBException;
import javax.ejb.FinderException;

/**
 * Bean implementation class for Enterprise Bean: BackOrder
 */
public abstract class BackOrderBean implements javax.ejb.EntityBean
{
   private javax.ejb.EntityContext myEntityCtx;
   /**
    * @see javax.ejb.EntityBean#setEntityContext(EntityContext)
    */
   public void setEntityContext(javax.ejb.EntityContext ctx)
   {
      myEntityCtx = ctx;
   }
   /**
    * Method getEntityContext.
    * @return EntityContext
    */
   public javax.ejb.EntityContext getEntityContext()
   {
      return myEntityCtx;
   }
   /**
    * @see javax.ejb.EntityBean#unsetEntityContext()
    */
   public void unsetEntityContext()
   {
      myEntityCtx = null;
   }
   /**
    * Method ejbPostCreate.
    * @param InventoryItem
    * @throws CreateException
    */
   public void ejbPostCreate(Inventory InventoryItem) throws javax.ejb.CreateException
   {
   }
   /**
    * @see javax.ejb.EntityBean#ejbActivate()
    */
   /**
    * ejbActivate
    */
   public void ejbActivate()
   {
   }
   /**
    * @see javax.ejb.EntityBean#ejbLoad()
    */
   public void ejbLoad()
   {
   }
   /**
    * @see javax.ejb.EntityBean#ejbPassivate()
    */
   public void ejbPassivate()
   {
   }
   /**
    * @see javax.ejb.EntityBean#ejbRemove()
    */
   public void ejbRemove() throws javax.ejb.RemoveException
   {
   }
   /**
    * @see javax.ejb.EntityBean#ejbStore()
    */
   public void ejbStore()
   {
   }
   private InventoryHome inventoryHome = null;

   /**
    * Method getInventoryHome.
    * @return InventoryHome
    */
   public InventoryHome getInventoryHome()
   {
      try
      {
         if (inventoryHome == null)
         {
            inventoryHome = (InventoryHome) Util.getEJBLocalHome("java:comp/env/ejb/Inventory", com.ibm.websphere.samples.plantsbywebsphereejb.InventoryHome.class);
         }
      }
      catch (Exception e)
      {
         Util.debug("BackOrderBean.getInventoryHome() - Exception: " + e);
         throw new EJBException(e);
      }
      return inventoryHome;
   }
   /**
    * Method getInventoryitem.
    * @return Inventory
    */
   public Inventory getInventoryitem()
   {
      Inventory inv = null;
      try
      {
         inv = getInventoryHome().findByPrimaryKey(new InventoryKey(this.getInventoryID()));
      }
      catch (Exception e)
      {
         Util.debug("BackOrderBean.getInventoryitem() - " + e);
      }
      return (inv);
   }
   /**
    * Method getName.
    * @return String
    */
   public java.lang.String getName()
   {
      String backOrderName = "";
      try
      {
         Util.debug("BackOrderBean.getName() - Entered");
         Inventory inv = this.getInventoryitem();
         if (inv != null)
            backOrderName = inv.getName();
      }
      catch (Exception e)
      {
         Util.debug("BackOrderBean.getName() - Exception: " + e);
      }
      return backOrderName;
   }
   /**
    * Method getInventoryQuantity
    * @return int
    */
   public int getInventoryQuantity()
   {
      int inventoryQuantity = 0;
      try
      {
         Util.debug("BackOrderBean.getInventoryQuantity() - Entered");
         Inventory inv = this.getInventoryitem();
         if (inv != null)
            inventoryQuantity = inv.getQuantity();
      }
      catch (Exception e)
      {
         Util.debug("BackOrderBean.getInventoryQuantity() - Exception: " + e);
      }
      return inventoryQuantity;
   }
   /**
    * Method getQuantity.
    * @return int
    */
   public abstract int getQuantity();
   /**
    * Method setQuantity.
    * @param newQuantity
    */
   public abstract void setQuantity(int newQuantity);
   /**
    * Method getStatus.
    * @return String
    */
   public abstract java.lang.String getStatus();
   /**
    * Method setStatus.
    * @param newStatus
    */
   public abstract void setStatus(java.lang.String newStatus);
   /**
    * Method setInventoryID.
    * @param newInventoryID
    */
   public abstract void setInventoryID(java.lang.String newInventoryID);
   /**
    * Method getInventoryID.
    * @return String
    */
   public abstract java.lang.String getInventoryID();
   /**
    * Method ejbCreate.
    * @param backOrderID
    * @return BackOrderKey
    * @throws CreateException
    */
   public com.ibm.websphere.samples.plantsbywebsphereejb.BackOrderKey ejbCreate(java.lang.String backOrderID) throws javax.ejb.CreateException
   {
      setBackOrderID(backOrderID);
      return null;
   }
   /**
    * Method ejbPostCreate.
    * @param backOrderID
    * @throws CreateException
    */
   public void ejbPostCreate(java.lang.String backOrderID) throws javax.ejb.CreateException
   {
   }
   /**
    * Method ejbCreate.
    * @param inventoryID
    * @param quantity
    * @return BackOrderKey
    * @throws CreateException
    */
   public com.ibm.websphere.samples.plantsbywebsphereejb.BackOrderKey ejbCreate(java.lang.String inventoryID, int quantity) throws javax.ejb.CreateException
   {
      try
      {
         // Get the Order ID to uniquely identity this BackOrder.
         IdGeneratorHome idGeneratorHome = (IdGeneratorHome) Util.getEJBLocalHome("java:comp/env/ejb/IdGenerator", com.ibm.websphere.samples.plantsbywebsphereejb.IdGeneratorHome.class);
         IdGenerator idGenerator = idGeneratorHome.findByPrimaryKey(new IdGeneratorKey("BACKORDER"));

         int orderInt = idGenerator.nextId();

         Util.debug("BackOrderBean.ejbCreate() - Setting backOrderID in BackOrder EJB to " + orderInt);
         this.setBackOrderID(new Integer(orderInt).toString());
         Util.debug("BackOrderBean.ejbCreate() - Setting inventoryID in BackOrder EJB to " + inventoryID);
         this.setInventoryID(inventoryID);
         Util.debug("BackOrderBean.ejbCreate() - Setting Quantity in BackOrder EJB to " + quantity);
         this.setQuantity(quantity);
         Util.debug("BackOrderBean.ejbCreate() - Setting STATUS_ORDERSTOCK in BackOrder EJB to " + Util.STATUS_ORDERSTOCK);
         this.setStatus(Util.STATUS_ORDERSTOCK);

         this.setLowDate(System.currentTimeMillis());
      }
      catch (Exception e)
      {
         Util.debug("BackOrderBean.ejbCreate() - Exception: " + e);
      }
      return null;
   }
   /**
    * Method ejbPostCreate.
    * @param inventoryID
    * @param quantity
    * @throws CreateException
    */
   public void ejbPostCreate(java.lang.String inventoryID, int quantity) throws javax.ejb.CreateException
   {
   }
   /**
    * Method getBackOrderID.
    * @return String
    */
   /**
    * Get accessor for persistent attribute: backOrderID
    */
   public abstract java.lang.String getBackOrderID();
   /**
    * Method setBackOrderID.
    * @param newBackOrderID
    */
   /**
    * Set accessor for persistent attribute: backOrderID
    */
   public abstract void setBackOrderID(java.lang.String newBackOrderID);
   /**
    * Get accessor for persistent attribute: lowDate
    */
   public abstract long getLowDate();
   /**
    * Method setLowDate.
    * @param newLowDate
    */
   /**
    * Set accessor for persistent attribute: lowDate
    */
   public abstract void setLowDate(long newLowDate);
   /**
    * Method getOrderDate.
    * @return long
    */
   /**
    * Get accessor for persistent attribute: orderDate
    */
   public abstract long getOrderDate();
   /**
    * Method setOrderDate.
    * @param newOrderDate
    */
   /**
    * Set accessor for persistent attribute: orderDate
    */
   public abstract void setOrderDate(long newOrderDate);
}

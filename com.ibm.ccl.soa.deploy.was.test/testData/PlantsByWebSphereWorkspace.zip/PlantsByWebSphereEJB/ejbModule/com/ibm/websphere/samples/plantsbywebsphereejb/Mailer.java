//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;

/**
 * Remote interface for the Mailer session bean.
 */
public interface Mailer extends javax.ejb.EJBObject 
{
    /**
     * This method sends an email message.
     *
     * @param eMessage Contents for the email message.
     * @see   EMailMessage
     */
    public void createAndSendMail(EMailMessage eMessage) throws MailerAppException,
       RemoteException;

}

//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;

/**
 * A class to hold a store item's data.
 */
public class StoreItem implements java.io.Serializable
{
   private String id;
   private String name;
   private String heading;
   private String desc;
   private String pkginfo;
   private String image;
   private float price;
   private float cost;
   private int quantity;
   private int category;
   private String notes;
   private boolean isPublic;
   
   /** Default constructor. */
   public StoreItem() { }

   /** Constructor of store item
    * @param id - id of this store item.
    * @param name - name of this store item.
    * @param pkginfo - package info of this store item.
    * @param price - price of this store item.
    * @param cost - cost of this store item.
    * @param category - category of this store item.
    * @param quantity - quantity of this store item.
    */
   public StoreItem(String id, String name, String pkginfo,
                    float price, float cost, int category, 
                    int quantity)
   {
      this.id = id;
      this.name = name;
      this.pkginfo = pkginfo;
      this.price = price;
      this.cost = cost;
      this.category = category;
      this.quantity = quantity;
   }

   /** Constructor of store item
    * @param id - id of this store item.
    * @param name - name of this store item.
    * @param heading - description heading of this store item.
    * @param desc - description of this store item.
    * @param pkginfo - package info of this store item.
    * @param image - image of this store item.
    * @param price - price of this store item.
    * @param cost - cost of this store item.
    * @param quantity - quantity of this store item.
    * @param category - category of this store item.
    * @param notes - notes of this store item.
    * @param isPublic - isPublic flag of this store item.
    */
   public StoreItem(String id, String name, String heading, 
                    String desc, String pkginfo, String image, 
                    float price, float cost, int quantity, 
                    int category, String notes, boolean isPublic)
   {
      this.id = id;
      this.name = name;
      this.heading = heading;
      this.desc = desc;
      this.pkginfo = pkginfo;
      this.image = image;
      this.price = price;
      this.cost = cost;
      this.quantity = quantity;
      this.category = category;
      this.notes = notes;
      this.isPublic = isPublic;
   }

   /**
    * Constructor to convert an Inventory object to StoreItem.
    * @param inv - Inventory item
    */
   public StoreItem(Inventory inv)
   {
      this.id = inv.getID();
      this.name = inv.getName();
      this.heading = inv.getHeading();
      this.desc = inv.getDescription();
      this.pkginfo = inv.getPkginfo();
      this.image = inv.getImage();
      this.price = inv.getPrice();
      this.cost = inv.getCost();
      this.category = inv.getCategory();
      this.quantity = inv.getQuantity();
      this.notes = inv.getNotes();
      this.isPublic = inv.isPublic();
   }

   /** Compares equality of store items. */
   public boolean equals(StoreItem si)
   {
      return si.getID().equals(this.id);
   }

   /** Get the ID of this store item. */
   public String getID() { return id; }
   /** Get the name of this store item. */
   public String getName() { return name; }
   /** Get the description heading of this store item. */
   public String getHeading() { return heading; }
   /** Get the description of this store item. */
   public String getDescription() { return desc; }
   /** Get the package info of this store item. */
   public String getPkginfo() { return pkginfo; }
   /** Get the image file of this store item. */
   public String getImage() { return image; }
   /** Get the price of this store item. */
   public float getPrice() { return price; }
   /** Get the cost of this store item. */
   public float getCost() { return cost; }
   /** Get the quantity of this store item. */
   public int getQuantity() { return quantity; }
   /** Get the category of this store item. */
   public int getCategory() { return category; }
   /** Get the notes of this store item. */
   public String getNotes() { return notes; }
   /** Is this store item viewable by the public? */
   public boolean isPublic() { return isPublic; }

   /** Set the quantity of this store item. */
   public void setQuantity(int quantity) { this.quantity = quantity; }

}

package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.util.Vector;
import javax.ejb.EJBException;


/**
 * Bean implementation class for Enterprise Bean: Order
 */
public abstract class OrderBean implements javax.ejb.EntityBean 
{
   public static final String ORDER_INFO_TABLE_NAME = "java:comp/env/plantsby/OrderInfoTableName";
   public static final String ORDER_ITEMS_TABLE_NAME = "java:comp/env/plantsby/OrderItemsTableName";

   private javax.ejb.EntityContext myEntityCtx;
   
   private Vector items = null;
	  	
   /**
    * Constructor to create an Order.
    *
    * @param customerID - customer's ID
    * @param billName - billing name
    * @param billAddr1 - billing address line 1
    * @param billAddr2 - billing address line 2
    * @param billCity - billing address city
    * @param billState - billing address state
    * @param billZip - billing address zip code
    * @param billPhone - billing phone
    * @param shipName - shippng name
    * @param shipAddr1 - shippng address line 1
    * @param shipAddr2 - shippng address line 2
    * @param shipCity - shippng address city
    * @param shipState - shippng address state
    * @param shipZip - shippng address zip code
    * @param shipPhone - shippng phone
    * @param creditCard - credit card
    * @param ccNum - credit card number
    * @param ccExpireMonth - credit card expiration month
    * @param ccExpireYear - credit card expiration year
    * @param cardHolder - credit card holder name
    * @param shippingMethod int of shipping method used
    * @param items vector of StoreItems ordered
    * @return key of Order created
    */
   public OrderKey ejbCreate(String customerID, String billName, String billAddr1, String billAddr2,
             String billCity, String billState, String billZip, String billPhone,
             String shipName, String shipAddr1, String shipAddr2,
             String shipCity, String shipState, String shipZip, String shipPhone,
             String creditCard, String ccNum, String ccExpireMonth, String ccExpireYear,
             String cardHolder, int shippingMethod, Vector items)
		throws javax.ejb.CreateException
   {
      this.setSellDate(Long.toString(System.currentTimeMillis()));

      // Pad it to 14 digits so sorting works properly.
      if (this.getSellDate().length() < 14)
      {
         StringBuffer sb = new StringBuffer(Util.ZERO_14);
         sb.replace((14 - this.getSellDate().length()), 14, this.getSellDate());
         this.setSellDate(sb.toString());
      }

      this.setCustomerID(customerID);
      this.setBillName(billName);
      this.setBillAddr1(billAddr1);
      this.setBillAddr2(billAddr2);
      this.setBillCity(billCity);
      this.setBillState(billState);
      this.setBillZip(billZip);
      this.setBillPhone(billPhone);
      this.setShipName(shipName);
      this.setShipAddr1(shipAddr1);
      this.setShipAddr2(shipAddr2);
      this.setShipCity(shipCity);
      this.setShipState(shipState);
      this.setShipZip(shipZip);
      this.setShipPhone(shipPhone);
      this.setCreditCard(creditCard);
      this.setCcNum(ccNum);
      this.setCcExpireMonth(ccExpireMonth);
      this.setCcExpireYear(ccExpireYear);
      this.setCardHolder(cardHolder);
      this.setShippingMethod(shippingMethod);

      // Get profit for total order.
      StoreItem si;
      float profit;
      profit = 0.0f;
      for (int i = 0; i < items.size(); i++)
      {
         si = (StoreItem) items.elementAt(i);
         profit = profit + (si.getQuantity() * (si.getPrice() - si.getCost()));
      }
      this.setProfit(profit);
      
      IdGeneratorHome idGeneratorHome = (IdGeneratorHome) Util.getEJBLocalHome("java:comp/env/ejb/IdGenerator",
               com.ibm.websphere.samples.plantsbywebsphereejb.IdGeneratorHome.class);

      try
      {        
         IdGenerator idGenerator= idGeneratorHome.findByPrimaryKey(new IdGeneratorKey("ORDER"));
         int orderInt = idGenerator.nextId();
     	 this.setOrderID(Integer.toString(orderInt)); 
      }
      catch(Exception e) 
      {        
         e.printStackTrace();
         throw new RuntimeException();
      }

      return new OrderKey(getOrderID());

   }

   /**
    * ejbPostCreate
    */
   public void ejbPostCreate(String customerID, String billName, String billAddr1, String billAddr2,
                 String billCity, String billState, String billZip, String billPhone,
                 String shipName, String shipAddr1, String shipAddr2,
                 String shipCity, String shipState, String shipZip, String shipPhone,
                 String creditCard, String ccNum, String ccExpireMonth, String ccExpireYear,
                 String cardHolder, int shippingMethod, Vector items)
		throws javax.ejb.CreateException
	{
      this.items = (Vector) items.clone();      
      Vector orderItems= new Vector();

      OrderKey orderKey= (OrderKey) this.myEntityCtx.getPrimaryKey();
      OrderItemHome orderItemHome = (OrderItemHome) Util.getEJBLocalHome("java:comp/env/ejb/OrderItem",
           com.ibm.websphere.samples.plantsbywebsphereejb.OrderItemHome.class);

      try 
      {
         for (int i = 0; i < items.size(); i++) 
         {
            StoreItem si;
            si = (StoreItem) items.elementAt(i);
            Util.debug("OrderBean.ejbPostCreate() orderID=" + orderKey.getOrderID() + "=");
            OrderItem item= orderItemHome.create(
               (Order) this.myEntityCtx.getEJBLocalObject(), orderKey.getOrderID(), si.getID(),
                  si.getName(), si.getPkginfo(), si.getPrice(), si.getCost(),
                  si.getQuantity(),si.getCategory(), getSellDate()); 

               orderItems.add(item);
         }
         setOrderitem(orderItems);             
      }    
      catch (Exception e) 
      {
         throw new EJBException(e);
      }                          
	}
   
   /**
    * ejbCreate
    */
   public com.ibm.websphere.samples.plantsbywebsphereejb.OrderKey ejbCreate(java.lang.String orderID) throws javax.ejb.CreateException
   {
      setOrderID(orderID);
      return null;
   }
   /**
    * ejbPostCreate
    */
   public void ejbPostCreate(java.lang.String orderID) throws javax.ejb.CreateException
   {
   }
	/**
	 * Get accessor for persistent attribute: orderID
	 */
   public abstract java.lang.String getOrderID();
	/**
	 * Set accessor for persistent attribute: orderID
	 */
	public abstract void setOrderID(java.lang.String newOrderID);
	/**
	 * Get accessor for persistent attribute: sellDate
	 */
	public abstract java.lang.String getSellDate();
	/**
	 * Set accessor for persistent attribute: sellDate
	 */
	public abstract void setSellDate(java.lang.String newSellDate);
	/**
	 * Get accessor for persistent attribute: billName
	 */
	public abstract java.lang.String getBillName();
	/**
	 * Set accessor for persistent attribute: billName
	 */
	public abstract void setBillName(java.lang.String newBillName);
	/**
	 * Get accessor for persistent attribute: billAddr1
	 */
	public abstract java.lang.String getBillAddr1();
	/**
	 * Set accessor for persistent attribute: billAddr1
	 */
	public abstract void setBillAddr1(java.lang.String newBillAddr1);
	/**
	 * Get accessor for persistent attribute: billAddr2
	 */
	public abstract java.lang.String getBillAddr2();
	/**
	 * Set accessor for persistent attribute: billAddr2
	 */
	public abstract void setBillAddr2(java.lang.String newBillAddr2);
	/**
	 * Get accessor for persistent attribute: billCity
	 */
	public abstract java.lang.String getBillCity();
	/**
	 * Set accessor for persistent attribute: billCity
	 */
	public abstract void setBillCity(java.lang.String newBillCity);
	/**
	 * Get accessor for persistent attribute: billState
	 */
	public abstract java.lang.String getBillState();
	/**
	 * Set accessor for persistent attribute: billState
	 */
	public abstract void setBillState(java.lang.String newBillState);
	/**
	 * Get accessor for persistent attribute: billZip
	 */
	public abstract java.lang.String getBillZip();
	/**
	 * Set accessor for persistent attribute: billZip
	 */
	public abstract void setBillZip(java.lang.String newBillZip);
	/**
	 * Get accessor for persistent attribute: billPhone
	 */
	public abstract java.lang.String getBillPhone();
	/**
	 * Set accessor for persistent attribute: billPhone
	 */
	public abstract void setBillPhone(java.lang.String newBillPhone);
	/**
	 * Get accessor for persistent attribute: shipName
	 */
	public abstract java.lang.String getShipName();
	/**
	 * Set accessor for persistent attribute: shipName
	 */
	public abstract void setShipName(java.lang.String newShipName);
	/**
	 * Get accessor for persistent attribute: shipAddr1
	 */
	public abstract java.lang.String getShipAddr1();
	/**
	 * Set accessor for persistent attribute: shipAddr1
	 */
	public abstract void setShipAddr1(java.lang.String newShipAddr1);
	/**
	 * Get accessor for persistent attribute: shipAddr2
	 */
	public abstract java.lang.String getShipAddr2();
	/**
	 * Set accessor for persistent attribute: shipAddr2
	 */
	public abstract void setShipAddr2(java.lang.String newShipAddr2);
	/**
	 * Get accessor for persistent attribute: shipCity
	 */
	public abstract java.lang.String getShipCity();
	/**
	 * Set accessor for persistent attribute: shipCity
	 */
	public abstract void setShipCity(java.lang.String newShipCity);
	/**
	 * Get accessor for persistent attribute: shipState
	 */
	public abstract java.lang.String getShipState();
	/**
	 * Set accessor for persistent attribute: shipState
	 */
	public abstract void setShipState(java.lang.String newShipState);
	/**
	 * Get accessor for persistent attribute: shipZip
	 */
	public abstract java.lang.String getShipZip();
	/**
	 * Set accessor for persistent attribute: shipZip
	 */
	public abstract void setShipZip(java.lang.String newShipZip);
	/**
	 * Get accessor for persistent attribute: shipPhone
	 */
	public abstract java.lang.String getShipPhone();
	/**
	 * Set accessor for persistent attribute: shipPhone
	 */
	public abstract void setShipPhone(java.lang.String newShipPhone);
	/**
	 * Get accessor for persistent attribute: creditCard
	 */
	public abstract java.lang.String getCreditCard();
	/**
	 * Set accessor for persistent attribute: creditCard
	 */
	public abstract void setCreditCard(java.lang.String newCreditCard);
	/**
	 * Get accessor for persistent attribute: ccNum
	 */
	public abstract java.lang.String getCcNum();
	/**
	 * Set accessor for persistent attribute: ccNum
	 */
	public abstract void setCcNum(java.lang.String newCcNum);
	/**
	 * Get accessor for persistent attribute: ccExpireMonth
	 */
	public abstract java.lang.String getCcExpireMonth();
	/**
	 * Set accessor for persistent attribute: ccExpireMonth
	 */
	public abstract void setCcExpireMonth(java.lang.String newCcExpireMonth);
	/**
	 * Get accessor for persistent attribute: ccExpireYear
	 */
	public abstract java.lang.String getCcExpireYear();
	/**
	 * Set accessor for persistent attribute: ccExpireYear
	 */
	public abstract void setCcExpireYear(java.lang.String newCcExpireYear);
	/**
	 * Get accessor for persistent attribute: cardHolder
	 */
	public abstract java.lang.String getCardHolder();
	/**
	 * Set accessor for persistent attribute: cardHolder
	 */
	public abstract void setCardHolder(java.lang.String newCardHolder);
	/**
	 * Get accessor for persistent attribute: shippingMethod
	 */
	public abstract int getShippingMethod();
	/**
	 * Set accessor for persistent attribute: shippingMethod
	 */
	public abstract void setShippingMethod(int newShippingMethod);
	/**
	 * Get accessor for persistent attribute: profit
	 */
	public abstract float getProfit();
	/**
	 * Set accessor for persistent attribute: profit
	 */
	public abstract void setProfit(float newProfit);
	
   /**
    * setEntityContext
    */
   public void setEntityContext(javax.ejb.EntityContext ctx) {
      myEntityCtx = ctx;
   }
   /**
    * getEntityContext
    */
   public javax.ejb.EntityContext getEntityContext() {
   	 return myEntityCtx;
   }
   /**
    * unsetEntityContext
    */
   public void unsetEntityContext() {
      myEntityCtx = null;
   }

   /**
    * ejbActivate
    */
   public void ejbActivate() {   }
   /**
    * ejbLoad
    */
   public void ejbLoad() {   }
   /**
    * ejbPassivate
    */
   public void ejbPassivate() {   }
   /**
    * ejbRemove
    */
   public void ejbRemove() throws javax.ejb.RemoveException {   }
   /**
    * ejbStore
    */
   public void ejbStore() {   }

   /**
    * Get accessor for persistent attribute: customerID
    */
   public abstract java.lang.String getCustomerID();
   /**
    * Set accessor for persistent attribute: customerID
    */
   public abstract void setCustomerID(java.lang.String newCustomerID);
	/**
	 * This method was generated for supporting the relationship role named orderitem.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract java.util.Collection getOrderitem();
	/**
	 * This method was generated for supporting the relationship role named orderitem.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract void setOrderitem(java.util.Collection anOrderitem);
}

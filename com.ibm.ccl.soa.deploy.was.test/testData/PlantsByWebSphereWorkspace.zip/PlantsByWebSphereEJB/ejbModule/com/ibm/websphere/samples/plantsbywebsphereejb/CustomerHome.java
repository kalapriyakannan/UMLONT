//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

/**
 * Home interface for Customer entity bean.
 */
import javax.ejb.CreateException;
import javax.ejb.FinderException;

public interface CustomerHome extends javax.ejb.EJBLocalHome
{
   public abstract Customer create(CustomerKey key, String password, String firstName,
                          String lastName, String addr1, String addr2,
                          String addrCity, String addrState,
                          String addrZip, String phone) throws CreateException;

   public abstract Customer findByPrimaryKey (CustomerKey id) throws FinderException;
}


//
//"This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
//instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
//or for redistribution by customer, as part of such an application, in customer's own products. " 
//
//Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001,2002
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.io.*;

/**
 * The key class of the Order entity bean.
 **/
public class OrderKey implements Serializable 
{
   public String orderID;

   /**
    * Constructs an OrderKey object.
    */
   public OrderKey() 
   {    }

   /**
    * Constructs a newly allocated OrderKey object that represents the primitive long argument.
    */
   public OrderKey(String orderID) 
   { 
      this.orderID = orderID; 
   }

   /**
    * Determines if the OrderKey object passed to the method matches this OrderKey object.
    * @param obj java.lang.Object The OrderKey object to compare to this OrderKey object.
    * @return boolean The pass object is either equal to this OrderKey object (true) or not.
    */
   public boolean equals(Object obj) 
   {
      if (obj instanceof OrderKey) 
      {
         OrderKey otherKey = (OrderKey) obj;
         return (((orderID.equals(otherKey.orderID))));
      } 
      else 
         return false;
   }

   /**
    * Generates a hash code for this OrderKey object.
    * @return int The hash code.
    */
   public int hashCode() 
   {
      return ( orderID.hashCode() );
   }
   
   	/**
	 * Get accessor for persistent attribute: orderID
	 */
	public java.lang.String getOrderID() {
		return orderID;
	}
	/**
	 * Set accessor for persistent attribute: orderID
	 */
	public void setOrderID(java.lang.String newOrderID) {
		orderID = newOrderID;
	}

}

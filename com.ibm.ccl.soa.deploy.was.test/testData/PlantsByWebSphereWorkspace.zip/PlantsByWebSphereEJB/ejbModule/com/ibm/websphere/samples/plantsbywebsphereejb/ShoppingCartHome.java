//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

/**
 * Home interface for ShoppingCart stateful session bean.
 */
import java.rmi.RemoteException;
import javax.ejb.CreateException;

public interface ShoppingCartHome extends javax.ejb.EJBHome
{
    /**
     * Create a shopping cart.
     *
     * @return ShoppingCart The ShoppingCart EJB object.
     * @exception javax.ejb.CreateException ShoppingCart EJB object was not created.
     */
    public ShoppingCart create() throws CreateException, RemoteException;

    /**
     * Create a shopping cart.
     *
     * @param cartContents Contents to populate cart with.
     * @return ShoppingCart The ShoppingCart EJB object.
     * @exception javax.ejb.CreateException ShoppingCart EJB object was not created.
     */
    public ShoppingCart create(ShoppingCartContents cartContents) throws CreateException, 
       RemoteException;
}


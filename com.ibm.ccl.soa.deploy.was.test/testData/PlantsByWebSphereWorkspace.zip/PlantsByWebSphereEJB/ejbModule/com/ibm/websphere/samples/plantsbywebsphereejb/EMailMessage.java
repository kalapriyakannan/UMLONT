//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

/**
 * This class encapsulates the info needed to send an email
 * message. This object is passed to the Mailer EJB 
 * sendMail() method.
 */
public class EMailMessage implements java.io.Serializable 
{
    private String subject;
    private String htmlContents;
    private String emailReceiver;

    public EMailMessage( String subject, String htmlContents,
                         String emailReceiver) {
        this.subject       = subject;
        this.htmlContents  = htmlContents;
        this.emailReceiver = emailReceiver;
    }

    //subject field of email message
    public String getSubject() {
        return subject;
    }

    //Email address of recipient of email message
    public String getEmailReceiver() {
        return emailReceiver;
    }

    //contents of email message
    public String getHtmlContents() {
        return htmlContents;
    }

    public String toString() {
        return  " subject=" + subject + " " +  emailReceiver + " " + htmlContents;
    }
}


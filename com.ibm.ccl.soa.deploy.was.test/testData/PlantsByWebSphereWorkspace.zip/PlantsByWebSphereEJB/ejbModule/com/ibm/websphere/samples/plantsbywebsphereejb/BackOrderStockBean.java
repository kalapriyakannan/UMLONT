//
// "This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
// instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
// or for redistribution by customer, as part of such an application, in customer's own products. " 
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2003,2003
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

import javax.ejb.EJBException;
import javax.ejb.FinderException;

/**
 * Bean implementation class for Enterprise Bean: BackOrderStock
 */
public class BackOrderStockBean implements javax.ejb.SessionBean, java.io.Serializable
{
   private javax.ejb.SessionContext mySessionCtx;
   private BackOrderLocalHome backOrderLocalHome = null;
   /**
    * Method getBackOrderLocalHome.
    * @return BackOrderLocalHome
    */
   public BackOrderLocalHome getBackOrderLocalHome()
   {
      try
      {
         if (backOrderLocalHome == null)
         {
            backOrderLocalHome = (BackOrderLocalHome) Util.getEJBLocalHome("java:comp/env/ejb/BackOrder", com.ibm.websphere.samples.plantsbywebsphereejb.BackOrderLocalHome.class);
         }
      }
      catch (Exception e)
      {
         Util.debug("BackOrderStockBean.getBackOrderLocalHome() - Exception: " + e);
      }
      return backOrderLocalHome;
   }
   /**
    * Method receiveConfirmation.
    * @param backOrderID
    */
   public void receiveConfirmation(String backOrderID)
   {
      try
      {
         Util.debug("BackOrderStockBean.receiveConfirmation() - Finding Back Order for backOrderID=" + backOrderID);
         BackOrderLocal backOrder = getBackOrderLocalHome().findByPrimaryKey(new BackOrderKey(backOrderID));
         backOrder.setStatus(Util.STATUS_RECEIVEDSTOCK);
         Util.debug("BackOrderStockBean.receiveConfirmation() - Updating status(" + Util.STATUS_RECEIVEDSTOCK + ") of backOrderID(" + backOrderID + ")");
      }
      catch (Exception e)
      {
         Util.debug("BackOrderStockBean.receiveConfirmation() -  Exception: " + e);
      }
   }
   /**
    * Method orderStock.
    * @param backOrderID
    * @param quantity
    */
   public void orderStock(String backOrderID, int quantity)
   {
      this.setBackOrderStatus(backOrderID, Util.STATUS_ORDEREDSTOCK);
      this.setBackOrderQuantity(backOrderID, quantity);
      this.setBackOrderOrderDate(backOrderID);
   }
   /**
    * Method updateStock.
    * @param backOrderID
    * @param quantity
    */
   public void updateStock(String backOrderID, int quantity)
   {
      this.addStock(backOrderID, quantity);
      this.setBackOrderStatus(backOrderID, Util.STATUS_ADDEDSTOCK);
   }
   /**
    * Method getBackOrderID.
    * @param backOrderID
    * @return String
    */
   public String getBackOrderID(String backOrderID)
   {
      String retbackOrderID = "";
      try
      {
         Util.debug("BackOrderStockBean.getBackOrderID() - Entered");
         BackOrderLocal backOrder = getBackOrderLocalHome().findByPrimaryKey(new BackOrderKey(backOrderID));
         retbackOrderID = backOrder.getBackOrderID();
      }
      catch (Exception e)
      {
         Util.debug("BackOrderStockBean.getBackOrderID() - Exception: " + e);
      }
      return retbackOrderID;

   }
   /**
    * Method getBackOrderInventoryID.
    * @param backOrderID
    * @return String
    */
   public String getBackOrderInventoryID(String backOrderID)
   {
      String retinventoryID = "";
      try
      {
         Util.debug("BackOrderStockBean.getBackOrderID() - Entered");
         BackOrderLocal backOrder = getBackOrderLocalHome().findByPrimaryKey(new BackOrderKey(backOrderID));
         retinventoryID = backOrder.getInventoryID();
      }
      catch (Exception e)
      {
         Util.debug("BackOrderStockBean.getBackOrderID() - Exception: " + e);
      }
      return retinventoryID;

   }
   /**
    * Method getBackOrderName.
    * @param backOrderID
    * @return String
    */
   public String getBackOrderName(String backOrderID)
   {
      String backOrderName = "";
      try
      {
         Util.debug("BackOrderStockBean.getBackOrderName() - Entered");
         BackOrderLocal backOrder = getBackOrderLocalHome().findByPrimaryKey(new BackOrderKey(backOrderID));
         backOrderName = backOrder.getName();
      }
      catch (Exception e)
      {
         Util.debug("BackOrderStockBean.getBackOrderName() - Exception: " + e);
      }
      return backOrderName;

   }
   /**
    * Method getBackOrderQuantity.
    * @param backOrderID
    * @return int
    */
   public int getBackOrderQuantity(String backOrderID)
   {
      int backOrderQuantity = -1;
      try
      {
         Util.debug("BackOrderStockBean.getBackOrderQuantity() - Entered");
         BackOrderLocal backOrder = getBackOrderLocalHome().findByPrimaryKey(new BackOrderKey(backOrderID));
         backOrderQuantity = backOrder.getQuantity();
      }
      catch (Exception e)
      {
         Util.debug("BackOrderStockBean.getBackOrderQuantity() - Exception: " + e);
      }
      return backOrderQuantity;
   }
   /**
    * Method getBackOrderStatus.
    * @param backOrderID
    * @return String
    */
   public String getBackOrderStatus(String backOrderID)
   {
      String backOrderStatus = "";
      try
      {
         Util.debug("BackOrderStockBean.getBackOrderStatus() - Entered");
         BackOrderLocal backOrder = getBackOrderLocalHome().findByPrimaryKey(new BackOrderKey(backOrderID));
         backOrderStatus = backOrder.getStatus();
      }
      catch (Exception e)
      {
         Util.debug("BackOrderStockBean.getBackOrderQuantity() - Exception: " + e);
      }
      return backOrderStatus;
   }
   /**
    * Method setBackOrderQuantity.
    * @param backOrderID
    * @param quantity
    */
   public void setBackOrderQuantity(String backOrderID, int quantity)
   {
      try
      {
         Util.debug("BackOrderStockBean.setBackOrderQuantity() - Entered");
         BackOrderLocal backOrder = getBackOrderLocalHome().findByPrimaryKey(new BackOrderKey(backOrderID));
         backOrder.setQuantity(quantity);
      }
      catch (Exception e)
      {
         Util.debug("BackOrderStockBean.setBackOrderQuantity() - Exception: " + e);
      }
   }
   /**
    * Method setBackOrderStatus.
    * @param backOrderID
    * @param Status
    */
   public void setBackOrderStatus(String backOrderID, String Status)
   {
      try
      {
         Util.debug("BackOrderStockBean.setBackOrderStatus() - Entered");
         BackOrderLocal backOrder = getBackOrderLocalHome().findByPrimaryKey(new BackOrderKey(backOrderID));
         backOrder.setStatus(Status);
      }
      catch (Exception e)
      {
         Util.debug("BackOrderStockBean.setBackOrderStatus() - Exception: " + e);
      }
   }

   /**
    * Method setBackOrderOrderDate.
    * @param backOrderID
    */
   public void setBackOrderOrderDate(String backOrderID)
   {
      try
      {
         Util.debug("BackOrderStockBean.setBackOrderQuantity() - Entered");
         BackOrderLocal backOrder = getBackOrderLocalHome().findByPrimaryKey(new BackOrderKey(backOrderID));
         backOrder.setOrderDate(System.currentTimeMillis());
      }
      catch (Exception e)
      {
         Util.debug("BackOrderStockBean.setBackOrderQuantity() - Exception: " + e);
      }
   }
   /**
    * Method deleteBackOrder.
    * @param backOrderID
    */
   public void deleteBackOrder(String backOrderID)
   {
      try
      {
         Util.debug("BackOrderStockBean.deleteBackOrder() - Entered");
         BackOrderLocal backOrder = getBackOrderLocalHome().findByPrimaryKey(new BackOrderKey(backOrderID));
         backOrder.remove();
      }
      catch (Exception e)
      {
         Util.debug("BackOrderStockBean.deleteBackOrder() - Exception: " + e);
      }
   }

   /**
    * Method findByID.
    * @param backOrderID
    * @return BackOrderItem
    */
   public BackOrderItem findByID(String backOrderID)
   {
      BackOrderItem backOrderItem = null;
      try
      {
         Util.debug("BackOrderStockBean.findByID() - Entered");
         BackOrderLocal backOrder = getBackOrderLocalHome().findByPrimaryKey(new BackOrderKey(backOrderID));
         backOrderItem = new BackOrderItem(backOrder);
      }
      catch (Exception e)
      {
         Util.debug("BackOrderStockBean.findByID() - Exception: " + e);
      }
      return backOrderItem;
   }
   /**
    * Method findBackOrderItems.
    * @return Vector
    */
   public Vector findBackOrderItems()
   {
      Vector backOrders = new Vector();
      try
      {
         Util.debug("BackOrderStockBean.findBackOrderItems() - Entered");
         Collection backOrderItems = getBackOrderLocalHome().findAll();
         Iterator i = backOrderItems.iterator();
         while (i.hasNext())
         {
            BackOrderLocal backOrder = (BackOrderLocal) i.next();
            backOrders.add(new BackOrderItem(backOrder));
         }
      }
      catch (Exception e)
      {
         Util.debug("BackOrderStockBean.findBackOrderItems() - Exception: " + e);
      }
      return backOrders;
   }

   /**
    * Method addStock.
    * @param backOrderID
    * @param quantity
    */
   public void addStock(String backOrderID, int quantity)
   {
      try
      {
         Util.debug("BackOrderStockBean.addStock() - Entered");
         BackOrderLocal backOrder = getBackOrderLocalHome().findByPrimaryKey(new BackOrderKey(backOrderID));
         Inventory inv = backOrder.getInventoryitem();
         inv.increaseInventory(quantity);
      }
      catch (Exception e)
      {
         Util.debug("BackOrderStockBean.addStock() - Exception: " + e);
      }
   }
   /**
    * Method createBackOrder.
    * @param inventoryID
    * @param amountToOrder
    * @param maximumItems
    */
   public void createBackOrder(String inventoryID, int amountToOrder, int maximumItems)
   {
      try
      {
         Util.debug("BackOrderStockBean.createBackOrder() - Entered");
         BackOrderLocal backOrder = null;
         try
         {
            // See if there is already an existing backorder and increase the order quantity
	    // but only if it has not been sent to the supplier.
            backOrder = getBackOrderLocalHome().findByInventoryID(inventoryID);
            if ( !(backOrder.getStatus().equals(Util.STATUS_ORDERSTOCK)) )
            {
               Util.debug("BackOrderStockBean.createBackOrder() - Backorders found but have already been ordered from the supplier");
               throw new FinderException();
            }
            // Increase the BackOrder quantity for an existing Back Order.
            backOrder.setQuantity(backOrder.getQuantity() + amountToOrder);
         }
         catch (FinderException e)
         {
            Util.debug("BackOrderStockBean.createBackOrder() - BackOrder EJB doesn't exist." + e);
            Util.debug("BackOrderStockBean.createBackOrder() - Creating BackOrder EJB for InventoryID: " + inventoryID);
            // Order enough stock from the supplier to reach the maximum threshold and to
            // satisfy the back order.
            amountToOrder = maximumItems + amountToOrder;
            backOrder = getBackOrderLocalHome().create(inventoryID, amountToOrder);
         }
      }
      catch (Exception e)
      {
         Util.debug("BackOrderStockBean.createBackOrder() - Exception: " + e);
      }
   }
   /**
    * Method getSessionContext.
    * @return SessionContext
    */
   /**
    * getSessionContext
    */
   public javax.ejb.SessionContext getSessionContext()
   {
      return mySessionCtx;
   }
   /**
    * @see javax.ejb.SessionBean#setSessionContext(SessionContext)
    */
   /**
    * setSessionContext
    */
   public void setSessionContext(javax.ejb.SessionContext ctx)
   {
      mySessionCtx = ctx;
   }
   /**
    * ejbCreate
    */
   public void ejbCreate() throws javax.ejb.CreateException
   {
   }
   /**
    * @see javax.ejb.SessionBean#ejbActivate()
    */
   /**
    * ejbActivate
    */
   public void ejbActivate()
   {
   }
   /**
    * @see javax.ejb.SessionBean#ejbPassivate()
    */
   /**
    * ejbPassivate
    */
   public void ejbPassivate()
   {
   }
   /**
    * @see javax.ejb.SessionBean#ejbRemove()
    */
   /**
    * ejbRemove
    */
   public void ejbRemove()
   {
   }
}

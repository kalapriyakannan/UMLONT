//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;
import java.sql.*;
import javax.ejb.*;
import javax.naming.*;

/**
 * LoginBean is the implementation class for the {@link Login} stateless session
 * EJB.  LoginBean implements each of the business methods in the <code>Login</code>
 * EJB remote interface and each of the EJB lifecycle methods in the javax.ejb.SessionBean
 * interface.
 * 
 * @see Login
 * @see LoginHome
 */

public class LoginBean implements SessionBean
{
    /**
	 * Verify that the user exists and the password is value.
	 * 
	 * @param customerID The customer ID
	 * @param password The password for the customer ID
	 * @return String with a results message.
	 */
	public String verifyUserAndPassword(String customerID, String password)
    {
        // Try to get customer.
        String results = null;
        Customer customer = null;
        
        try
        {
           CustomerHome customerHome = (CustomerHome) 
              Util.getEJBLocalHome("java:comp/env/ejb/Customer",
                 com.ibm.websphere.samples.plantsbywebsphereejb.CustomerHome.class);

           try
           {
              customer = customerHome.findByPrimaryKey(new CustomerKey(customerID));
           }
           catch (ObjectNotFoundException e) { }
        }
        catch (FinderException e) { e.printStackTrace(); }

        // Does customer exists?
        if (customer != null)
        {
           if ( ! customer.verifyPassword(password) )    // Is password correct?
           {
              results = "\nPassword does not match for : " + customerID; 
              Util.debug("Password given does not match for userid=" + customerID);
           }
        }
        else     // Customer was not found.
        {
           results = "\nCould not find account for : " + customerID; 
           Util.debug("customer " + customerID + " NOT found");
        }

    	return results;
    }

   /**
    * Create a new user.
    *
    * @param customerID The new customer ID.
    * @param password The password for the customer ID.
    * @param firstName First name.
    * @param lastName Last name.
    * @param addr1 Address line 1.
    * @param addr2 Address line 2.
    * @param addrCity City address information.
    * @param addrState State address information.
    * @param addrZip Zip code address information.
    * @param phone User's phone number.
    * @return CustomerInfo
    */
   public CustomerInfo createNewUser(String customerID, String password, String firstName,
                                     String lastName, String addr1, String addr2,
                                     String addrCity, String addrState, String addrZip,
                                     String phone)
   {
      CustomerInfo customerInfo = null;
      CustomerHome customerHome = null;

      try
      {
         customerHome = (CustomerHome) Util.getEJBLocalHome("java:comp/env/ejb/Customer",
               com.ibm.websphere.samples.plantsbywebsphereejb.CustomerHome.class);

         try
         {
            // Only create new user if it doesn't already exist.
            customerHome.findByPrimaryKey(new CustomerKey(customerID));
         }
         catch (ObjectNotFoundException onfe)
         {
            // Create customer and return true if all goes well.
            Customer customer = 
                  customerHome.create(new CustomerKey(customerID), password, firstName, 
                                      lastName, addr1, addr2, addrCity, addrState,
                                      addrZip, phone);

            if (customer != null)
               customerInfo = new CustomerInfo(customer);
         }
      }
      catch (FinderException e) { e.printStackTrace(); }
      catch (CreateException e) { e.printStackTrace(); }

      return customerInfo;
   }

   /**
    * Update an existing user.
    *
    * @param customerID The customer ID.
    * @param firstName First name.
    * @param lastName Last name.
    * @param addr1 Address line 1.
    * @param addr2 Address line 2.
    * @param addrCity City address information.
    * @param addrState State address information.
    * @param addrZip Zip code address information.
    * @param phone User's phone number.
    * @return CustomerInfo
    */
    public CustomerInfo updateUser(String customerID, String firstName, String lastName, 
                                   String addr1, String addr2, String addrCity, 
                                   String addrState, String addrZip,String phone)
    {
       CustomerInfo customerInfo = null;
       CustomerHome customerHome = null;

       try
       {
          customerHome = (CustomerHome) Util.getEJBLocalHome("java:comp/env/ejb/Customer",
                com.ibm.websphere.samples.plantsbywebsphereejb.CustomerHome.class);

          Customer customer = customerHome.findByPrimaryKey(new CustomerKey(customerID));
          customer.update(firstName, lastName, addr1, addr2, addrCity, addrState, addrZip, phone);
          customerInfo = new CustomerInfo(customer);
       }
       catch (FinderException e) { e.printStackTrace(); }

       return customerInfo;
    }
    
   /**
    * Retrieve an existing user.
    * 
    * @param customerID The customer ID.
    * @return CustomerInfo
    */    
   public CustomerInfo getCustomerInfo(String customerID)
   {
       CustomerInfo customerInfo = null;
       CustomerHome customerHome = null;

       try
       {
          customerHome = (CustomerHome) Util.getEJBLocalHome("java:comp/env/ejb/Customer",
                com.ibm.websphere.samples.plantsbywebsphereejb.CustomerHome.class);

          Customer customer = customerHome.findByPrimaryKey(new CustomerKey(customerID));
          customerInfo = new CustomerInfo(customer);
       }
       catch (FinderException e) { e.printStackTrace(); }

       return customerInfo;

   }

   /**
    * ejbCreate Session EJB lifecycle callback method. This method is empty for Stateless EJB.
    * This method corresponds to the create method in the home interface.
    */
   public void ejbCreate() throws CreateException { }

   /**
    * ejbRemove Session EJB lifecycle callback method. This method is empty for Stateless EJB.
    * Called just before the end of life for this object.
    */
   public void ejbRemove() { }

   /**
    * ejbActivate Session EJB lifecycle callback method. This method is empty for Stateless EJB.
    */
   public void ejbActivate() { }

   /**
    * ejbPassivate Session EJB lifecycle callback method. This method is empty for Stateless EJB.
    * Called when the instance is passivated from its "active" state, and releases.
    */
   public void ejbPassivate() { }

   /**
    * setSessionContext Session EJB lifecycle callback method to set the EJB sessionContext for this EJB.
    *
    * @param ctx javax.ejb.SessionContext The context for this session EJB.
    * @exception java.rmi.RemoteException If there is a remote communication failure.
    */
   public void setSessionContext (SessionContext ctx) throws RemoteException { }

}


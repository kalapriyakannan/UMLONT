//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

/**
 * The key class of the Customer entity bean.
 **/

import java.io.*;

public class CustomerKey implements Serializable 
{
   public String customerID;

   /**
    * Constructs an CustomerKey object.
    */
   public CustomerKey() 
   { 
      super();
   }

   /**
    * Constructs a newly allocated CustomerKey object that represents the primitive long argument.
    */
   public CustomerKey(String customerID) 
   { 
      this.customerID = customerID; 
   }

   /**
    * Determines if the CustomerKey object passed to the method matches this CustomerKey object.
    * @param o java.lang.Object The CustomerKey object to compare to this CustomerKey object.
    * @return boolean The pass object is either equal to this CustomerKey object (true) or not.
    */
   public boolean equals(Object o) 
   {
      if (o instanceof CustomerKey) 
      {
         CustomerKey otherKey = (CustomerKey) o;
         return (customerID.equals(otherKey.customerID));
      } 
      else 
         return false;
   }

   /**
    * Generates a hash code for this CustomerKey object.
    * @return int The hash code.
    */
   public int hashCode() 
   {
      return (customerID.hashCode());
   }
}

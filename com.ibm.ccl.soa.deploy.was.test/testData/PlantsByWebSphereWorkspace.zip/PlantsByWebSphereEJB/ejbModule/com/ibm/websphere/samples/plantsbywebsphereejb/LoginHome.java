//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;
import javax.ejb.CreateException;

/**
 * Home interface for Login stateless session bean.
 */
public interface LoginHome extends javax.ejb.EJBHome
{
    /**
     * @return Login The Login EJB object.
     * @exception javax.ejb.CreateException Login EJB object was not created.
     */
    public Login create() throws CreateException, RemoteException;
}


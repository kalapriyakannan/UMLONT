//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.text.NumberFormat;
import java.util.Hashtable;
import java.util.Properties;

import javax.ejb.*;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;

/**
 *  Utility class.
 */
public class Util
{
   /** Datasource name. */
   public static final String DS_NAME = "java:comp/env/plantsby/PlantsByWebSphereDataSource";

   // Constants for JSPs and HTMLs.
   public static final String PAGE_ACCOUNT = "account.jsp";
   public static final String PAGE_CART = "cart.jsp";
   public static final String PAGE_CHECKOUTFINAL = "checkout_final.jsp";
   public static final String PAGE_HELP = "help.jsp";
   public static final String PAGE_LOGIN = "login.jsp";
   public static final String PAGE_ORDERDONE = "orderdone.jsp";
   public static final String PAGE_ORDERINFO = "orderinfo.jsp";
   public static final String PAGE_PRODUCT = "product.jsp";
   public static final String PAGE_PROMO = "promo.html";
   public static final String PAGE_REGISTER = "register.jsp";
   public static final String PAGE_SHOPPING = "shopping.jsp";
   public static final String PAGE_BACKADMIN = "backorderadmin.jsp";
   public static final String PAGE_ADMINHOME = "admin.html";

   // Request and session attributes.
   public static final String ATTR_ACTION = "action";
   public static final String ATTR_CART = "ShoppingCart";
   public static final String ATTR_CART_CONTENTS = "CartContents";
   public static final String ATTR_CARTITEMS = "cartitems";
   public static final String ATTR_CATEGORY = "Category";
   public static final String ATTR_CHECKOUT = "CheckingOut";
   public static final String ATTR_CUSTOMER = "CustomerInfo";
   public static final String ATTR_EDITACCOUNTINFO = "EditAccountInfo";
   public static final String ATTR_INVITEM = "invitem";
   public static final String ATTR_INVITEMS = "invitems";
   public static final String ATTR_ORDERID = "OrderID";
   public static final String ATTR_ORDERINFO = "OrderInfo";
   public static final String ATTR_ORDERKEY = "OrderKey";
   public static final String ATTR_RESULTS = "results";
   public static final String ATTR_UPDATING = "updating";

   // Admin type actions
   public static final String ATTR_ADMINTYPE = "admintype";
   public static final String ADMIN_BACKORDER = "backorder";
   public static final String STATUS_ORDERSTOCK = "Order Stock";
   public static final String STATUS_ORDEREDSTOCK = "Ordered Stock";
   public static final String STATUS_RECEIVEDSTOCK = "Received Stock";
   public static final String STATUS_ADDEDSTOCK = "Added Stock";

   private static InitialContext initCtx = null;
   private static Hashtable homeTable = new Hashtable();
   private static Hashtable localhomeTable = new Hashtable();

   private static final String[] CATEGORY_STRINGS = { "Flowers", "Fruits & Vegetables", "Trees", "Accessories" };

   private static final String[] SHIPPING_METHOD_STRINGS = { "Standard Ground", "Second Day Air", "Next Day Air" };

   private static final String[] SHIPPING_METHOD_TIMES = { "( 3 to 6 business days )", "( 2 to 3 business days )", "( 1 to 2 business days )" };

   private static final float[] SHIPPING_METHOD_PRICES = { 4.99f, 8.99f, 12.99f };

   public static final String ZERO_14 = "00000000000000";

   /**
    * Return the cached Initial Context.
    *
    * @return InitialContext, or null if a naming exception.
    */
   static public InitialContext getInitialContext()
   {
      try
      {
         // Get InitialContext if it has not been gotten yet.
         if (initCtx == null)
         {
            // properties are in the system properties
            initCtx = new InitialContext();
         }
      }
      // Naming Exception will cause a null return.
      catch (NamingException e)
      {
      }

      return initCtx;
   }

   /**
    * Lookup and return an EJB home.
    *
    * @param jndiName jndi name of the EJB
    * @param homeClass EJB's home class
    * @return EJBHome EJB home instance, or null if a naming exception on lookup.
    */
   static public EJBHome getEJBHome(String jndiName, Class homeClass)
   {
      EJBHome home = (EJBHome) homeTable.get(jndiName);
      if (home == null)
      {
         try
         {
            InitialContext ic = getInitialContext();
            if (ic != null)
            {
               Object obj = ic.lookup(jndiName);
               if (obj != null)
               {
                  home = (EJBHome) PortableRemoteObject.narrow(obj, homeClass);
                  if (home != null)
                  {
                     homeTable.put(jndiName, home);
                  }
               }
            }
         }
         // Naming Exception will cause a null return.
         catch (NamingException e)
         {
         }
      }
      return home;
   }
   static public EJBLocalHome getEJBLocalHome(String jndiName, Class homeClass)
   {
      EJBLocalHome home = (EJBLocalHome) localhomeTable.get(jndiName);
      if (home == null)
      {
         try
         {
            InitialContext ic = getInitialContext();
            if (ic != null)
            {
               home = (EJBLocalHome) ic.lookup(jndiName);
               if (home != null)
               {
                  localhomeTable.put(jndiName, home);
               }
            }
         }
         // Naming Exception will cause a null return.
         catch (NamingException e)
         {
            debug("Util.getEJBLocalHome(): Exception: " + e);
         }
      }
      return home;
   }

   /**
    * Get the displayable name of a category.
    * @param index The int representation of a category.
    * @return The category as a String (null, if an invalid index given).
    */
   static public String getCategoryString(int index)
   {
      if ((index >= 0) && (index < CATEGORY_STRINGS.length))
         return CATEGORY_STRINGS[index];
      else
         return null;
   }

   /**
    * Get the category strings in an array.
    *
    * @return The category strings in an array.
    */
   static public String[] getCategoryStrings()
   {
      return CATEGORY_STRINGS;
   }

   /**
    * Get the shipping method.
    * @param index The int representation of a shipping method.
    * @return The shipping method (null, if an invalid index given).
    */
   static public String getShippingMethod(int index)
   {
      if ((index >= 0) && (index < SHIPPING_METHOD_STRINGS.length))
         return SHIPPING_METHOD_STRINGS[index];
      else
         return null;
   }

   /**
    * Get the shipping method price.
    * @param index The int representation of a shipping method.
    * @return The shipping method price (-1, if an invalid index given).
    */
   static public float getShippingMethodPrice(int index)
   {
      if ((index >= 0) && (index < SHIPPING_METHOD_PRICES.length))
         return SHIPPING_METHOD_PRICES[index];
      else
         return -1;
   }

   /**
    * Get the shipping method price.
    * @param index The int representation of a shipping method.
    * @return The shipping method time (null, if an invalid index given).
    */
   static public String getShippingMethodTime(int index)
   {
      if ((index >= 0) && (index < SHIPPING_METHOD_TIMES.length))
         return SHIPPING_METHOD_TIMES[index];
      else
         return null;
   }

   /**
    * Get the shipping method strings in an array.
    * @return The shipping method strings in an array.
    */
   static public String[] getShippingMethodStrings()
   {
      return SHIPPING_METHOD_STRINGS;
   }

   /**
    * Get the shipping method strings, including prices and times, in an array.
    * @return The shipping method strings, including prices and times, in an array.
    */
   static public String[] getFullShippingMethodStrings()
   {
      String[] shippingMethods = new String[SHIPPING_METHOD_STRINGS.length];
      for (int i = 0; i < shippingMethods.length; i++)
      {
         shippingMethods[i] = SHIPPING_METHOD_STRINGS[i] + " " + SHIPPING_METHOD_TIMES[i] + " " + NumberFormat.getCurrencyInstance(java.util.Locale.US).format(new Float(SHIPPING_METHOD_PRICES[i]));
      }
      return shippingMethods;
   }

   static final public String PBW_Properties_File = "pbw.properties";
   static public Properties PBW_Properties = null;

   /**
    * Method readProperties.
    */
   public static void readProperties()
   {
      if (PBW_Properties == null)
      {
         Properties prop = new Properties();
         try
         {
            prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream(PBW_Properties_File));
         }
         catch (Exception e)
         {
            debug("Util.readProperties(): Exception: " + e);
            e.printStackTrace(System.err);
         }
         PBW_Properties = prop;
      }
   }

   /**
    * Method getProperty.
    * @param name
    * @return String
    */
   public static String getProperty(String name)
   {
      if (PBW_Properties == null)
      {
         readProperties();
      }
      String value = PBW_Properties.getProperty(name);
      if (value == null)
      {
         value = "";
      }
      return (value);
   }

   static private boolean debug = false;

   /** Set debug setting to on or off.
    * @param val True or false.
    */
   static final public void setDebug(boolean val)
   {
      debug = val;
   }

   /** Is debug turned on? */
   static final public boolean debugOn()
   {
      return debug;
   }

   /** 
    * Output RAS message.
    * @param msg Message to be output.
    */
   static final public void debug(String msg)
   {
      if (debug)
      {
         System.out.println(msg);
      }
   }
}

//
// "This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
// instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
// or for redistribution by customer, as part of such an application, in customer's own products. " 
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2003,2003
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;
/**
 * Key class for Entity Bean: BackOrder
 */
public class BackOrderKey implements java.io.Serializable
{
   static final long serialVersionUID = 3206093459760846163L;
   /**
    * Implementation field for persistent attribute: backOrderID
    */
   public java.lang.String backOrderID;
   /**
    * @see java.lang.Object#Object()
    */
   /**
    * Creates an empty key for Entity Bean: BackOrder
    */
   public BackOrderKey()
   {
   }
   /**
    * @see java.lang.Object#equals(Object)
    */
   /**
    * Returns true if both keys are equal.
    */
   public boolean equals(java.lang.Object otherKey)
   {
      if (otherKey instanceof com.ibm.websphere.samples.plantsbywebsphereejb.BackOrderKey)
      {
         com.ibm.websphere.samples.plantsbywebsphereejb.BackOrderKey o = (com.ibm.websphere.samples.plantsbywebsphereejb.BackOrderKey) otherKey;
         return ((this.backOrderID.equals(o.backOrderID)));
      }
      return false;
   }
   /**
    * @see java.lang.Object#hashCode()
    */
   /**
    * Returns the hash code for the key.
    */
   public int hashCode()
   {
      return (backOrderID.hashCode());
   }
   /**
    * Method BackOrderKey.
    * @param backOrderID
    */
   /**
    * Creates a key for Entity Bean: BackOrder
    */
   public BackOrderKey(java.lang.String backOrderID)
   {
      this.backOrderID = backOrderID;
   }
   /**
    * Method getBackOrderID.
    * @return String
    */
   /**
    * Get accessor for persistent attribute: backOrderID
    */
   public java.lang.String getBackOrderID()
   {
      return backOrderID;
   }
   /**
    * Method setBackOrderID.
    * @param newBackOrderID
    */
   /**
    * Set accessor for persistent attribute: backOrderID
    */
   public void setBackOrderID(java.lang.String newBackOrderID)
   {
      backOrderID = newBackOrderID;
   }
}

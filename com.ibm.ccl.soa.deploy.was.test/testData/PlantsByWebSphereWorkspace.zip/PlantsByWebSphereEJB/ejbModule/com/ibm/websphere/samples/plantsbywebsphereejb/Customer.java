//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

/**
 * Local interface for Customer entity bean.
 */
public interface Customer extends javax.ejb.EJBLocalObject
{
   /** Verify that the passed in matches the stored password.
    * @param password Password entered.
    * @return True, if the password matches. */
   public boolean verifyPassword(String password);

   /** Update the customer information. */
   public void update(String firstName, String lastName, String addr1, 
                      String addr2, String addrCity, String addrState,
                      String addrZip, String phone);

   /** Get the customer's id.
    * @return String of customer's id. */
   public String getCustomerID();
   /** Get the customer's password.
    * @return String of customer's password. */
   public String getPassword();
   /** Get the customer's first name.
    * @return String of customer's first name. */
   public String getFirstName();
   /** Get the customer's last name.
    * @return String of customer's last name. */
   public String getLastName();
   /** Get the customer's full name.
    * @return String of customer's full name. */
   public String getFullName();
   /** Get the customer's address line 1.
    * @return String of customer's address line 1. */
   public String getAddr1();
   /** Get the customer's address line 2.
    * @return String of customer's address line 2. */
   public String getAddr2();
   /** Get the customer's city.
    * @return String of customer's city. */
   public String getAddrCity();
   /** Get the customer's state.
    * @return String of customer's state. */
   public String getAddrState();
   /** Get the customer's zip code.
    * @return String of customer's zip code. */
   public String getAddrZip();
   /** Get the customer's phone.
    * @return String of customer's phone. */
   public String getPhone();
}


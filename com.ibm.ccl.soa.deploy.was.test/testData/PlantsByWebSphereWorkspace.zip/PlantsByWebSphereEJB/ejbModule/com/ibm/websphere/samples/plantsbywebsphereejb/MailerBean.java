//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.util.Date;
import javax.ejb.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.naming.NamingException;

/**
 * MailerBean is the implementation class for the {@link Mailer} stateless session EJB.
 * MailerBean implements each of the business methods in the <code>Mailer</code>
 * EJB remote interface and each of the EJB lifecycle methods in the javax.ejb.SessionBean
 * interface.
 * 
 * @see Mailer
 * @see MailerHome
 */
public class MailerBean implements SessionBean
{
   public static final String MAIL_SESSION = "java:comp/env/mail/PlantsByWebSphere";

   /** 
    * Create a mail message and send it.
    *
    * @param eMessage The e-mail message to send. 
    */
   public void createAndSendMail(EMailMessage eMessage) throws MailerAppException 
   {
       try 
       {
           Util.debug("Sending message" +
                      "\nTo: " + eMessage.getEmailReceiver() +
                      "\nSubject: " + eMessage.getSubject() +
                      "\nContents: " + eMessage.getHtmlContents());

           Session session = (Session) Util.getInitialContext().lookup(MAIL_SESSION);

           MimeMessage msg = new MimeMessage(session);
           msg.setFrom();

           msg.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(eMessage.getEmailReceiver(), false));

           msg.setSubject(eMessage.getSubject());
           String contentType = "text/plain";
           MimeBodyPart mbp = new MimeBodyPart();
           mbp.setText(eMessage.getHtmlContents(), "us-ascii");
           msg.setHeader("X-Mailer", "JavaMailer");
           Multipart mp = new MimeMultipart();
           mp.addBodyPart(mbp);
           msg.setContent(mp);
           msg.setSentDate(new Date());

           Transport.send(msg);

           Util.debug("\nMail sent successfully.");
       }   
       catch (javax.naming.NamingException e)
       {
          Util.debug("javax.naming.NamingException, Has mail session been created?");
       }
       catch (Exception e) 
       {
           Util.debug("createAndSendMail exception : " + e);
           throw new MailerAppException("Failure while sending mail");
       }
   }

   public void ejbCreate() {}

   public void setSessionContext(SessionContext sc) {}

   public void ejbRemove() {}

   public void ejbActivate() {}

   public void ejbPassivate() {}
}

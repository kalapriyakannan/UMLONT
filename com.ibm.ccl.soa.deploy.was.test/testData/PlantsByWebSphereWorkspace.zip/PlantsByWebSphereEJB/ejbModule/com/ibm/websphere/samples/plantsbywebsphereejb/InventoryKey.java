//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

/**
 * The key class of the Inventory entity bean.
 **/

import java.io.*;

public class InventoryKey implements Serializable 
{
   public String inventoryID;

   /**
    * Constructs an InventoryKey object.
    */
   public InventoryKey() 
   { 
      super();
   }

   /**
    * Constructs a newly allocated InventoryKey object that represents the primitive long argument.
    */
   public InventoryKey(String inventoryID) 
   { 
      this.inventoryID = inventoryID; 
   }

   /**
    * Determines if the InventoryKey object passed to the method matches this InventoryKey object.
    * @param o java.lang.Object The InventoryKey object to compare to this InventoryKey object.
    * @return boolean The pass object is either equal to this InventoryKey object (true) or not.
    */
   public boolean equals(Object o) 
   {
      if (o instanceof InventoryKey) 
      {
         InventoryKey otherKey = (InventoryKey) o;
         return (inventoryID.equals(otherKey.inventoryID));
      } 
      else 
         return false;
   }

   /**
    * Generates a hash code for this InventoryKey object.
    * @return int The hash code.
    */
   public int hashCode() 
   {
      return (inventoryID.hashCode());
   }
}

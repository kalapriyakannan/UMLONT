//
// "This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
// instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
// or for redistribution by customer, as part of such an application, in customer's own products. " 
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2003,2003
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Vector;

/**
 * Remote interface for Enterprise Bean: BackOrderStock
 */
public interface BackOrderStock extends javax.ejb.EJBObject
{
   /**
    * Method receiveConfirmation.
    * @param backOrderID
    * @throws RemoteException
    */
   public void receiveConfirmation(String backOrderID) throws RemoteException;
   /**
    * Method orderStock.
    * @param backOrderID
    * @param quantity
    * @throws RemoteException
    */
   public void orderStock(String backOrderID, int quantity) throws RemoteException;
   /**
    * Method updateStock.
    * @param backOrderID
    * @param quantity
    * @throws RemoteException
    */
   public void updateStock(String backOrderID, int quantity) throws RemoteException;
   /**
    * Method getBackOrderID.
    * @param backOrderID
    * @return String
    * @throws RemoteException
    */
   public String getBackOrderID(String backOrderID) throws RemoteException;
   /**
    * Method getBackOrderInventoryID.
    * @param backOrderID
    * @return String
    * @throws RemoteException
    */
   public String getBackOrderInventoryID(String backOrderID) throws RemoteException;
   /**
    * Method getBackOrderName.
    * @param backOrderID
    * @return String
    * @throws RemoteException
    */
   public String getBackOrderName(String backOrderID) throws RemoteException;
   /**
    * Method getBackOrderQuantity.
    * @param backOrderID
    * @return int
    * @throws RemoteException
    */
   public int getBackOrderQuantity(String backOrderID) throws RemoteException;
   /**
    * Method setBackOrderQuantity.
    * @param backOrderID
    * @param quantity
    * @throws RemoteException
    */
   public void setBackOrderQuantity(String backOrderID, int quantity) throws RemoteException;
   /**
    * Method getBackOrderStatus.
    * @param backOrderID
    * @return String
    * @throws RemoteException
    */
   public String getBackOrderStatus(String backOrderID) throws RemoteException;

   /**
    * Method setBackOrderStatus.
    * @param backOrderID
    * @param Status
    * @throws RemoteException
    */
   public void setBackOrderStatus(String backOrderID, String Status) throws RemoteException;
   /**
    * Method setBackOrderOrderDate.
    * @param backOrderID
    * @throws RemoteException
    */
   public void setBackOrderOrderDate(String backOrderID) throws RemoteException;
   /**
    * Method deleteBackOrder.
    * @param backOrderID
    * @throws RemoteException
    */
   public void deleteBackOrder(String backOrderID) throws RemoteException;
   /**
    * Method addStock.
    * @param backOrderID
    * @param quantity
    * @throws RemoteException
    */
   public void addStock(String backOrderID, int quantity) throws RemoteException;
   /**
    * Method createBackOrder.
    * @param inventoryID
    * @param amountToOrder
    * @param maximumItems
    * @throws RemoteException
    */
   public void createBackOrder(String inventoryID, int amountToOrder, int maximumItems) throws RemoteException;
   /**
    * Method findBackOrderItems.
    * @return Vector
    * @throws RemoteException
    */
   public Vector findBackOrderItems() throws RemoteException;
   /**
    * Method findByID.
    * @param backOrderID
    * @return BackOrderItem
    * @throws RemoteException
    */
   public BackOrderItem findByID(String backOrderID) throws RemoteException;
}

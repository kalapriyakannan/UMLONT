//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.util.*;
import javax.ejb.*;

/**
 * ShoppingCartBean is the implementation class for the {@link ShoppingCart} stateful session
 * EJB.  ShoppingCartBean implements each of the business methods in the <code>ShoppingCart</code>
 * EJB local interface and each of the EJB lifecycle methods in the javax.ejb.SessionBean
 * interface.
 * 
 * @see ShoppingCart
 * @see ShoppingCartHome
 */
public class ShoppingCartBean implements SessionBean
{
   private Vector items;

   /**
    * Create a shopping cart.
    */
   public void ejbCreate() throws CreateException
   {
      items = new Vector();
   }
   /**
    * Create a shopping cart.
    */
   public void ejbPostCreate() throws CreateException
   {
   }
   /**
    * Get the inventory item.
    *
    * @param id of inventory item.
    * @return an inventory bean.
    */
   private Inventory getInventoryItem(String inventoryID)
   {
      Inventory inv = null;
      // Get the Inventory home.
      InventoryHome inventoryHome = (InventoryHome) Util.getEJBLocalHome("java:comp/env/ejb/Inventory", InventoryHome.class);
      try
      {
         inv = inventoryHome.findByPrimaryKey(new InventoryKey(inventoryID));
      }
      catch (FinderException e)
      {
         Util.debug("ShoppingCartBean.getInventoryItem() - Exception: " + e);
      }
      return inv;
   }

   /**
    * Create a shopping cart.
    *
    * @param cartContents Contents to populate cart with.
    */
   public void ejbCreate(ShoppingCartContents cartContents) throws CreateException
   {
      items = new Vector();
      int qty;
      String inventoryID;
      StoreItem si;
      Inventory inv;
      for (int i = 0; i < cartContents.size(); i++)
      {
         inventoryID = cartContents.getInventoryID(i);
         qty = cartContents.getQuantity(inventoryID);

         // Get the Inventory home.
         InventoryHome inventoryHome = (InventoryHome) Util.getEJBLocalHome("java:comp/env/ejb/Inventory", com.ibm.websphere.samples.plantsbywebsphereejb.InventoryHome.class);
         try
         {
            inv = inventoryHome.findByPrimaryKey(new InventoryKey(inventoryID));
            si = new StoreItem(inv);
            si.setQuantity(qty);
            addItem(si);
         }
         catch (FinderException e)
         {
         }
      }
   }

   /**
    * ejbPostCreate
    */
   public void ejbPostCreate(ShoppingCartContents cartContents) throws javax.ejb.CreateException
   {
   }
   /** 
    * Add an item to the cart.
    *
    * @param new_item Item to add to the cart.
    */
   public void addItem(StoreItem new_item)
   {
      boolean added = false;
      StoreItem old_item;
      // If the same item is already in the cart, just increase the quantity.
      for (int i = 0; i < items.size(); i++)
      {
         old_item = (StoreItem) items.elementAt(i);
         if (new_item.equals(old_item))
         {
            old_item.setQuantity(old_item.getQuantity() + new_item.getQuantity());
            added = true;
            break;
         }
      }

      // Add this item to shopping cart, if it is a brand new item.
      if (!added)
         items.addElement(new_item);
   }

   /** 
    * Remove an item from the cart.
    *
    * @param item Item to remove from cart.
    */
   public void removeItem(StoreItem item)
   {
      Object obj;
      for (Enumeration enum = items.elements(); enum.hasMoreElements();)
      {
         obj = enum.nextElement();
         if (item.equals(obj))
         {
            items.remove(obj);
            break;
         }
      }
   }

   /** 
    * Get the items in the shopping cart.
    *
    * @return A Vector of StoreItem's.
    */
   public Vector getItems()
   {
      return items;
   }

   /** 
    * Set the items in the shopping cart.
    *
    * @param items A Vector of StoreItem's.
    */
   public void setItems(Vector items)
   {
      this.items = (Vector) items.clone();
   }

   /** 
    * Get the total cost of all items in the shopping cart.
    *
    * @return The total cost of all items in the shopping cart.
    */
   public float getTotalCost()
   {
      float total = 0.0f;
      StoreItem si;
      for (int i = 0; i < items.size(); i++)
      {
         si = (StoreItem) items.elementAt(i);
         total += si.getPrice() * si.getQuantity();
      }
      return total;
   }

   /** 
    * Method checkInventory.
    * Check the inventory level all items in the shopping cart.
    * Order additional inventory when necessary
    *
    * @param items
    */
   public void checkInventory(Vector items)
   {
      float total = 0.0f;
      StoreItem si;
      for (int i = 0; i < items.size(); i++)
      {
         si = (StoreItem) items.elementAt(i);
         Util.debug("ShoppingCart.checkInventory() - checking Inventory quanrity of item: " + si.getID());
         Inventory inv = getInventoryItem(si.getID());
         inv.decreaseInventory(si.getQuantity());
      }
   }

   /**
    * Get the contents of the shopping cart.
    *
    * @return The contents of the shopping cart.
    */
   public ShoppingCartContents getCartContents()
   {
      ShoppingCartContents cartContents = new ShoppingCartContents();

      // Fill it with data.
      for (int i = 0; i < items.size(); i++)
      {
         cartContents.addItem((StoreItem) items.elementAt(i));
      }

      return cartContents;
   }

   /**
    * Create an order with contents of a shopping cart.
    *
    * @param customerID customer's ID
    * @param billName billing name
    * @param billAddr1 billing address line 1
    * @param billAddr2 billing address line 2
    * @param billCity billing address city
    * @param billState billing address state
    * @param billZip billing address zip code
    * @param billPhone billing phone
    * @param shipName shippng name
    * @param shipAddr1 shippng address line 1
    * @param shipAddr2 shippng address line 2
    * @param shipCity shippng address city
    * @param shipState shippng address state
    * @param shipZip shippng address zip code
    * @param shipPhone shippng phone
    * @param creditCard credit card
    * @param ccNum credit card number
    * @param ccExpireMonth credit card expiration month
    * @param ccExpireYear credit card expiration year
    * @param cardHolder credit card holder name
    * @param shippingMethod int of shipping method used
    * @param items vector of StoreItems ordered
    * @return OrderInfo
    */
   public OrderInfo createOrder(
      String customerID,
      String billName,
      String billAddr1,
      String billAddr2,
      String billCity,
      String billState,
      String billZip,
      String billPhone,
      String shipName,
      String shipAddr1,
      String shipAddr2,
      String shipCity,
      String shipState,
      String shipZip,
      String shipPhone,
      String creditCard,
      String ccNum,
      String ccExpireMonth,
      String ccExpireYear,
      String cardHolder,
      int shippingMethod,
      Vector items)
   {
      Order order = null;

      try
      {
         OrderHome orderHome = (OrderHome) Util.getEJBLocalHome("java:comp/env/ejb/Order", com.ibm.websphere.samples.plantsbywebsphereejb.OrderHome.class);
         Util.debug("ShoppingCartBean.createOrder:  Creating Order");
         order =
            orderHome.create(
               customerID,
               billName,
               billAddr1,
               billAddr2,
               billCity,
               billState,
               billZip,
               billPhone,
               shipName,
               shipAddr1,
               shipAddr2,
               shipCity,
               shipState,
               shipZip,
               shipPhone,
               creditCard,
               ccNum,
               ccExpireMonth,
               ccExpireYear,
               cardHolder,
               shippingMethod,
               items);
      }
      catch (CreateException e)
      {
         Util.debug("ShoppingCartBean(createOrder): Exception - " + e);
         e.printStackTrace();
      }

      if (order != null)
      {
         return new OrderInfo(order);
      }
      else
         return null;
   }

   /**
    * ejbRemove Session EJB lifecycle callback method. This method is empty for Stateless EJB.
    * Called just before the end of life for this object.
    */
   public void ejbRemove()
   {
   }

   /**
    * ejbActivate Session EJB lifecycle callback method. This method is empty for Stateless EJB.
    */
   public void ejbActivate()
   {
   }

   /**
    * ejbPassivate Session EJB lifecycle callback method. This method is empty for Stateless EJB.
    * Called when the instance is passivated from its "active" state, and releases.
    */
   public void ejbPassivate()
   {
   }

   /**
    * setSessionContext Session EJB lifecycle callback method to set the EJB sessionContext for this EJB.
    *
    * @param ctx javax.ejb.SessionContext The context for this session EJB.
    */
   public void setSessionContext(SessionContext ctx)
   {
   }

}

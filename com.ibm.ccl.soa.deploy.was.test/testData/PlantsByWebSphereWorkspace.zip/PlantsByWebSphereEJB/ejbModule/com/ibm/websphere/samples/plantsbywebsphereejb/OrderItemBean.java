package com.ibm.websphere.samples.plantsbywebsphereejb;
/**
 * Bean implementation class for Enterprise Bean: OrderItem
 */
public abstract class OrderItemBean implements javax.ejb.EntityBean 
{
   
	private javax.ejb.EntityContext myEntityCtx;
	/**
	 * ejbCreate
	 */
	public OrderItemKey ejbCreate(
		java.lang.String inventoryID)
		throws javax.ejb.CreateException 
	{
		Util.debug("OrderItemBean.ejbCreate(invid)");
		setInventoryID(inventoryID);
		return null;
	}
   
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(String inventoryID)
		throws javax.ejb.CreateException 
	{	}
	
   /**
    * ejbCreate
    */
   public OrderItemKey ejbCreate(Order order, String orderID, 
                            java.lang.String inventoryID, java.lang.String name,
                            java.lang.String pkginfo, float price, float cost,
                            int quantity, int category, 
                            java.lang.String sellDate)
            throws javax.ejb.CreateException 
   {
   			Util.debug("OrderItemBean.ejbCreate(etc.)");
      setInventoryID(inventoryID);
      setName(name);
      setPkginfo(pkginfo);
      setPrice(price);
      setCost(cost);
      setQuantity(quantity);
      setCategory(category);
      setSellDate(sellDate);
      this.setOrder_orderID(orderID);
      return null;
   }

   /**
    * ejbPostCreate
    */
   public void ejbPostCreate(Order order, String orderID, String inventoryID, 
                              String name, String pkginfo, float price, float cost,
                              int quantity, int category, String sellDate)
          throws javax.ejb.CreateException 
   { 
      this.setOrder(order);
   }
   
	/**
	 * Get accessor for persistent attribute: inventoryID
	 */
	public abstract java.lang.String getInventoryID();
	/**
	 * Set accessor for persistent attribute: inventoryID
	 */
	public abstract void setInventoryID(java.lang.String newInventoryID);
	/**
	 * Get accessor for persistent attribute: name
	 */
	public abstract java.lang.String getName();
	/**
	 * Set accessor for persistent attribute: name
	 */
	public abstract void setName(java.lang.String newName);
	/**
	 * Get accessor for persistent attribute: pkginfo
	 */
	public abstract java.lang.String getPkginfo();
	/**
	 * Set accessor for persistent attribute: pkginfo
	 */
	public abstract void setPkginfo(java.lang.String newPkginfo);
	/**
	 * Get accessor for persistent attribute: price
	 */
	public abstract float getPrice();
	/**
	 * Set accessor for persistent attribute: price
	 */
	public abstract void setPrice(float newPrice);
	/**
	 * Get accessor for persistent attribute: cost
	 */
	public abstract float getCost();
	/**
	 * Set accessor for persistent attribute: cost
	 */
	public abstract void setCost(float newCost);
	/**
	 * Get accessor for persistent attribute: category
	 */
	public abstract int getCategory();
	/**
	 * Set accessor for persistent attribute: category
	 */
	public abstract void setCategory(int newCategory);
	/**
	 * Get accessor for persistent attribute: quantity
	 */
	public abstract int getQuantity();
	/**
	 * Set accessor for persistent attribute: quantity
	 */
	public abstract void setQuantity(int newQuantity);
	/**
	 * Get accessor for persistent attribute: sellDate
	 */
	public abstract java.lang.String getSellDate();
	/**
	 * Set accessor for persistent attribute: sellDate
	 */
	public abstract void setSellDate(java.lang.String newSellDate);
	/**
	 * setEntityContext
	 */
	public void setEntityContext(javax.ejb.EntityContext ctx) {
		myEntityCtx = ctx;
	}
	/**
	 * getEntityContext
	 */
	public javax.ejb.EntityContext getEntityContext() {
		return myEntityCtx;
	}
	/**
	 * unsetEntityContext
	 */
	public void unsetEntityContext() {
		myEntityCtx = null;
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
	}
	/**
	 * This method was generated for supporting the relationship role named order.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract com
		.ibm
		.websphere
		.samples
		.plantsbywebsphereejb
		.Order getOrder();
	/**
	 * This method was generated for supporting the relationship role named order.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract void setOrder(
		com.ibm.websphere.samples.plantsbywebsphereejb.Order anOrder);
	/**
	/**
	 * Get accessor for persistent attribute: order_orderID
	 */
	public abstract java.lang.String getOrder_orderID();
	/**
	 * Set accessor for persistent attribute: order_orderID
	 */
	public abstract void setOrder_orderID(java.lang.String newOrder_orderID);
} 
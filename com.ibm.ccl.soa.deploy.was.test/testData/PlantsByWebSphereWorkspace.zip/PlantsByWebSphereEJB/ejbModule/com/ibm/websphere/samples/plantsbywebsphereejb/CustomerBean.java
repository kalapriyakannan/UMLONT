//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import javax.ejb.*;

/**
 * CustomerBean is the implementation class for the {@link Customer} entity
 * EJB.  CustomerBean implements each of the business methods in the <code>Customer</code>
 * EJB local interface and each of the EJB lifecycle methods in the javax.ejb.EntityBean
 * interface.
 * 
 * @see Customer
 * @see CustomerHome
 */
public abstract class CustomerBean implements EntityBean
{
   /** 
    * Create a new Customer.
    *
    * @param key CustomerKey
    * @param password Password used for this customer account.
    * @param fullName Full name of the customer.
    * @return CustomerKey
    */
   public CustomerKey ejbCreate(CustomerKey key, String password, 
                                String firstName, String lastName,
                                String addr1, String addr2,
                                String addrCity, String addrState,
                                String addrZip, String phone) throws CreateException 
   { 
      this.setCustomerID(key.customerID);
      this.setPassword(password);
      this.setFirstName(firstName);
      this.setLastName(lastName);
      this.setAddr1(addr1);
      this.setAddr2(addr2);
      this.setAddrCity(addrCity);
      this.setAddrState(addrState);
      this.setAddrZip(addrZip);
      this.setPhone(phone);
      return null;
   }

   /**
    * Entity EJB lifecycle callback method. This method is empty for this CMP Customer EJB.
    *
    */
   public void ejbPostCreate(CustomerKey key, String password, 
                             String firstName, String lastName,
                             String addr1, String addr2,
                             String addrCity, String addrState,
                             String addrZip, String phone) { }

   /**
    * Verify password.
    *
    * @param Password value to be checked.
    * @return True, if password matches one stored.
    */
   public boolean verifyPassword(String password)
   {
      return this.getPassword().equals(password);
   }

   /** Update the customer information. */
   public void update(String firstName, String lastName,
                      String addr1, String addr2,
                      String addrCity, String addrState,
                      String addrZip, String phone)
   {
      this.setFirstName(firstName);
      this.setLastName(lastName);
      this.setAddr1(addr1);
      this.setAddr2(addr2);
      this.setAddrCity(addrCity);
      this.setAddrState(addrState);
      this.setAddrZip(addrZip);
      this.setPhone(phone);
   }

   /** Get the customer's full name.
    * @return String of customer's full name. */
   public String getFullName() 
   { 
      return this.getFirstName() + " " + this.getLastName(); 
   }

   /** Get the customer's id.
    * @return String of customer's id. */
   public abstract String getCustomerID();
   /** Get the customer's password.
    * @return String of customer's password. */
   public abstract String getPassword();
   /** Get the customer's first name.
    * @return String of customer's first name. */
   public abstract String getFirstName();
   /** Get the customer's last name.
    * @return String of customer's last name. */
   public abstract String getLastName();
   /** Get the customer's address line 1.
    * @return String of customer's address line 1. */
   public abstract String getAddr1();
   /** Get the customer's address line 2.
    * @return String of customer's address line 2. */
   public abstract String getAddr2();
   /** Get the customer's city.
    * @return String of customer's city. */
   public abstract String getAddrCity();
   /** Get the customer's state.
    * @return String of customer's state. */
   public abstract String getAddrState();
   /** Get the customer's zip code.
    * @return String of customer's zip code. */
   public abstract String getAddrZip();
   /** Get the customer's phone.
    * @return String of customer's phone. */
   public abstract String getPhone();

   public abstract void setCustomerID(String id);
   public abstract void setPassword(String password);
   public abstract void setFirstName(String firstName);
   public abstract void setLastName(String lastName);
   public abstract void setAddr1(String addr1);
   public abstract void setAddr2(String addr2);
   public abstract void setAddrCity(String city);
   public abstract void setAddrState(String state);
   public abstract void setAddrZip(String zip);
   public abstract void setPhone(String phone);

   /** ejbLoad Session EJB lifecycle callback method.*/
   public void ejbLoad() { }
   /** ejbStore Session EJB lifecycle callback method.*/
   public void ejbStore() { }
   /** ejbRemove Session EJB lifecycle callback method.*/
   public void ejbRemove() { }
   /** ejbActivate Session EJB lifecycle callback method.*/
   public void ejbActivate() { }
   /** ejbPassivate Session EJB lifecycle callback method.*/
   public void ejbPassivate() { }
   /**
    * setEntityContext Entity EJB lifecycle callback method to set the EJB entityContext for this EJB.
    *
    * @param ctx javax.ejb.EntityContext The context for this entity EJB.
    */
   public void setEntityContext (EntityContext ctx) { }
   /**
    * unsetEntityContext Entity EJB lifecycle callback method to unset the EJB entityContext for this EJB.
    */
   public void unsetEntityContext () { }

}


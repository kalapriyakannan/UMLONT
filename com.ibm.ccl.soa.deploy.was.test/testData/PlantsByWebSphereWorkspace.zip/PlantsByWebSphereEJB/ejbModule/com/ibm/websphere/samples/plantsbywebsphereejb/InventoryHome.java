//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

/**
 * Home interface for Inventory entity bean.
 */
import java.util.Collection;
import javax.ejb.CreateException;
import javax.ejb.FinderException;

public interface InventoryHome extends javax.ejb.EJBLocalHome
{
   /** 
    * Create a new Inventory.
    *
    * @param key InventoryKey
    * @param name Name of inventory item.
    * @param heading Description heading of inventory item.
    * @param desc Description of inventory item.
    * @param pkginfo Package info of inventory item.
    * @param image Image of inventory item.
    * @param imgbytes Array of bytes containing the image of the inventory item.
    * @param price Price of inventory item.
    * @param cost Cost of inventory item.
    * @param quantity Quantity of inventory items in stock.
    * @param category Category of inventory item.
    * @param notes Notes of inventory item.
    * @param isPublic Access permission of inventory item.
    */
   public abstract Inventory create(InventoryKey key, String name, String heading, String desc, String pkginfo, String image, /*byte[] imgbytes,*/
   float price, float cost, int quantity, int category, String notes, int isPublic) throws CreateException;

   /** 
    * Create a new Inventory.
    *
    * @param item StoreItem to use to make a new inventory item.
    */
   public abstract Inventory create(StoreItem item) throws CreateException;

   /**
    * Finds the Inventory bean with the specified key.
    * @param key InventoryKey of Inventory bean desired.
    * @return The Inventory bean desired.
    */
   public abstract Inventory findByPrimaryKey(InventoryKey key) throws FinderException;

   /**
    * Finds all Inventory beans by category type.
    * @param category Category of Inventory bean wanted.
    * @return A Collection of Inventory beans which match the category.
    */
   public abstract Collection findByCategory(int category) throws FinderException;

   /**
    * Finds all Inventory beans by whose name contains the given string.
    * @param category Category of Inventory bean wanted.
    * @return A Collection of Inventory beans whose name contain the given string.
    */
   public abstract Collection findByNameLikeness(String name) throws FinderException;
   /**
    * Creates an instance from a key for Entity Bean: Inventory
    */
   public com.ibm.websphere.samples.plantsbywebsphereejb.Inventory create(java.lang.String inventoryID) throws javax.ejb.CreateException;
}

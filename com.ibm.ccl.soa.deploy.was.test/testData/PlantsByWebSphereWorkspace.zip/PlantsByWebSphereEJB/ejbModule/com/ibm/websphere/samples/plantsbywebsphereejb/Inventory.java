//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

/**
 * Local interface for Inventory entity bean.
 */
public interface Inventory extends javax.ejb.EJBLocalObject
{
   /*** Get the inventory ID.
    * @return String The inventory ID. */
   public String getID();
   /*** Get the inventory item name.
    * @return The inventory item name. */
   public String getName();
   /*** Get the inventory item description heading.
    * @return The inventory item description heading. */
   public String getHeading();
   /*** Get the inventory item description.
    * @return The inventory item description. */
   public String getDescription();
   /*** Get the inventory item package info.
    * @return The inventory item package info. */
   public String getPkginfo();
   /*** Get the inventory item image file name.
    * @return The inventory item image file name. */
   public String getImage();
   /*** Get the inventory item image binary data.
    * @return The inventory item image binary data. */
   public byte[] getImgbytes();
   /*** Get the inventory item price.
    * @return The inventory item price. */
   public float getPrice();
   /*** Get the inventory item cost.
    * @return The inventory item cost. */
   public float getCost();
   /*** Get the quantity of inventory in stock.
    * @return The quantity of inventory in stock. */
   public int getQuantity();
   /*** Get the inventory category.
    * @return The inventory category. */
   public int getCategory();
   /*** Get the notes of inventory in stock.
    * @return The inventory notes. */
   public String getNotes();

   /** 
    * Is this inventory item viewable by the public?
    *
    * @return True, if the public can view this inventory item.
    */
   public boolean isPublic();

   /** Set the inventory item's name. */
   public void setName(String name);
   /** Set the inventory item's description heading. */
   public void setHeading(String heading);
   /** Set the inventory item's description. */
   public void setDescription(String desc);
   /** Set the inventory item's package info. */
   public void setPkginfo(String pkginfo);
   /** Set the inventory item's category. */
   public void setCategory(int category);
   /** Set the inventory item's image file name. */
   public void setImage(String image);
   /** Set the inventory item's image binary data. */
   public void setImgbytes(byte[] imgbytes);
   /** Set the inventory item's price. */
   public void setPrice(float price);
   /** Set the inventory item's cost. */
   public void setCost(float cost);
   /** Set the inventory item's quantity in stock. */
   public void setQuantity(int amount);
   /** Set the inventory item's notes. */
   public void setNotes(String note);
   /** Set the inventory item's public availability. */
   public void setPrivacy(boolean isPublic);

   /**
    * Increase the quantity of this inventory item.
    * @param quantity The number to increase the inventory by.
    */
   public void increaseInventory(int quantity);
   /**
    * Decrease the quantity of this inventory item.
    * @param quantity The number to decrease the inventory by.
    * @return int The number of inventory items removed.
    */
   public int decreaseInventory(int quantity);

   /**
    * Method getMinThreshold.
    * @return int
    */
   /**
    * Get accessor for persistent attribute: minThreshold
    */
   public int getMinThreshold();
   /**
    * Method setMinThreshold.
    * @param newMinThreshold
    */
   /**
    * Set accessor for persistent attribute: minThreshold
    */
   public void setMinThreshold(int newMinThreshold);
   /**
    * Method getMaxThreshold.
    * @return int
    */
   /**
    * Get accessor for persistent attribute: maxThreshold
    */
   public int getMaxThreshold();
   /**
    * Method setMaxThreshold.
    * @param newMaxThreshold
    */
   /**
    * Set accessor for persistent attribute: maxThreshold
    */
   public void setMaxThreshold(int newMaxThreshold);
}

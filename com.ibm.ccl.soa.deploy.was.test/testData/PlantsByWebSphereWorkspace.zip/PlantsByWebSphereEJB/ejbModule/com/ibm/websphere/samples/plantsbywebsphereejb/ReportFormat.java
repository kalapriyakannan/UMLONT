//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.util.Vector;

/**
 * Report format for database query.  Currently, this format only determines whether
 * the data is sorted in an ascending or descending order.  This class can be expanded
 * to allow for selecting what columns appear, order of columns, etc.
 */
public class ReportFormat implements java.io.Serializable
{
   private boolean ascending;

   /**
    * Create a ReportFormat object which defaults to an ascending sort order.
    */
   public ReportFormat()
   {
      ascending = true;
   }                                                

   /**
    * Create a ReportFormat object.
    *
    * @param ascending A boolean value set to TRUE when sortingby ascending
    * values, and FALSE when sorting by descending values.
    */
   public ReportFormat(boolean ascending)
   {
      this.ascending = ascending;
   }                                                

   /**
    * Used to establish the sorting rules.
    *
    * @param field The field to sort by.
    * @param priority When multiple sorting is desired, the data will be
    * sorted according to priority. Priority 1 will be the first sort, followed
    * by priority 2, and so on.
    * @param ascending A boolean value set to TRUE when sortingby ascending
    * values, and FALSE when sorting by descending values.
    */
   public void sortBy(boolean ascending)
   {
      this.ascending = ascending;
   }

   /**
    * Is report sorted in ascending order?
    *
    * @return True, if ascending.
    */
   public boolean isAscending()
   {
      return ascending;
   }
}

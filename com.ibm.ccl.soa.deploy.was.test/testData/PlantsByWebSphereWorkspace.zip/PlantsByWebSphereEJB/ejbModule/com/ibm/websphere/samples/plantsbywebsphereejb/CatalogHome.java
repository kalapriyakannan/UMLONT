//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;
import javax.ejb.CreateException;

/**
 * Home interface for Catalog stateless session bean.
 */
public interface CatalogHome extends javax.ejb.EJBHome
{
    /**
     * @return Catalog The Catalog EJB object.
     * @exception javax.ejb.CreateException Catalog EJB object was not created.
     */
    public Catalog create() throws CreateException, RemoteException;

}


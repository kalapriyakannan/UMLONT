//
// "This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
// instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
// or for redistribution by customer, as part of such an application, in customer's own products. " 
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2003,2003
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.util.Collection;

/**
 * Local Home interface for Enterprise Bean: BackOrderStock
 */
public interface BackOrderLocalHome extends javax.ejb.EJBLocalHome
{
   /**
    * Creates an instance from a key for Entity Bean: BackOrder
    */
   public com.ibm.websphere.samples.plantsbywebsphereejb.BackOrderLocal create(java.lang.String backOrderID) throws javax.ejb.CreateException;

   /**
    * Method create.
    * @param inventoryID
    * @param quantity
    * @return BackOrder
    * @throws CreateException
    */
   public com.ibm.websphere.samples.plantsbywebsphereejb.BackOrderLocal create(java.lang.String inventoryID, int quantity) throws javax.ejb.CreateException;
   /**
    * Method findByPrimaryKey.
    * @param primaryKey
    * @return BackOrderLocal
    * @throws FinderException
    */
   /**
    * Finds an instance using a key for Entity Bean: BackOrder
    */
   public BackOrderLocal findByPrimaryKey(BackOrderKey primaryKey) throws javax.ejb.FinderException;
   /**
    * Method findAll.
    * @return Collection
    * @throws FinderException
    */
   /**
    * findAll
    */
   public abstract java.util.Collection findAll() throws javax.ejb.FinderException;
   /**
    * Method findByInventoryID.
    * @return BackOrder
    * @throws FinderException
    */
   public abstract com.ibm.websphere.samples.plantsbywebsphereejb.BackOrderLocal findByInventoryID(java.lang.String inventoryID) throws javax.ejb.FinderException;
}

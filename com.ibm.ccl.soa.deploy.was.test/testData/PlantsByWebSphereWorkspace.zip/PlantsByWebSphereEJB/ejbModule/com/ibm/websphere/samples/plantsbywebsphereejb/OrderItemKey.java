package com.ibm.websphere.samples.plantsbywebsphereejb;
/**
 * Key class for Entity Bean: OrderItem
 */
public class OrderItemKey implements java.io.Serializable {
   static final long serialVersionUID = 3206093459760846163L;
   /**
    * Implementation field for persistent attribute: inventoryID
    */
   public java.lang.String inventoryID;
	/**
	 * Implementation field for persistent attribute: order_orderID
	 */
	public java.lang.String order_orderID;
   /**
    * Creates an empty key for Entity Bean: OrderItem
    */
   public OrderItemKey() {  Util.debug("OrderItemKey()"); }
	/**
	 * Creates a key for Entity Bean: OrderItem
	 */
	public OrderItemKey(
		java.lang.String inventoryID,
		com.ibm.websphere.samples.plantsbywebsphereejb.OrderKey argOrder) {
		Util.debug("OrderItemKey() inventoryID=" + inventoryID + "=");
		Util.debug("OrderItemKey() orderID=" + argOrder.getOrderID() + "=");
		this.inventoryID = inventoryID;
		privateSetOrderKey(argOrder);
	}
	/**
	 * Returns true if both keys are equal.
	 */
	public boolean equals(java.lang.Object otherKey) {
		if (otherKey
			instanceof com.ibm.websphere.samples.plantsbywebsphereejb.OrderItemKey) {
			com.ibm.websphere.samples.plantsbywebsphereejb.OrderItemKey o =
				(com
					.ibm
					.websphere
					.samples
					.plantsbywebsphereejb
					.OrderItemKey) otherKey;
			return (
				(this.inventoryID.equals(o.inventoryID))
					&& (this.order_orderID.equals(o.order_orderID)));
		}
		return false;
	}
	/**
	 * Returns the hash code for the key.
	 */
	public int hashCode() {
		Util.debug("OrderItemKey.hashCode() inventoryID=" + inventoryID + "=");
		Util.debug("OrderItemKey.hashCode() orderID=" + order_orderID + "=");

		return (inventoryID.hashCode() + order_orderID.hashCode());
	}
	/**
	 * This method was generated for supporting the relationship role named order.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public com
		.ibm
		.websphere
		.samples
		.plantsbywebsphereejb
		.OrderKey getOrderKey() {
		com.ibm.websphere.samples.plantsbywebsphereejb.OrderKey temp =
			new com.ibm.websphere.samples.plantsbywebsphereejb.OrderKey();
		boolean order_NULLTEST = true;
		order_NULLTEST &= (order_orderID == null);
		temp.orderID = order_orderID;
		if (order_NULLTEST)
			temp = null;
		return temp;
	}
	/**
	 * This method was generated for supporting the relationship role named order.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public void privateSetOrderKey(
		com.ibm.websphere.samples.plantsbywebsphereejb.OrderKey inKey) {
		boolean order_NULLTEST = (inKey == null);
		order_orderID = (order_NULLTEST) ? null : inKey.orderID;
	}
}

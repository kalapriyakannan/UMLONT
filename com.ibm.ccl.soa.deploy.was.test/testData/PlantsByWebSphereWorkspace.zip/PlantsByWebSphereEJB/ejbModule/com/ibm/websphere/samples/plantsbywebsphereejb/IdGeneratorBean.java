package com.ibm.websphere.samples.plantsbywebsphereejb;
/**
 * Bean implementation class for Enterprise Bean: IdGenerator
 */
public abstract class IdGeneratorBean implements javax.ejb.EntityBean 
{
   private javax.ejb.EntityContext myEntityCtx;
   
   /**
    * ejbCreate
    */
   public IdGeneratorKey ejbCreate(String idName) throws javax.ejb.CreateException 
   {
      setIdName(idName);
      return null;
   }
   /**
    * ejbPostCreate
    */
   public void ejbPostCreate(String idName) throws javax.ejb.CreateException {   }
   
   /**
    * ejbCreate
    */
   public IdGeneratorKey ejbCreate(String idName, int idValue) throws javax.ejb.CreateException 
   {
      setIdName(idName);
      setIdValue(idValue);
      return null;
   }
   /**
    * ejbPostCreate
    */
   public void ejbPostCreate(String idName, int idValue) throws javax.ejb.CreateException {   }
   
   /**
    * Get accessor for persistent attribute: idName
    */
   public abstract String getIdName();
   
   /**
    * Set accessor for persistent attribute: idName
    */
   public abstract void setIdName(String newIdName);

   /**
    * Get accessor for persistent attribute: idValue
    */
   public abstract int getIdValue();
   
   /**
    * Set accessor for persistent attribute: idValue
    */
   public abstract void setIdValue(int newIdValue);
   
   /**
    * Get the next available id.
    */
   public int nextId() 
   {
      int i = getIdValue();
      i++;
      setIdValue(i);    
      return i;
   }
  
    /**
    * setEntityContext
    */
   public void setEntityContext(javax.ejb.EntityContext ctx) {
      myEntityCtx = ctx;
   }
   /**
    * getEntityContext
    */
   public javax.ejb.EntityContext getEntityContext() {
      return myEntityCtx;
   }
   /**
    * unsetEntityContext
    */
   public void unsetEntityContext() {
      myEntityCtx = null;
   }
  
   /**
    * ejbActivate
    */
   public void ejbActivate() {   }
   /**
    * ejbLoad
    */
   public void ejbLoad() {   }
   /**
    * ejbPassivate
    */
   public void ejbPassivate() {   }
   /**
    * ejbRemove
    */
   public void ejbRemove() throws javax.ejb.RemoveException {   }
   /**
    * ejbStore
    */
   public void ejbStore() {   }
}

//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.io.*;
import java.rmi.RemoteException;
import java.sql.*;
import java.util.*;
import javax.ejb.*;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;

/**
 * CatalogBean is the implementation class for the {@link Catalog} stateless session
 * EJB.  CatalogBean implements each of the business methods in the <code>Catalog</code>
 * EJB remote interface and each of the EJB lifecycle methods in the javax.ejb.SessionBean
 * interface.
 * 
 * @see Catalog
 * @see CatalogHome
 */

public class CatalogBean implements SessionBean
{
   /**
    * Get all inventory items.
    *
    * @return Vector of StoreItems.
    */
   public Vector getItems()
   {
      Vector items = new Vector();
      int count = Util.getCategoryStrings().length;
      for (int i = 0; i < count; i++)
      {
         items.addAll(getItemsByCategory(i));
      }
      return items;
   }

   /**
    * Get all inventory items for the given category.
    *
    * @param Category of items desired.
    * @return Vector of StoreItems.
    */
   public Vector getItemsByCategory(int category)
   {
      Vector items = new Vector();
      try
      {
         InventoryHome invHome = (InventoryHome) Util.getEJBLocalHome("java:comp/env/ejb/Inventory",
               com.ibm.websphere.samples.plantsbywebsphereejb.InventoryHome.class);
         Collection invCollection = invHome.findByCategory(category);

         Iterator invs = invCollection.iterator();
         Inventory inv;
         while (invs.hasNext())
         {
            inv = (Inventory) invs.next();
            items.addElement( new StoreItem(inv) );
         }
      }
      catch (FinderException e) { e.printStackTrace(); }

      return items;
   }

   /**
    * Get inventory items that contain a given String within their names.
    *
    * @param name String to search names for.
    * @return A Vector of StoreItems that match.
    */
   public Vector getItemsLikeName(String name)
   {
      Vector items = new Vector();
      try
      {
         InventoryHome invHome = (InventoryHome) Util.getEJBLocalHome("java:comp/env/ejb/Inventory",
               com.ibm.websphere.samples.plantsbywebsphereejb.InventoryHome.class);
         Collection invCollection = invHome.findByNameLikeness('%' + name + '%');

         Iterator invs = invCollection.iterator();
         Inventory inv;
         while (invs.hasNext())
         {
            inv = (Inventory) invs.next();
            items.addElement( new StoreItem(inv) );
         }
      }
      catch (FinderException e) { e.printStackTrace(); }

      return items;
   }

   /**
    * Get the Inventory item for the given ID.
    *
    * @param inventoryID - ID of the Inventory item desired.
    * @return StoreItem
    */
   public StoreItem getItem(String inventoryID)
   {
      StoreItem si = null;
      try
      {
         InventoryHome invHome = (InventoryHome) Util.getEJBLocalHome("java:comp/env/ejb/Inventory",
               com.ibm.websphere.samples.plantsbywebsphereejb.InventoryHome.class);
         Inventory inv = invHome.findByPrimaryKey(new InventoryKey(inventoryID));
         si = new StoreItem(inv);
      }
      catch (FinderException e)
      {
         e.printStackTrace();
      }

      return si;
   }

   /**
    * Add an inventory item.
    *
    * @param item The StoreItem to add.
    * @return True, if item added.
    */
   public boolean addItem(StoreItem item)
   {
      boolean retval = false;
      try
      {
         InventoryHome invHome = (InventoryHome) Util.getEJBLocalHome("java:comp/env/ejb/Inventory",
               com.ibm.websphere.samples.plantsbywebsphereejb.InventoryHome.class);
         Inventory inv = invHome.create(item);

         // If inventory is not null, then return TRUE to indicate add succeeded.
         if (inv != null)
            retval = true;
      }
      catch (CreateException e) { e.printStackTrace(); }

      return retval;
   }

   /**
    * Delete an inventory item.
    *
    * @param inventoryID The ID of the inventory item to delete.
    * @return True, if item deleted.
    */
   public boolean deleteItem(String inventoryID)
   {
      boolean retval = false;
      try
      {
         InventoryHome invHome = (InventoryHome) Util.getEJBLocalHome("java:comp/env/ejb/Inventory",
               com.ibm.websphere.samples.plantsbywebsphereejb.InventoryHome.class);
         Inventory inv = invHome.findByPrimaryKey(new InventoryKey(inventoryID));
         inv.remove();
         retval = true;
      }
      catch (FinderException e) { e.printStackTrace(); }
      catch (RemoveException e) { e.printStackTrace(); }

      return retval;
   }

   /**
    * Set the inventory item's name.
    *
    * @param inventoryID The inventory item's ID.
    * @param desc The inventory item's new name.
    */
   public void setItemName(String inventoryID, String name) 
   { 
      Inventory inv = getInv(inventoryID);
      if (inv != null)
      {
         inv.setName(name);
      }
   }

   /**
    * Set the inventory item's heading.
    *
    * @param inventoryID The inventory item's ID.
    * @param desc The inventory item's new heading.
    */
   public void setItemHeading(String inventoryID, String heading)
   { 
      Inventory inv = getInv(inventoryID);
      if (inv != null)
      {
         inv.setHeading(heading);
      }
   }

   /**
    * Set the inventory item's description.
    *
    * @param inventoryID The inventory item's ID.
    * @param desc The inventory item's new description.
    */
   public void setItemDescription(String inventoryID, String desc) 
   { 
      Inventory inv = getInv(inventoryID);
      if (inv != null)
      {
         inv.setDescription(desc);
      }
   }

   /**
    * Set the inventory item's package information.
    *
    * @param inventoryID The inventory item's ID.
    * @param desc The inventory item's new package information.
    */
   public void setItemPkginfo(String inventoryID, String pkginfo) 
   { 
      Inventory inv = getInv(inventoryID);
      if (inv != null)
      {
         inv.setPkginfo(pkginfo);
      }
   }

   /**
    * Set the inventory item's category.
    *
    * @param inventoryID The inventory item's ID.
    * @param category The inventory item's new category.
    */
   public void setItemCategory(String inventoryID, int category)
   { 
      Inventory inv = getInv(inventoryID);
      if (inv != null)
      {
         inv.setCategory(category);
      }
   }
 
   /**
    * Set the inventory item's image file name.
    *
    * @param inventoryID The inventory item's ID.
    * @param imageName The inventory item's new image file name.
    */
   public void setItemImageFileName(String inventoryID, String imageName)
   { 
      Inventory inv = getInv(inventoryID);
      if (inv != null)
      {
         inv.setImage(imageName);
      }
   }

   /** 
    * Get the image for the inventory item.
    * @param inventoryID The id of the inventory item wanted.
    * @return Buffer containing the image.
    */
   public byte[] getItemImageBytes(String inventoryID)
   {
      byte[] retval = null;
      Inventory inv = getInv(inventoryID);
      if (inv != null)
      {
         retval = inv.getImgbytes();
      }

      return retval;
   }

   /** 
    * Set the image for the inventory item. 
    * @param inventoryID The id of the inventory item wanted.
    * @param imgbytes Buffer containing the image.
    */
   public void setItemImageBytes(String inventoryID, byte[] imgbytes)
   {
      Inventory inv = getInv(inventoryID);
      if (inv != null)
      {
         inv.setImgbytes(imgbytes);
      }
   }

   /**
    * Set the inventory item's price.
    *
    * @param inventoryID The inventory item's ID.
    * @param price The inventory item's new price.
    */
   public void setItemPrice(String inventoryID, float price)
   { 
      Inventory inv = getInv(inventoryID);
      if (inv != null)
      {
         inv.setPrice(price);
      }
   }

   /**
    * Set the inventory item's cost.
    *
    * @param inventoryID The inventory item's ID.
    * @param cost The inventory item's new cost.
    */
   public void setItemCost(String inventoryID, float cost)
   { 
      Inventory inv = getInv(inventoryID);
      if (inv != null)
      {
         inv.setCost(cost);
      }
   }

   /**
    * Set the inventory item's quantity.
    *
    * @param inventoryID The inventory item's ID.
    * @param quantity The inventory item's new quantity.
    */
   public void setItemQuantity(String inventoryID, int quantity)
   { 
      Inventory inv = getInv(inventoryID);
      if (inv != null)
      {
         inv.setQuantity(quantity);
      }
   }

   /**
    * Set the inventory item's notes.
    *
    * @param inventoryID The inventory item's ID.
    * @param notes The inventory item's new notes.
    */
   public void setItemNotes(String inventoryID, String notes)
   { 
      Inventory inv = getInv(inventoryID);
      if (inv != null)
      {
         inv.setNotes(notes);
      }
   }

   /**
    * Set the inventory item's access availability.
    *
    * @param inventoryID The inventory item's ID.
    * @param isPublic True, if this item can be viewed by the public.
    */
   public void setItemPrivacy(String inventoryID, boolean isPublic)
   { 
      Inventory inv = getInv(inventoryID);
      if (inv != null)
      {
         inv.setPrivacy(isPublic);
      }
   }

   /**
    * Get a remote Inventory object.
    *
    * @param inventoryID The id of the inventory item wanted.
    * @return Reference to the remote Inventory object.
    */
   private Inventory getInv(String inventoryID)
   {
      Inventory inv = null;
      try
      {
         InventoryHome invHome = (InventoryHome) Util.getEJBLocalHome("java:comp/env/ejb/Inventory",
               com.ibm.websphere.samples.plantsbywebsphereejb.InventoryHome.class);
         inv = invHome.findByPrimaryKey(new InventoryKey(inventoryID));
      }
      catch (FinderException e) { e.printStackTrace(); }

      return inv;
   }

   /**
    * ejbCreate Session EJB lifecycle callback method. This method is empty for Stateless EJB.
    * This method corresponds to the create method in the home interface.
    */
   public void ejbCreate() throws CreateException { }

   /**
    * ejbRemove Session EJB lifecycle callback method. This method is empty for Stateless EJB.
    * Called just before the end of life for this object.
    */
   public void ejbRemove() { }

   /**
    * ejbActivate Session EJB lifecycle callback method. This method is empty for Stateless EJB.
    */
   public void ejbActivate() { }

   /**
    * ejbPassivate Session EJB lifecycle callback method. This method is empty for Stateless EJB.
    * Called when the instance is passivated from its "active" state, and releases.
    */
   public void ejbPassivate() { }

   /**
    * setSessionContext Session EJB lifecycle callback method to set the EJB sessionContext for this EJB.
    *
    * @param ctx javax.ejb.SessionContext The context for this session EJB.
    */
   public void setSessionContext (SessionContext ctx) { }

}


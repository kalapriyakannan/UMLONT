//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.Hashtable;

/**
 * A class to hold a shopping cart's contents.
 */
public class ShoppingCartContents implements java.io.Serializable
{
   private Hashtable table = null;

   public ShoppingCartContents()
   {
      table = new Hashtable();
   }

   /** Add the item to the shopping cart. */
   public void addItem(StoreItem si)
   {
      table.put(si.getID(), new Integer(si.getQuantity()));
   }

   /** Update the item in the shopping cart. */
   public void updateItem(StoreItem si)
   {
      table.put(si.getID(), new Integer(si.getQuantity()));
   }

   /** Remove the item from the shopping cart. */
   public void removeItem(StoreItem si)
   {
      table.remove(si.getID());
   }

   /** 
    * Return the number of items in the cart.
    *
    * @return The number of items in the cart.
    */
   public int size()
   {
      return table.size();
   }

   /**
    * Return the inventory ID at the index given.  The first element
    * is at index 0, the second at index 1, and so on.
    *
    * @return The inventory ID at the index, or NULL if not present.
    */
   public String getInventoryID(int index)
   {
      String retval = null;
      String inventoryID;
      int cnt = 0;
      for (Enumeration enum = table.keys(); enum.hasMoreElements(); cnt++)
      {
         inventoryID = (String) enum.nextElement();
         if (index == cnt)
         {
            retval = inventoryID;
            break;
         }
      }
      return retval;
   }

   /** 
    * Return the quantity for the inventory ID given.
    *
    * @return The quantity for the inventory ID given..
    *
    */
   public int getQuantity(String inventoryID)
   {
      Integer quantity = (Integer) table.get(inventoryID);

      if (quantity == null)
         return 0;
      else
         return quantity.intValue();
   }

}

package com.ibm.websphere.samples.plantsbywebsphereejb;
/**
 * Key class for Entity Bean: IdGenerator
 */
public class IdGeneratorKey implements java.io.Serializable {
   static final long serialVersionUID = 3206093459760846163L;
   /**
    * Implementation field for persistent attribute: idName
    */
   public String idName;
   /**
    * Creates an empty key for Entity Bean: IdGenerator
    */
   public IdGeneratorKey() { }
   /**
    * Creates a key for Entity Bean: IdGenerator
    */
   public IdGeneratorKey(String idName) { this.idName = idName; }
   /**
    * Returns true if both keys are equal.
    */
   public boolean equals(java.lang.Object otherKey) 
   {
      if (otherKey instanceof IdGeneratorKey) 
      {
         IdGeneratorKey o = (IdGeneratorKey) otherKey;
         return ((this.idName == o.idName));
      }
      return false;
   }
   /**
    * Returns the hash code for the key.
    */
   public int hashCode() 
   {
      return ((new java.lang.String(idName).hashCode()));
   }
   /**
    * Get accessor for persistent attribute: idName
    */
   public String getIdName() { return idName; }
   /**
    * Set accessor for persistent attribute: idName
    */
   public void setIdName(String newIdName) { idName = newIdName; }
}

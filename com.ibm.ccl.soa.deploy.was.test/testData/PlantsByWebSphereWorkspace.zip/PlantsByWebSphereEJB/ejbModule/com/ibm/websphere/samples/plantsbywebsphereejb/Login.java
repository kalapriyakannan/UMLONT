//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;

/**
 * Remote interface for Login stateless session bean.
 */
public interface Login extends javax.ejb.EJBObject
{
	/**
	 * Verify that the user exists and the password is value.
	 * 
	 * @param customerID The customer ID
	 * @param password The password for the customer ID
	 * @return String with a results message.
	 */
	public String verifyUserAndPassword(String customerID,
	                                     String password) throws RemoteException;
   /**
    * Create a new user.
    *
    * @param customerID The new customer ID.
    * @param password The password for the customer ID.
    * @param firstName First name.
    * @param lastName Last name.
    * @param addr1 Address line 1.
    * @param addr2 Address line 2.
    * @param addrCity City address information.
    * @param addrState State address information.
    * @param addrZip Zip code address information.
    * @param phone User's phone number.
    * @return CustomerInfo
    */
    public CustomerInfo createNewUser(String customerID, String password, String firstName, 
                                      String lastName, String addr1, String addr2,
                                      String addrCity, String addrState, String addrZip,
                                      String phone) throws RemoteException;
            
    /**
     * Retrieve an existing user.
     * 
     * @param customerID The customer ID.
     * @return CustomerInfo
     */
    public CustomerInfo getCustomerInfo(String customerID) throws RemoteException;
    
    /**
     * Update an existing user.
     *
     * @param customerID The customer ID.
     * @param firstName First name.
     * @param lastName Last name.
     * @param addr1 Address line 1.
     * @param addr2 Address line 2.
     * @param addrCity City address information.
     * @param addrState State address information.
     * @param addrZip Zip code address information.
     * @param phone User's phone number.
     * @return CustomerInfo
     */
    public CustomerInfo updateUser(String customerID, String firstName, String lastName, 
                                   String addr1, String addr2, String addrCity, 
                                   String addrState, String addrZip, String phone)
                                  throws RemoteException;
}


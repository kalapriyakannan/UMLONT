//
// "This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
// instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
// or for redistribution by customer, as part of such an application, in customer's own products. " 
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2003,2003
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;
import java.util.Collection;

/**
 * Home interface for Enterprise Bean: BackOrder
 */
public interface BackOrderHome extends javax.ejb.EJBHome
{
   /**
    * Method create.
    * @param backOrderID
    * @return BackOrder
    * @throws CreateException
    * @throws RemoteException
    */
   /**
    * Creates an instance from a key for Entity Bean: BackOrder
    */
   public com.ibm.websphere.samples.plantsbywebsphereejb.BackOrder create(java.lang.String backOrderID) throws javax.ejb.CreateException, java.rmi.RemoteException;
   /**
    * Method ejbCreate.
    * @param inventoryID
    * @param quantity
    * @return BackOrderKey
    * @throws CreateException
    * @throws RemoteException
    */
   public com.ibm.websphere.samples.plantsbywebsphereejb.BackOrder create(java.lang.String inventoryID, int quantity) throws javax.ejb.CreateException, java.rmi.RemoteException;
   /**
    * Method findByPrimaryKey.
    * @param primaryKey
    * @return BackOrder
    * @throws FinderException
    * @throws RemoteException
    */
   /**
    * Finds an instance using a key for Entity Bean: BackOrder
    */
   public BackOrder findByPrimaryKey(BackOrderKey primaryKey) throws javax.ejb.FinderException, RemoteException;

   /**
    * Method findAll.
    * @return Collection
    * @throws FinderException
    * @throws RemoteException
    */
   public abstract Collection findAll() throws javax.ejb.FinderException, RemoteException;
   /**
    * Method findByInventoryID.
    * @param inventoryID
    * @return BackOrder
    * @throws FinderException
    * @throws RemoteException
    */
   public abstract BackOrder findByInventoryID(java.lang.String inventoryID) throws javax.ejb.FinderException, RemoteException;
}

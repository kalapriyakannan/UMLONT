package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.util.Vector;

/**
 * Local Home interface for Enterprise Bean: Order
 */
public interface OrderHome extends javax.ejb.EJBLocalHome 
{
	/**
    * Constructor to create an Order.
    *
    * @param customerID - customer's ID
    * @param billName - billing name
    * @param billAddr1 - billing address line 1
    * @param billAddr2 - billing address line 2
    * @param billCity - billing address city
    * @param billState - billing address state
    * @param billZip - billing address zip code
    * @param billPhone - billing phone
    * @param shipName - shippng name
    * @param shipAddr1 - shippng address line 1
    * @param shipAddr2 - shippng address line 2
    * @param shipCity - shippng address city
    * @param shipState - shippng address state
    * @param shipZip - shippng address zip code
    * @param shipPhone - shippng phone
    * @param creditCard - credit card
    * @param ccNum - credit card number
    * @param ccExpireMonth - credit card expiration month
    * @param ccExpireYear - credit card expiration year
    * @param cardHolder - credit card holder name
    * @param shippingMethod int of shipping method used
    * @param items vector of StoreItems ordered
    * @return Order created
    */
   public Order create(String customerID, String billName, String billAddr1, String billAddr2,
             String billCity, String billState, String billZip, String billPhone,
             String shipName, String shipAddr1, String shipAddr2,
             String shipCity, String shipState, String shipZip, String shipPhone,
             String creditCard, String ccNum, String ccExpireMonth, String ccExpireYear,
             String cardHolder, int shippingMethod, Vector items)
		throws javax.ejb.CreateException;
		
	/**
	 * Finds an instance using a key for Entity Bean: Order
	 */
   public Order findByPrimaryKey(OrderKey primaryKey)
       throws javax.ejb.FinderException;
       
   /**
    * Creates an instance from a key for Entity Bean: Order
    */
   public Order create(java.lang.String orderID) throws javax.ejb.CreateException;
}

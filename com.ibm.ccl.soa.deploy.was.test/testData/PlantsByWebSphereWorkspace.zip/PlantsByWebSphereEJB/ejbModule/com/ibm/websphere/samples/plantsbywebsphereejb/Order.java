package com.ibm.websphere.samples.plantsbywebsphereejb;
/**
 * Local interface for Enterprise Bean: Order
 */
public interface Order extends javax.ejb.EJBLocalObject {
	/**
	 * Get accessor for persistent attribute: sellDate
	 */
	public java.lang.String getSellDate();
	/**
	 * Set accessor for persistent attribute: sellDate
	 */
	public void setSellDate(java.lang.String newSellDate);
	/**
	 * Get accessor for persistent attribute: billName
	 */
	public java.lang.String getBillName();
	/**
	 * Set accessor for persistent attribute: billName
	 */
	public void setBillName(java.lang.String newBillName);
	/**
	 * Get accessor for persistent attribute: billAddr1
	 */
	public java.lang.String getBillAddr1();
	/**
	 * Set accessor for persistent attribute: billAddr1
	 */
	public void setBillAddr1(java.lang.String newBillAddr1);
	/**
	 * Get accessor for persistent attribute: billAddr2
	 */
	public java.lang.String getBillAddr2();
	/**
	 * Set accessor for persistent attribute: billAddr2
	 */
	public void setBillAddr2(java.lang.String newBillAddr2);
	/**
	 * Get accessor for persistent attribute: billCity
	 */
	public java.lang.String getBillCity();
	/**
	 * Set accessor for persistent attribute: billCity
	 */
	public void setBillCity(java.lang.String newBillCity);
	/**
	 * Get accessor for persistent attribute: billState
	 */
	public java.lang.String getBillState();
	/**
	 * Set accessor for persistent attribute: billState
	 */
	public void setBillState(java.lang.String newBillState);
	/**
	 * Get accessor for persistent attribute: billZip
	 */
	public java.lang.String getBillZip();
	/**
	 * Set accessor for persistent attribute: billZip
	 */
	public void setBillZip(java.lang.String newBillZip);
	/**
	 * Get accessor for persistent attribute: billPhone
	 */
	public java.lang.String getBillPhone();
	/**
	 * Set accessor for persistent attribute: billPhone
	 */
	public void setBillPhone(java.lang.String newBillPhone);
	/**
	 * Get accessor for persistent attribute: shipName
	 */
	public java.lang.String getShipName();
	/**
	 * Set accessor for persistent attribute: shipName
	 */
	public void setShipName(java.lang.String newShipName);
	/**
	 * Get accessor for persistent attribute: shipAddr1
	 */
	public java.lang.String getShipAddr1();
	/**
	 * Set accessor for persistent attribute: shipAddr1
	 */
	public void setShipAddr1(java.lang.String newShipAddr1);
	/**
	 * Get accessor for persistent attribute: shipAddr2
	 */
	public java.lang.String getShipAddr2();
	/**
	 * Set accessor for persistent attribute: shipAddr2
	 */
	public void setShipAddr2(java.lang.String newShipAddr2);
	/**
	 * Get accessor for persistent attribute: shipCity
	 */
	public java.lang.String getShipCity();
	/**
	 * Set accessor for persistent attribute: shipCity
	 */
	public void setShipCity(java.lang.String newShipCity);
	/**
	 * Get accessor for persistent attribute: shipState
	 */
	public java.lang.String getShipState();
	/**
	 * Set accessor for persistent attribute: shipState
	 */
	public void setShipState(java.lang.String newShipState);
	/**
	 * Get accessor for persistent attribute: shipZip
	 */
	public java.lang.String getShipZip();
	/**
	 * Set accessor for persistent attribute: shipZip
	 */
	public void setShipZip(java.lang.String newShipZip);
	/**
	 * Get accessor for persistent attribute: shipPhone
	 */
	public java.lang.String getShipPhone();
	/**
	 * Set accessor for persistent attribute: shipPhone
	 */
	public void setShipPhone(java.lang.String newShipPhone);
	/**
	 * Get accessor for persistent attribute: creditCard
	 */
	public java.lang.String getCreditCard();
	/**
	 * Set accessor for persistent attribute: creditCard
	 */
	public void setCreditCard(java.lang.String newCreditCard);
	/**
	 * Get accessor for persistent attribute: ccNum
	 */
	public java.lang.String getCcNum();
	/**
	 * Set accessor for persistent attribute: ccNum
	 */
	public void setCcNum(java.lang.String newCcNum);
	/**
	 * Get accessor for persistent attribute: ccExpireMonth
	 */
	public java.lang.String getCcExpireMonth();
	/**
	 * Set accessor for persistent attribute: ccExpireMonth
	 */
	public void setCcExpireMonth(java.lang.String newCcExpireMonth);
	/**
	 * Get accessor for persistent attribute: ccExpireYear
	 */
	public java.lang.String getCcExpireYear();
	/**
	 * Set accessor for persistent attribute: ccExpireYear
	 */
	public void setCcExpireYear(java.lang.String newCcExpireYear);
	/**
	 * Get accessor for persistent attribute: cardHolder
	 */
	public java.lang.String getCardHolder();
	/**
	 * Set accessor for persistent attribute: cardHolder
	 */
	public void setCardHolder(java.lang.String newCardHolder);
	/**
	 * Get accessor for persistent attribute: shippingMethod
	 */
	public int getShippingMethod();
	/**
	 * Set accessor for persistent attribute: shippingMethod
	 */
	public void setShippingMethod(int newShippingMethod);
	/**
	 * Get accessor for persistent attribute: profit
	 */
	public float getProfit();
	/**
	 * Set accessor for persistent attribute: profit
	 */
	public void setProfit(float newProfit);
   /**
    * Get accessor for persistent attribute: orderID
    */
   public java.lang.String getOrderID();
   /**
    * Set accessor for persistent attribute: orderID
    */
   public void setOrderID(java.lang.String newOrderID);
   /**
    * Get accessor for persistent attribute: customerID
    */
   public java.lang.String getCustomerID();
   /**
    * Set accessor for persistent attribute: customerID
    */
   public void setCustomerID(java.lang.String newCustomerID);
	/**
	 * This method was generated for supporting the relationship role named orderitem.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public java.util.Collection getOrderitem();
	/**
	 * This method was generated for supporting the relationship role named orderitem.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public void setOrderitem(java.util.Collection anOrderitem);
}

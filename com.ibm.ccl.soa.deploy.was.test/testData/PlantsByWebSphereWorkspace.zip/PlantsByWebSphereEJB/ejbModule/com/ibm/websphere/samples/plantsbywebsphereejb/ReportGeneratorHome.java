//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;
import javax.ejb.CreateException;

/**
 * Home interface for ReportGenerator stateless session bean.
 */
public interface ReportGeneratorHome extends javax.ejb.EJBHome
{
    /** Create a ReportGenerator session bean.
     * @return ReportGenerator The ReportGenerator EJB object.
     * @exception javax.ejb.CreateException ReportGenerator EJB object was not created.
     */
    public ReportGenerator create() throws CreateException, RemoteException;

}


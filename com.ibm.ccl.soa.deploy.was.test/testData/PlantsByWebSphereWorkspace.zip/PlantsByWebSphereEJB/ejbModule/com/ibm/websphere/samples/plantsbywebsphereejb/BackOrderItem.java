//
// "This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
// instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
// or for redistribution by customer, as part of such an application, in customer's own products. " 
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2003,2003
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;

/**
 * A class to hold a back order item's data.
 */
public class BackOrderItem implements java.io.Serializable
{
   private String backOrderID;
   private String inventoryID;
   private String name;
   private int quantity;
   private int inventoryQuantity;
   private String status;
   private long lowDate;
   private long orderDate;

   /**
    * @see java.lang.Object#Object()
    */
   /** Default constructor. */
   public BackOrderItem()
   {
   }

   /**
    * Method BackOrderItem.
    * @param backOrderID
    * @param inventoryID
    * @param name
    * @param quantity
    * @param status
    */
   public BackOrderItem(String backOrderID, String inventoryID, String name, int quantity, String status)
   {
      this.backOrderID = backOrderID;
      this.inventoryID = inventoryID;
      this.name = name;
      this.quantity = quantity;
      this.status = status;
      this.lowDate = lowDate;
   }

   /**
    * Method BackOrderItem.
    * @param backorderItem
    */
   public BackOrderItem(BackOrderLocal backOrder)
   {
      try
      {
         this.backOrderID = backOrder.getBackOrderID();
         this.inventoryID = backOrder.getInventoryID();
         this.name = backOrder.getName();
         this.quantity = backOrder.getQuantity();
         this.inventoryQuantity = backOrder.getInventoryQuantity();
         this.status = backOrder.getStatus();
         this.lowDate = backOrder.getLowDate();
         this.orderDate = backOrder.getOrderDate();
      }
      catch (Exception e)
      {
         Util.debug("BackOrderItem - Exception: " + e);
      }
   }
   /**
    * Method getBackOrderID.
    * @return String
    */
   public String getBackOrderID()
   {
      return backOrderID;
   }

   /**
    * Method setOrderID.
    * @param backOrderID
    */
   public void setBackOrderID(String backOrderID)
   {
      this.backOrderID = backOrderID;
   }

   /**
    * Method setQuantity.
    * @param quantity
    */
   public void setQuantity(int quantity)
   {
      this.quantity = quantity;
   }

   /**
    * Method getInventoryID.
    * @return String
    */
   public String getInventoryID()
   {
      return inventoryID;
   }

   /**
    * Method getName.
    * @return String
    */
   public String getName()
   {
      return name;
   }

   /**
    * Method getQuantity.
    * @return int
    */
   public int getQuantity()
   {
      return quantity;
   }


   /**
    * Method getInventoryQuantity.
    * @return int
    */
   public int getInventoryQuantity()
   {
      return inventoryQuantity;
   }
   /**
    * Method getStatus.
    * @return String
    */
   public String getStatus()
   {
      return status;
   }
   /**
    * Method getLowDate.
    * @return long
    */
   public long getLowDate()
   {
      return lowDate;
   }
   /**
    * Method getOrderDate.
    * @return long
    */
   public long getOrderDate()
   {
      return orderDate;
   }
}

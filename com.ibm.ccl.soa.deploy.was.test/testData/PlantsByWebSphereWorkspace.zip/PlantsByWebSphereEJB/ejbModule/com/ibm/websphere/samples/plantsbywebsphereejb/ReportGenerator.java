//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;
import java.util.Date;

/**
 * Remote interface for ReportGenerator stateless session bean.
 */
public interface ReportGenerator extends javax.ejb.EJBObject
{  
   /** 
    * Run the report to get the top selling items for a range of dates.
    */
   public Report getTopSellersForDates(Date startdate, Date enddate, int quantity,
                                       ReportFormat reportFormat) throws RemoteException;

   /** 
    * Run the report to get the top zip codes for a range of dates.
    */
   public Report getTopSellingZipsForDates(Date startdate, Date enddate, int quantity,
                                           ReportFormat reportFormat) throws RemoteException;
}


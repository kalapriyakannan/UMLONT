//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;
import javax.ejb.CreateException;

/**
 * Home interface for Mailer stateless session bean.
 */
public interface MailerHome extends javax.ejb.EJBHome 
{
   /** Create a Mailer session bean. */
    public Mailer create() throws CreateException, RemoteException;
}

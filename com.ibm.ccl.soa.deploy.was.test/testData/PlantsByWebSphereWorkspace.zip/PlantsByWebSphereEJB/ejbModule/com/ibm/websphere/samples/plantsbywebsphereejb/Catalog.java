//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebsphereejb;

import java.rmi.RemoteException;
import java.util.Vector;

/**
 * Remote interface for Catalog stateless session bean.
 */
public interface Catalog extends javax.ejb.EJBObject
{
   /**
    * Get all inventory items.
    *
    * @return Vector of StoreItems.
    */
   public Vector getItems() throws RemoteException;

   /**
    * Get all inventory items for the given category.
    *
    * @param Category of items desired.
    * @return Vector of StoreItems.
    */
   public Vector getItemsByCategory(int category) throws RemoteException;

   /**
    * Get inventory items that contain a given String within their names.
    *
    * @param name String to search names for.
    * @return A Vector of StoreItems that match.
    */
   public Vector getItemsLikeName(String name) throws RemoteException;

   /**
    * Get the Inventory item for the given ID.
    *
    * @param inventoryID - ID of the Inventory item desired.
    * @return StoreItem
    */
   public StoreItem getItem(String inventoryID) throws RemoteException;

   /**
    * Add an inventory item.
    *
    * @param item The StoreItem to add.
    * @return True, if item added.
    */
   public boolean addItem(StoreItem item) throws RemoteException;

   /**
    * Delete an inventory item.
    *
    * @param inventoryID The ID of the inventory item to delete.
    * @return True, if item deleted.
    */
   public boolean deleteItem(String inventoryID) throws RemoteException;

   /**
    * Set the inventory item's name.
    *
    * @param inventoryID The inventory item's ID.
    * @param desc The inventory item's new name.
    */
   public void setItemName(String inventoryID, String name) throws RemoteException;
   /**
    * Set the inventory item's heading.
    *
    * @param inventoryID The inventory item's ID.
    * @param desc The inventory item's new heading.
    */
   public void setItemHeading(String inventoryID, String heading) throws RemoteException;
   /**
    * Set the inventory item's description.
    *
    * @param inventoryID The inventory item's ID.
    * @param desc The inventory item's new description.
    */
   public void setItemDescription(String inventoryID, String desc) throws RemoteException;
   /**
    * Set the inventory item's package information.
    *
    * @param inventoryID The inventory item's ID.
    * @param pkginfo The inventory item's new package information.
    */
   public void setItemPkginfo(String inventoryID, String pkginfo) throws RemoteException;

   /**
    * Set the inventory item's category.
    *
    * @param inventoryID The inventory item's ID.
    * @param category The inventory item's new category.
    */
   public void setItemCategory(String inventoryID, int category) throws RemoteException;
 
   /**
    * Set the inventory item's image file name.
    *
    * @param inventoryID The inventory item's ID.
    * @param imageName The inventory item's new image file name.
    */
   public void setItemImageFileName(String inventoryID, String imageName) throws RemoteException;

   /** 
    * Get the image for the inventory item.
    * @param inventoryID The id of the inventory item wanted.
    * @return Buffer containing the image.
    */
   public byte[] getItemImageBytes(String inventoryID) throws RemoteException;

   /** 
    * Set the image for the inventory item. 
    * @param inventoryID The id of the inventory item wanted.
    * @param imgbytes Buffer containing the image.
    */
   public void setItemImageBytes(String inventoryID, byte[] imgbytes) throws RemoteException;

   /**
    * Set the inventory item's price.
    *
    * @param inventoryID The inventory item's ID.
    * @param price The inventory item's new price.
    */
   public void setItemPrice(String inventoryID, float price) throws RemoteException;

   /**
    * Set the inventory item's cost.
    *
    * @param inventoryID The inventory item's ID.
    * @param cost The inventory item's new cost.
    */
   public void setItemCost(String inventoryID, float cost) throws RemoteException;

   /**
    * Set the inventory item's quantity.
    *
    * @param inventoryID The inventory item's ID.
    * @param quantity The inventory item's new quantity.
    */
   public void setItemQuantity(String inventoryID, int amount) throws RemoteException;

   /**
    * Set the inventory item's notes.
    *
    * @param inventoryID The inventory item's ID.
    * @param notes The inventory item's new notes.
    */
   public void setItemNotes(String inventoryID, String note) throws RemoteException;

   /**
    * Set the inventory item's access availability.
    *
    * @param inventoryID The inventory item's ID.
    * @param isPublic True, if this item can be viewed by the public.
    */
   public void setItemPrivacy(String inventoryID, boolean isPublic) throws RemoteException;

}


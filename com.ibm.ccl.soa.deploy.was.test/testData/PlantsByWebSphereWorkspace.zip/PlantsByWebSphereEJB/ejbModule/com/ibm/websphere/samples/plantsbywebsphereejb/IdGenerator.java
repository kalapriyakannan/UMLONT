package com.ibm.websphere.samples.plantsbywebsphereejb;
/**
 * Local interface for Enterprise Bean: IdGenerator
 */
public interface IdGenerator extends javax.ejb.EJBLocalObject 
{
   /**
    * Get accessor for persistent attribute: idName
    */
   public String getIdName();
   /**
    * Set accessor for persistent attribute: idName
    */
   public void setIdName(String newIdName);

   /**
    * Get accessor for persistent attribute: idValue
    */
   public int getIdValue();
   /**
    * Set accessor for persistent attribute: idValue
    */
   public void setIdValue(int newIdValue);

   public int nextId();

}

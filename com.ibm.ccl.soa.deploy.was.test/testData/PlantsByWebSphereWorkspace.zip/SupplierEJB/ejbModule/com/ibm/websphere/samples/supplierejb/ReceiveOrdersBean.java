//
// "This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
// instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
// or for redistribution by customer, as part of such an application, in customer's own products. " 
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2003,2003
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.supplierejb;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.ibm.websphere.samples.supplierejb.Util;

/**
 * Bean implementation class for Enterprise Bean: ReceiveOrders
 */
public class ReceiveOrdersBean implements javax.ejb.SessionBean
{
   private javax.ejb.SessionContext mySessionCtx;

   private QueueConnectionFactory qConnFactory = null;
   private Queue queue = null;
   private InitialContext context;

   /**
    * Method queueOrderInternal.
    * @param customerID
    * @param orderID
    * @param inventoryID
    * @param quantity
    * @throws JMSException
    */
   private void queueOrderInternal(String customerID, String orderID, String inventoryID, int quantity) throws javax.jms.JMSException
   {
      Util.debug("ReceiveOrdersBean.queueOrderInternal() - customer ID ->" + customerID);

      QueueConnection qConn = null;
      QueueSession qSess = null;
      try
      {
         context = new InitialContext();
         qConnFactory = (QueueConnectionFactory) context.lookup("java:comp/env/jms/QueueConnectionFactory");
         queue = (Queue) context.lookup("java:comp/env/jms/PurchaseOrdersQueue");
         qConn = qConnFactory.createQueueConnection();
         qSess = qConn.createQueueSession(true, Session.AUTO_ACKNOWLEDGE);
         QueueSender qSender = qSess.createSender(queue);
         TextMessage msg = qSess.createTextMessage();

         /* Generate an orderID for the received new order. */
         msg.setStringProperty("command", "neworder");
         msg.setStringProperty("customerID", customerID);
         msg.setStringProperty("orderID", orderID);
         msg.setStringProperty("inventoryID", inventoryID);
         msg.setIntProperty("quantity", quantity);

         Util.debug("ReceiveOrdersBean.queueOrderInternal() - Sending message: " + msg.getText());
         qSender.send(msg);
         qSender.close();
      }
      catch (javax.jms.JMSException e)
      {
         Util.debug("ReceiveOrdersBean.queueOrderInternal() - JMSException - " + e);
         throw e; // pass the exception back
      }
      catch (javax.naming.NamingException e)
      {
         Util.debug("ReceiveOrdersBean.queueOrderInternal() - NamingException - " + e);
      }
      finally
      {
         if (qSess != null)
            qSess.close();
         if (qConn != null)
            qConn.close();
      }
   }

   /**
    * Method sendOrder.
    * @param customerID
    * @param orderID
    * @param inventoryID
    * @param quantity
    */
   public void sendOrder(String customerID, String orderID, String inventoryID, int quantity)
   {
      try
      {
         Util.debug("ReceiveOrdersBean.sendOrder() - Sending message");
         queueOrderInternal(customerID, orderID, inventoryID, quantity);
      }
      catch (JMSException e)
      {
      }
   }

   /**
    * Method sendOrder
    * @param customerID
    * @param orderID
    * @param inventoryID
    * @param quantity
    */
   public void sendOrder(String customerID, String orderID, String inventoryID, Integer quantity)
   {
      sendOrder(customerID, orderID, inventoryID, quantity.intValue());
   }
   /**
    * Method checkInventory.
    */
   public void checkInventory()
   {
   }
   /**
    * Method processOrder.
    * @param customerID
    * @param orderID
    * @param inventoryID
    * @param quantity
    */
   public void processOrder(String customerID, String orderID, String inventoryID, int quantity)
   {
      sendConfirmation(customerID, orderID, inventoryID, quantity);
   }
   /**
    * Method sendConfirmation.
    * @param customerID
    * @param orderID
    * @param inventoryID
    * @param quantity
    */
   public void sendConfirmation(String customerID, String orderID, String inventoryID, int quantity)
   {
      Util.debug("ReceiveOrdersBean.sendConfirmation()");

      try
      {
         SupplierProxy supplierProxy = new SupplierProxy();
         supplierProxy.receiveConfirmation(orderID);
      }
      catch (Exception e)
      {
         Util.debug("ReceiveOrdersBean.sendConfirmation() - Exception: " + e);
      }
   }

   /**
    * Method getSessionContext.
    * @return SessionContext
    */
   /**
    * getSessionContext
    */
   public javax.ejb.SessionContext getSessionContext()
   {
      return mySessionCtx;
   }
   /**
    * @see javax.ejb.SessionBean#setSessionContext(SessionContext)
    */
   /**
    * setSessionContext
    */
   public void setSessionContext(javax.ejb.SessionContext ctx)
   {
      mySessionCtx = ctx;
   }
   /**
    * Method ejbCreate.
    * @throws CreateException
    */
   /**
    * ejbCreate
    */
   public void ejbCreate() throws javax.ejb.CreateException
   {
      // Uncomment the following to turn Debug ON
      // Util.setDebug(true);
   }
   /**
    * @see javax.ejb.SessionBean#ejbActivate()
    */
   /**
    * ejbActivate
    */
   public void ejbActivate()
   {
   }
   /**
    * @see javax.ejb.SessionBean#ejbPassivate()
    */
   /**
    * ejbPassivate
    */
   public void ejbPassivate()
   {
   }
   /**
    * @see javax.ejb.SessionBean#ejbRemove()
    */
   /**
    * ejbRemove
    */
   public void ejbRemove()
   {
   }
}

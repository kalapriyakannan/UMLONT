//
// "This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
// instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
// or for redistribution by customer, as part of such an application, in customer's own products. " 
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2003,2003
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.supplierejb;

import java.rmi.RemoteException;

/**
 * Remote interface for Enterprise Bean: ReceiveOrders
 */
public interface ReceiveOrders extends javax.ejb.EJBObject
{
   /**
    * Method sendOrder.
    * @param customerID
    * @param orderID
    * @param quantity
    * @throws RemoteException
    */
   public void sendOrder(String customerID, String orderID, String inventoryID, int quantity) throws RemoteException;
   /**
    * Method sendOrder.
    * @param customerID
    * @param orderID
    * @param quantity
    * @throws RemoteException
    */
   public void sendOrder(String customerID, String orderID, String inventoryID, Integer quantity) throws RemoteException;

   /**
    * Method checkInventory.
    * @throws RemoteException
    */
   public void checkInventory() throws RemoteException;
   /**
    * Method sendConfirmation.
    * @param customerID
    * @param orderID
    * @param inventoryID
    * @param quantity
    * @throws RemoteException
    */
   public void sendConfirmation(String customerID, String orderID, String inventoryID, int quantity) throws RemoteException;
}

//
// "This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
// instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
// or for redistribution by customer, as part of such an application, in customer's own products. " 
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2003,2003
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.supplierejb;

import java.util.Hashtable;
import java.util.Properties;

import javax.ejb.*;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;

/**
 *  Utility class.
 */
public class Util
{

   private static InitialContext initCtx = null;
   private static Hashtable homeTable = new Hashtable();
   private static Hashtable localhomeTable = new Hashtable();

   /**
    * Method getInitialContext - Return the cached Initial Context.
    * @return InitialContext
    */
   static public InitialContext getInitialContext()
   {
      try
      {
         // Get InitialContext if it has not been gotten yet.
         if (initCtx == null)
         {
            // properties are in the system properties
            initCtx = new InitialContext();
         }
      }
      // Naming Exception will cause a null return.
      catch (NamingException e)
      {
      }

      return initCtx;
   }

   /**
    * Method getEJBHome - Lookup and return an EJB home.
    *
    * @param jndiName jndi name of the EJB
    * @param homeClass EJB's home class
    * @return EJBHome EJB home instance, or null if a naming exception on lookup.
    */
   static public EJBHome getEJBHome(String jndiName, Class homeClass)
   {
      EJBHome home = (EJBHome) homeTable.get(jndiName);
      if (home == null)
      {
         try
         {
            InitialContext ic = getInitialContext();
            if (ic != null)
            {
               Object obj = ic.lookup(jndiName);
               if (obj != null)
               {
                  home = (EJBHome) PortableRemoteObject.narrow(obj, homeClass);
                  if (home != null)
                  {
                     homeTable.put(jndiName, home);
                  }
               }
            }
         }
         // Naming Exception will cause a null return.
         catch (NamingException e)
         {
            debug("Util.getEJBHome() - Naming Exception: " + e);
         }
      }
      return home;
   }
   /**
    * Method getEJBLocalHome.
    * @param jndiName
    * @param homeClass
    * @return EJBLocalHome
    */
   static public EJBLocalHome getEJBLocalHome(String jndiName, Class homeClass)
   {
      EJBLocalHome home = (EJBLocalHome) localhomeTable.get(jndiName);
      if (home == null)
      {
         try
         {
            InitialContext ic = getInitialContext();
            if (ic != null)
            {
               home = (EJBLocalHome) ic.lookup(jndiName);
               if (home != null)
               {
                  localhomeTable.put(jndiName, home);
               }
            }
         }
         // Naming Exception will cause a null return.
         catch (NamingException e)
         {
            debug("Util.getEJBLocalHome() - Naming Exception: " + e);
         }
      }
      return home;
   }
   static final public String Supplier_Properties_File = "supplier.properties";
   static public Properties Supplier_Properties = null;

   /**
    * Method readProperties.
    */
   public static void readProperties()
   {
      System.out.println("Util.readProperties(): Loading Supplier Properties");
      if (Supplier_Properties == null)
      {
         Properties prop = new Properties();
         try
         {
            prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream(Supplier_Properties_File));
         }
         catch (Exception e)
         {
            System.out.println("Util.readProperties(): Exception: " + e);
            e.printStackTrace(System.err);
         }
         Supplier_Properties = prop;
      }
   }

   /**
    * Method getProperty.
    * @param name
    * @return String
    */
   public static String getProperty(String name)
   {
      if (Supplier_Properties == null)
      {
         readProperties();
      }
      String value = Supplier_Properties.getProperty(name);
      if (value == null)
      {
         System.out.println("Util.getProperty() - name(" + name + ") not found in properties file");
         value = "";
      }
      return (value);
   }

   static private boolean debug = false;

   /**
    * Method setDebug - Set debug setting to on or off.
    * @param val True or false.
    */
   static final public void setDebug(boolean val)
   {
      debug = val;
   }

   /**
    * Method debugOn - Is debug turned on? 
    * @return boolean
    */
   static final public boolean debugOn()
   {
      return debug;
   }

   /** 
    * Method debug - Output RAS message.
    * @param msg Message to be output.
    */
   static final public void debug(String msg)
   {
      if (debug)
      {
         System.out.println(msg);
      }
   }
}

//
// "This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
// instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
// or for redistribution by customer, as part of such an application, in customer's own products. " 
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2003,2003
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.supplierejb;

import javax.jms.TextMessage;

/**
 * Bean implementation class for Enterprise Bean: PurchaseOrder
 */
public class PurchaseOrdersBean implements javax.ejb.MessageDrivenBean, javax.jms.MessageListener
{
   private javax.ejb.MessageDrivenContext fMessageDrivenCtx;
   /**
    * Method getMessageDrivenContext.
    * @return MessageDrivenContext
    */
   /**
    * getMessageDrivenContext
    */
   public javax.ejb.MessageDrivenContext getMessageDrivenContext()
   {
      return fMessageDrivenCtx;
   }
   /**
    * @see javax.ejb.MessageDrivenBean#setMessageDrivenContext(MessageDrivenContext)
    */
   /**
    * setMessageDrivenContext
    */
   public void setMessageDrivenContext(javax.ejb.MessageDrivenContext ctx)
   {
      fMessageDrivenCtx = ctx;
   }
   /**
    * Method ejbCreate.
    */
   /**
    * ejbCreate
    */
   public void ejbCreate()
   {
      // Uncomment the following to turn Debug ON
      // Util.setDebug(true);
      Util.debug("PurchaseOrder(ejbCreate): create");
   }
   /**
    * @see javax.jms.MessageListener#onMessage(Message)
    */
   /**
    * onMessage
    */
   public void onMessage(javax.jms.Message msg)
   {
      try
      {
         Util.debug("PurchaseOrder.onMessage() - received msg");
         if (msg instanceof TextMessage)
         {
            Util.debug("PurchaseOrder.onMessage() - received message -->" + ((TextMessage) msg).getText() + "command-->" + msg.getStringProperty("command") + "<--");

            if (msg.getJMSRedelivered())
            {
               Util.debug("PurchaseOrder(onMessage): The following JMS message was redelivered due to a rollback:\n" + ((TextMessage) msg).getText());
               //Order has been cancelled -- ignore returned messages 
               return;
            }
            String command = msg.getStringProperty("command");
            if (command == null)
            {
               Util.debug("PurchaseOrder.onMessage() - received message with null command. Message-->" + msg);
               return;
            }
            if (command.equalsIgnoreCase("neworder"))
            {
               Util.debug("PurchaseOrder.onMessage() - received message and processing. Message-->" + msg);
               /* Get the Customer ID, Order ID and complete the Order */
               String customerID = msg.getStringProperty("customerID");
               String orderID = msg.getStringProperty("orderID");
               String inventoryID = msg.getStringProperty("inventoryID");
               int quantity = msg.getIntProperty("quantity");

               Util.debug("PurchaseOrdersBean.onMessage() - invoking processOrder");
               ReceiveOrdersLocalHome receiveOrdersLocalHome =
                  (ReceiveOrdersLocalHome) Util.getEJBLocalHome("java:comp/env/ejb/ReceiveOrders", com.ibm.websphere.samples.supplierejb.ReceiveOrdersLocalHome.class);

               try
               {
                  ReceiveOrdersLocal receiveOrders = receiveOrdersLocalHome.create();
                  receiveOrders.processOrder(customerID, orderID, inventoryID, quantity);
                  receiveOrders.remove();
               }
               catch (Exception e)
               {
                  Util.debug("PurchaseOrder.onMessage() - Exception: " + e);
               }

            }
            else
            {
               Util.debug("PurchaseOrder.onMessage() - unknown message request command-->" + command + "<-- message=" + ((TextMessage) msg).getText());
            }
         }
         else
         {
            Util.debug("PurchaseOrder.onMessage() - Message of wrong type--> " + msg.getClass().getName());
         }
      }
      catch (Throwable t)
      {
         //JMS onMessage should handle all exceptions
         Util.debug("PurchaseOrder.onMessage() -  Error rolling back transaction" + t.toString());
         fMessageDrivenCtx.setRollbackOnly();
      }
   }
   /**
    * @see javax.ejb.MessageDrivenBean#ejbRemove()
    */
   /**
    * ejbRemove
    */
   public void ejbRemove()
   {
      Util.debug("PurchaseOrder.ejbRemove() - remove");
   }
}

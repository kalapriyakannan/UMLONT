//
// "This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
// instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
// or for redistribution by customer, as part of such an application, in customer's own products. " 
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2003,2003
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.supplierejb;

import java.net.*;
import java.util.*;
import org.w3c.dom.*;
import org.apache.soap.*;
import org.apache.soap.encoding.*;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.util.xml.*;
import org.apache.soap.messaging.*;
import org.apache.soap.transport.http.*;

public class SupplierProxy
{
   private Call call;
   private URL url = null;
   private java.lang.reflect.Method setTcpNoDelayMethod;

   /**
    * @see java.lang.Object#Object()
    */
   public SupplierProxy()
   {
      try
      {
         setTcpNoDelayMethod = SOAPHTTPConnection.class.getMethod("setTcpNoDelay", new Class[] { Boolean.class });
      }
      catch (Exception e)
      {
      }
      call = createCall();
   }

   /**
    * Method setEndPoint.
    * @param url
    */
   public synchronized void setEndPoint(URL url)
   {
      this.url = url;
   }

   /**
    * Method getEndPoint.
    * @return URL
    * @throws MalformedURLException
    */
   public synchronized URL getEndPoint() throws MalformedURLException
   {
      return getURL();
   }

   /**
    * Method getURL.
    * @return URL
    * @throws MalformedURLException
    */
   private URL getURL() throws MalformedURLException
   {

      if (url == null)
      {
         String stringURL = (String) Util.getProperty("customer.soapurl");
         Util.debug("SupplierProxy.getURL(): Soap URL read: " + stringURL);
         if ((stringURL == null) || (stringURL == ""))
         {
            // Default Soap URL
            stringURL = "http://localhost:9080/PlantsByWebSphere/servlet/rpcrouter";
         }
         url = new URL(stringURL);
      }
      return url;
   }

   /**
    * Method receiveConfirmation.
    * @param orderID
    * @throws Exception
    */
   public synchronized void receiveConfirmation(java.lang.String orderID) throws Exception
   {
      String targetObjectURI = "urn:BackOrderStock";
      String SOAPActionURI = "";
      String customeruser = "samples";
      String customerpwd = "samples";

      if (getURL() == null)
      {
         throw new SOAPException(Constants.FAULT_CODE_CLIENT, "A URL must be specified via SupplierProxy.setEndPoint(URL).");
      }

      call.setMethodName("receiveConfirmation");
      call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
      call.setTargetObjectURI(targetObjectURI);
      Vector params = new Vector();
      Parameter backOrderIDParam = new Parameter("orderID", java.lang.String.class, orderID, Constants.NS_URI_SOAP_ENC);
      params.addElement(backOrderIDParam);
      call.setParams(params);

      SOAPHTTPConnection transport = new SOAPHTTPConnection();
      transport.setUserName(customeruser);
      transport.setPassword(customerpwd);
      call.setSOAPTransport(transport);

      try
      {
         Response resp = call.invoke(getURL(), SOAPActionURI);

         // Check the response.
         if (resp.generatedFault())
         {
            Fault fault = resp.getFault();
            call.setFullTargetObjectURI(targetObjectURI);
            throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
         }
      }
      catch (SOAPException e)
      {
         Util.debug("SupplierProxy.receiveConfirmation(): Caught SOAPException (" + e.getFaultCode() + "): " + e.getMessage());
      }
      catch (Exception e)
      {
         Util.debug("SupplierProxy.receiveConfirmation(): Caught Exception (" + e + ")");
      }
      
      return;

   }

   /**
    * Method createCall.
    * @return Call
    */
   protected Call createCall()
   {
      SOAPHTTPConnection soapHTTPConnection = new SOAPHTTPConnection();
      if (setTcpNoDelayMethod != null)
      {
         try
         {
            setTcpNoDelayMethod.invoke(soapHTTPConnection, new Object[] { Boolean.TRUE });
         }
         catch (Exception ex)
         {
         }
      }
      Call call = new Call();
      call.setSOAPTransport(soapHTTPConnection);
      SOAPMappingRegistry smr = call.getSOAPMappingRegistry();
      return call;
   }
}

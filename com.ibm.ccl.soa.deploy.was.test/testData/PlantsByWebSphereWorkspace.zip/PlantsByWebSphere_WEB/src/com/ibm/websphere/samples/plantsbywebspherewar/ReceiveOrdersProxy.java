//
//"This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
//instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
//or for redistribution by customer, as part of such an application, in customer's own products. " 
//
//Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2003,2003
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebspherewar;

import java.net.*;
import java.util.*;
import org.w3c.dom.*;
import org.apache.soap.*;
import org.apache.soap.encoding.*;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.util.xml.*;
import org.apache.soap.messaging.*;
import org.apache.soap.transport.http.*;

import com.ibm.websphere.samples.plantsbywebsphereejb.Util;

public class ReceiveOrdersProxy
{
   private Call call;
   private URL url = null;
   private java.lang.reflect.Method setTcpNoDelayMethod;

   /**
    * @see java.lang.Object#Object()
    */
   public ReceiveOrdersProxy()
   {
      try
      {
         setTcpNoDelayMethod = SOAPHTTPConnection.class.getMethod("setTcpNoDelay", new Class[] { Boolean.class });
      }
      catch (Exception e)
      {
      }
      call = createCall();
   }

   /**
    * Method setEndPoint.
    * @param url
    */
   public synchronized void setEndPoint(URL url)
   {
      this.url = url;
   }

   /**
    * Method getEndPoint.
    * @return URL
    * @throws MalformedURLException
    */
   public synchronized URL getEndPoint() throws MalformedURLException
   {
      return getURL();
   }

   /**
    * Method getURL.
    * @return URL
    * @throws MalformedURLException
    */
   private URL getURL() throws MalformedURLException
   {
      if (url == null)
      {
         String stringURL = (String) Util.getProperty("supplier.soapurl");
         Util.debug("ReceiveOrdersProxy.getURL(): Soap URL read: " + stringURL);
         if ((stringURL == null) || (stringURL == ""))
         {
            stringURL = "http://localhost:9080/Supplier/servlet/rpcrouter";
         }
         url = new URL(stringURL);
      }
      return url;
   }

   /**
    * Method sendOrder.
    * @param customerID
    * @param backOrderID
    * @param inventoryID
    * @param quantity
    * @throws Exception
    */
   public synchronized void sendOrder(java.lang.String customerID, java.lang.String backOrderID, java.lang.String inventoryID, int quantity) throws Exception
   {
      String targetObjectURI = "urn:ReceiveOrders";
      String SOAPActionURI = "";
      String supplieruser = "samples";
      String supplierpwd = "samples";

      if (getURL() == null)
      {
         throw new SOAPException(Constants.FAULT_CODE_CLIENT, "A URL must be specified via ReceiveOrdersProxy.setEndPoint(URL).");
      }

      call.setMethodName("sendOrder");
      call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
      call.setTargetObjectURI(targetObjectURI);
      Vector params = new Vector();
      Parameter customerIDParam = new Parameter("customerID", java.lang.String.class, customerID, Constants.NS_URI_SOAP_ENC);
      params.addElement(customerIDParam);
      Parameter backOrderIDParam = new Parameter("backOrderID", java.lang.String.class, backOrderID, Constants.NS_URI_SOAP_ENC);
      params.addElement(backOrderIDParam);
      Parameter inventoryIDParam = new Parameter("inventoryID", java.lang.String.class, inventoryID, Constants.NS_URI_SOAP_ENC);
      params.addElement(inventoryIDParam);
      Parameter quantityParam = new Parameter("quantity", int.class, new Integer(quantity), Constants.NS_URI_SOAP_ENC);
      params.addElement(quantityParam);
      call.setParams(params);
      SOAPHTTPConnection transport = new SOAPHTTPConnection();
      transport.setUserName(supplieruser);
      transport.setPassword(supplierpwd);
      call.setSOAPTransport(transport);

      try
      {
         Response resp = call.invoke(getURL(), SOAPActionURI);

         // Check the response.
         if (resp.generatedFault())
         {
            Fault fault = resp.getFault();
            call.setFullTargetObjectURI(targetObjectURI);
            throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
         }
      }
      catch (SOAPException e)
      {
         Util.debug("ReceiveOrdersProxy.sendOrder(): Caught SOAPException (" + e.getFaultCode() + "): " + e.getMessage());
      }
      catch (Exception e)
      {
         Util.debug("ReceiveOrdersProxy.sendOrder(): Caught Exception (" + e + ")");
      }

      return;
   }

   /**
    * Method createCall.
    * @return Call
    */
   protected Call createCall()
   {
      SOAPHTTPConnection soapHTTPConnection = new SOAPHTTPConnection();
      if (setTcpNoDelayMethod != null)
      {
         try
         {
            setTcpNoDelayMethod.invoke(soapHTTPConnection, new Object[] { Boolean.TRUE });
         }
         catch (Exception ex)
         {
         }
      }
      Call call = new Call();
      call.setSOAPTransport(soapHTTPConnection);
      SOAPMappingRegistry smr = call.getSOAPMappingRegistry();
      return call;
   }
}

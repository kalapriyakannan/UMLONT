//
// "This program may be used, executed, copied, modified and distributed without royalty for the 
// purpose of developing, using, marketing, or distributing."
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001, 2002
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebspherewar;

import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.Vector;
import javax.ejb.*;
import javax.naming.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.sql.DataSource;
import com.ibm.websphere.samples.plantsbywebsphereejb.*;

/**
 * Servlet to handle shopping needs.
 */
public class ShoppingServlet extends HttpServlet 
{
   // Servlet action codes.
   public static final String ACTION_ADDTOCART        = "addtocart";
   public static final String ACTION_COMPLETECHECKOUT = "completecheckout";
   public static final String ACTION_GOTOCART         = "gotocart";
   public static final String ACTION_INITCHECKOUT     = "initcheckout";
   public static final String ACTION_ORDERINFODONE    = "orderinfodone";
   public static final String ACTION_PRODUCTDETAIL    = "productdetail";
   public static final String ACTION_SHOPPING         = "shopping";
   public static final String ACTION_UPDATEQUANTITY   = "updatequantity";

   private ShoppingCartHome shoppingCartHome;
   private CatalogHome catalogHome;

   /**
    * Servlet initialization.
    */
   public void init(ServletConfig config) throws ServletException
   {
      super.init(config);
      shoppingCartHome = (ShoppingCartHome) Util.getEJBHome("java:comp/env/ejb/ShoppingCart",
            com.ibm.websphere.samples.plantsbywebsphereejb.ShoppingCartHome.class);
      catalogHome = (CatalogHome) Util.getEJBHome("java:comp/env/ejb/Catalog",
            com.ibm.websphere.samples.plantsbywebsphereejb.CatalogHome.class);
   }

   /**
    * Process incoming HTTP GET requests
    *
    * @param request Object that encapsulates the request to the servlet
    * @param response Object that encapsulates the response from the servlet
    */
   public void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response)
           throws ServletException, IOException
   {
      performTask(request,response);
   }

   /**
    * Process incoming HTTP POST requests
    *
    * @param request Object that encapsulates the request to the servlet
    * @param response Object that encapsulates the response from the servlet
    */
   public void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response)
           throws ServletException, IOException
   {
      performTask(request,response);
   }	

  /**
    * Main service method for ShoppingServlet
    *
    * @param request Object that encapsulates the request to the servlet
    * @param response Object that encapsulates the response from the servlet
    */    	
   public void performTask(HttpServletRequest req, HttpServletResponse resp)
           throws ServletException, IOException 
   {
      String action = null;

      action = req.getParameter(Util.ATTR_ACTION);
      Util.debug("action=" + action);

      if (action.equals(ACTION_SHOPPING))
      {
         String category = (String) req.getParameter("category");
         HttpSession session = req.getSession(true);

         // Get session category if none on request, such as 
         // 'Continue Shopping' from the Shopping Cart jsp.
         if ((category == null) || (category.equals("null")))
         {
            category = (String) session.getAttribute(Util.ATTR_CATEGORY);
         }

         // If categoyr still null, default to first category.
         if ((category == null) || (category.equals("null")))
         {
            category = "0";
         }
         session.setAttribute(Util.ATTR_CATEGORY, category);

         // Get the shopping items from the catalog.
         try
         {
            Catalog catalog = catalogHome.create();
            Vector items = catalog.getItemsByCategory(Integer.parseInt(category));
            for (int i = 0; i < items.size(); )
            {
               if ( ((StoreItem)items.elementAt(i)).isPublic() )
                  i++;
               else
                  items.removeElementAt(i);
            }
            req.setAttribute(Util.ATTR_INVITEMS, items);
         }
         catch (javax.ejb.CreateException e) { }

         requestDispatch( getServletConfig().getServletContext(),
                          req, resp, Util.PAGE_SHOPPING);
      }
      else if (action.equals(ACTION_PRODUCTDETAIL))
      {
         String invID = (String) req.getParameter("itemID");
         try
         {
            Catalog catalog = catalogHome.create();
            req.setAttribute(Util.ATTR_INVITEM, catalog.getItem(invID));
         }
         catch (javax.ejb.CreateException e) { }

         requestDispatch( getServletConfig().getServletContext(),
                          req, resp, Util.PAGE_PRODUCT);
      }
      else if (action.equals(ACTION_GOTOCART))
      {
         HttpSession session = req.getSession(true);

         // Get shopping cart.
         ShoppingCart shoppingCart = (ShoppingCart) session.getAttribute(Util.ATTR_CART);
         if (shoppingCart != null)
         {
            // Make sure ShopingCart reference has not timed out.
            try
            {
               shoppingCart.getItems();
            }
            catch (javax.ejb.NoSuchObjectLocalException e)
            {
               Util.debug("gotocart: shopping cart ref must have timed out");
               ShoppingCartContents cartContents = 
                     (ShoppingCartContents) session.getAttribute(Util.ATTR_CART_CONTENTS);
               try
               {
                  shoppingCart = shoppingCartHome.create(cartContents);
                  session.setAttribute(Util.ATTR_CART, shoppingCart);
               }
               catch (CreateException ce) 
               { 
                  shoppingCart = null;
               }
            }
         }

         requestDispatch( getServletConfig().getServletContext(),
                          req, resp, Util.PAGE_CART);
      }
      else if (action.equals(ACTION_ADDTOCART))
      {
         ShoppingCart shoppingCart = null;
         try
         {    
            // Get shopping cart.
            HttpSession session = req.getSession(true);
            shoppingCart = (ShoppingCart) session.getAttribute(Util.ATTR_CART);
            if (shoppingCart == null)
            {
               Util.debug("shopping cart is NULL, must create it");
               shoppingCart = shoppingCartHome.create();
            }
            else 
            {
               // Make sure ShopingCart reference has not timed out.
               try
               {
                  Util.debug("shopping cart is not null, check items, size=" + shoppingCart.getItems().size());
                  shoppingCart.getItems();
               }
               catch (NoSuchObjectLocalException e)
               {
                  // ShoppingCart timed out, so create a new one.
                  Util.debug("addtocart: shopping cart ref must have timed out, create a new one");
                  ShoppingCartContents cartContents = 
                        (ShoppingCartContents) session.getAttribute(Util.ATTR_CART_CONTENTS);

                  if (cartContents != null)
                     shoppingCart = shoppingCartHome.create(cartContents);
                  else
                     shoppingCart = shoppingCartHome.create();
               }
            }

            // Add item to cart.
            if (shoppingCart != null)
            {
               String invID = req.getParameter("itemID");
               try
               {
                  Catalog catalog = catalogHome.create();
                  StoreItem si = catalog.getItem(invID);
                  si.setQuantity(Integer.parseInt(req.getParameter("qty").trim()));
                  shoppingCart.addItem(si);
               }
               catch (javax.ejb.CreateException e) { }
               session.setAttribute(Util.ATTR_CART, shoppingCart);
               session.setAttribute(Util.ATTR_CART_CONTENTS, shoppingCart.getCartContents());
            }

            requestDispatch( getServletConfig().getServletContext(),
                             req, resp, Util.PAGE_CART);
         }
         catch (javax.ejb.CreateException e)
         {
            e.printStackTrace();
            throw new ServletException(e.getMessage());
         }
      }
      else if (action.equals(ACTION_UPDATEQUANTITY))
      {
         try
         {    
            // Get shopping cart.
            HttpSession session = req.getSession(true);
            ShoppingCart shoppingCart = (ShoppingCart) session.getAttribute(Util.ATTR_CART);
            // Make sure ShopingCart reference has not timed out.
            try
            {
               shoppingCart.getItems();
            }
            catch (NoSuchObjectLocalException e)
            {
               // ShoppingCart timed out, so create a new one.
               Util.debug("updatequantity: shopping cart ref must have timed out, create a new one");
               ShoppingCartContents cartContents = 
                     (ShoppingCartContents) session.getAttribute(Util.ATTR_CART_CONTENTS);

               if (cartContents != null)
                  shoppingCart = shoppingCartHome.create(cartContents);
               else
                  shoppingCart = shoppingCartHome.create();
            }

            // Update item quantity in cart.
            if (shoppingCart != null)
            {
               int cnt = 0;
               Vector items = shoppingCart.getItems();
               StoreItem si;
               String parm, parmval;
               // Check all quantity values from cart form.
               for (int parmcnt = 0; ; parmcnt++)
               {
                  parm = "itemqty" + String.valueOf(parmcnt);
                  parmval = req.getParameter(parm);
                  // No more quantity fields, so break out.
                  if ((parmval == null) || parmval.equals("null"))
                  {
                     break;
                  }
                  else   // Check quantity value of cart item.
                  {
                     int quantity = Integer.parseInt(parmval);
                     // Quantity set to 0, so remove from cart.
                     if (quantity == 0)
                     {
                        items.removeElementAt(cnt);
                     }
                     else   // Change quantity of cart item.
                     {
                        si = (StoreItem) items.elementAt(cnt);
                        si.setQuantity(quantity);
                        items.setElementAt(si, cnt);
                        cnt++;
                     }
                  }
               }
               // Are items in cart? Yes, set the session attributes.
               if (items.size() > 0)
               {
                  shoppingCart.setItems(items);
                  session.setAttribute(Util.ATTR_CART, shoppingCart);
                  session.setAttribute(Util.ATTR_CART_CONTENTS, shoppingCart.getCartContents());
               }
               else  // No items in cart, so remove attributes from session.
               {
                  session.removeAttribute(Util.ATTR_CART);
                  session.removeAttribute(Util.ATTR_CART_CONTENTS);
               }
            }

            requestDispatch( getServletConfig().getServletContext(),
                             req, resp, Util.PAGE_CART);
         }
         catch (javax.ejb.CreateException e)
         {
            e.printStackTrace();
            throw new ServletException(e.getMessage());
         }
      }
      else if (action.equals(ACTION_INITCHECKOUT))
      {
         String url;
         HttpSession session = req.getSession(true);
         CustomerInfo customerInfo = (CustomerInfo) session.getAttribute(Util.ATTR_CUSTOMER);
         if (customerInfo == null)
         {
            req.setAttribute(Util.ATTR_RESULTS, "You must login or register before checking out.");
            session.setAttribute(Util.ATTR_CHECKOUT, new Boolean(true));
            url = Util.PAGE_LOGIN;
         }
         else
         {
            url = Util.PAGE_ORDERINFO;
         }
         requestDispatch( getServletConfig().getServletContext(),
                          req, resp, url);
      }
      else if (action.equals(ACTION_ORDERINFODONE))
      {
         Order order = null;
         OrderInfo orderinfo = null;
         ShoppingCart shoppingCart = null;
         HttpSession session = req.getSession(true);
         CustomerInfo customerInfo = (CustomerInfo) session.getAttribute(Util.ATTR_CUSTOMER);
         String customerID = customerInfo.getCustomerID();

         shoppingCart = (ShoppingCart) session.getAttribute(Util.ATTR_CART);
         // Make sure ShopingCart reference has not timed out.
         try
         {
            Util.debug("orderinfodone: ShoppingCart timeout? check getItems() method");
            shoppingCart.getItems();
         }
         catch (NoSuchObjectLocalException e)
         {
            // ShoppingCart timed out, so create a new one.
            Util.debug("orderinfodone: ShoppingCart ref must have timed out");
            ShoppingCartContents cartContents = 
                  (ShoppingCartContents) session.getAttribute(Util.ATTR_CART_CONTENTS);
            if (cartContents != null)
            {
               try
               {
                  shoppingCart = shoppingCartHome.create(cartContents);
               }
               catch (CreateException ce)
               {
                  shoppingCart = null;
                  ce.printStackTrace();
               }
            }
            else
            {
               Util.debug("NoSuchObjectLocal Exception!!!");
               Util.debug("Major Problem!!!");
               shoppingCart = null;
            }
         }
         Util.debug("orderinfodone: got cart?");

         if (shoppingCart != null)
         {
            Util.debug("orderinfodone: cart not NULL");
            String billName      = req.getParameter("bname");
            String billAddr1     = req.getParameter("baddr1");
            String billAddr2     = req.getParameter("baddr2");
            String billCity      = req.getParameter("bcity");
            String billState     = req.getParameter("bstate");
            String billZip       = req.getParameter("bzip");
            String billPhone     = req.getParameter("bphone");

            String shipName      = req.getParameter("sname");
            String shipAddr1     = req.getParameter("saddr1");
            String shipAddr2     = req.getParameter("saddr2");
            String shipCity      = req.getParameter("scity");
            String shipState     = req.getParameter("sstate");
            String shipZip       = req.getParameter("szip");
            String shipPhone     = req.getParameter("sphone");
                
            int shippingMethod = Integer.parseInt(req.getParameter("shippingMethod"));

            String creditCard    = req.getParameter("ccardname");
            String ccNum         = req.getParameter("ccardnum");
            String ccExpireMonth = req.getParameter("ccexpiresmonth");
            String ccExpireYear  = req.getParameter("ccexpiresyear");
            String cardHolder    = req.getParameter("ccholdername");

            orderinfo = shoppingCart.createOrder(customerID, billName, billAddr1,
                                             billAddr2, billCity, billState, billZip,
                                             billPhone, shipName, shipAddr1,
                                             shipAddr2, shipCity, shipState, shipZip,
                                             shipPhone, creditCard, ccNum, ccExpireMonth,
                                             ccExpireYear, cardHolder, shippingMethod,
                                             shoppingCart.getItems());
            Util.debug("orderinfodone: order created");
         }

         if (orderinfo != null)
         {
            req.setAttribute(Util.ATTR_ORDERINFO, orderinfo);
            req.setAttribute(Util.ATTR_CARTITEMS, shoppingCart.getItems());
            session.setAttribute(Util.ATTR_ORDERKEY, new OrderKey(orderinfo.getID()));

            requestDispatch( getServletConfig().getServletContext(),
                             req, resp, Util.PAGE_CHECKOUTFINAL);
         }
      }
      else if (action.equals(ACTION_COMPLETECHECKOUT))
      {
         ShoppingCart shoppingCart = null;
         HttpSession session = req.getSession(true);

         OrderKey key = (OrderKey) session.getAttribute(Util.ATTR_ORDERKEY);
         req.setAttribute(Util.ATTR_ORDERID, String.valueOf(key.orderID));

         String orderKey = String.valueOf(key.orderID); 
         CustomerInfo customerInfo = (CustomerInfo) session.getAttribute(Util.ATTR_CUSTOMER);

         // Check the available inventory and backorder if necessary.
         shoppingCart = (ShoppingCart) session.getAttribute(Util.ATTR_CART);
         // Make sure ShopingCart reference has not timed out.
         try
         {
            Util.debug("completecheckout: ShoppingCart timeout? check getItems() method");
            shoppingCart.getItems();
         }
         catch (NoSuchObjectLocalException e)
         {
            // ShoppingCart timed out, so create a new one.
            Util.debug("completecheckout: ShoppingCart ref must have timed out");
            ShoppingCartContents cartContents = 
                  (ShoppingCartContents) session.getAttribute(Util.ATTR_CART_CONTENTS);
            if (cartContents != null)
            {
               try
               {
                  shoppingCart = shoppingCartHome.create(cartContents);
               }
               catch (CreateException ce)
               {
                  shoppingCart = null;
                  ce.printStackTrace();
               }
            }
            else
            {
               Util.debug("NoSuchObjectLocal Exception!!!");
               Util.debug("Major Problem!!!");
               shoppingCart = null;
            }
         }
         if (shoppingCart != null)
         {
            shoppingCart.checkInventory(shoppingCart.getItems());
         }

         try
         {
             MailAction mAction = new MailAction();
             mAction.sendConfirmationMessage(customerInfo, orderKey);
         }
         catch (CreateException e) { e.printStackTrace(); }
         catch (FinderException e) { e.printStackTrace(); }

         // Remove items saved in HttpSession.
         session.removeAttribute(Util.ATTR_CART);
         session.removeAttribute(Util.ATTR_CART_CONTENTS);
         session.removeAttribute(Util.ATTR_CATEGORY);
         session.removeAttribute(Util.ATTR_ORDERKEY);
         session.removeAttribute(Util.ATTR_CHECKOUT);

         requestDispatch( getServletConfig().getServletContext(),
                          req, resp, Util.PAGE_ORDERDONE);
      }
   }

   /** 
    * Send redirect
    */
   private void sendRedirect(HttpServletResponse resp, String page)
           throws ServletException, IOException 
   {
      resp.sendRedirect(resp.encodeRedirectURL(page));
   }

   /** 
    * Request dispatch
    */

   private void requestDispatch(ServletContext      ctx, 
                                HttpServletRequest  req, 
                                HttpServletResponse resp, 
                                String              page) throws ServletException, IOException
   {
      resp.setContentType("text/html");
      ctx.getRequestDispatcher(page).forward(req, resp);
   }
}
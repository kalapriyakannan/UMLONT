//
//"This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
//instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
//or for redistribution by customer, as part of such an application, in customer's own products. " 
//
//Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2001,2002
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebspherewar;

import java.rmi.RemoteException;
import javax.ejb.*;
import com.ibm.websphere.samples.plantsbywebsphereejb.*;

/**
 * This class sends the email confirmation message. 
 */
public class MailAction implements java.io.Serializable 
{
   /** Public constructor */
    public MailAction( ) { }

   /**
    * Send the email order confirmation message. 
    *
    * @param customerInfo The customer information.
    * @param orderKey The order number.
    */
    public static final void sendConfirmationMessage(CustomerInfo customerInfo, String orderKey)
                             throws CreateException, FinderException
    {
       try 
       {
          EMailMessage eMessage = new EMailMessage(createSubjectLine(orderKey),
                         createMessage(orderKey),
                         customerInfo.getCustomerID());

          MailerHome mailerHome = (MailerHome) Util.getEJBHome("java:comp/env/ejb/Mailer",
                        com.ibm.websphere.samples.plantsbywebsphereejb.MailerHome.class);

          Mailer mailer = mailerHome.create();
          mailer.createAndSendMail(eMessage);
          mailer.remove();
       }
       catch (CreateException e) { e.printStackTrace(); }
       catch (RemoteException e) { e.printStackTrace(); }
       catch (RemoveException e) { e.printStackTrace(); }
       catch (MailerAppException e) { e.printStackTrace(); }
    }

   /**
    * Create the email message.
    *
    * @param customerDetails The customer information.
    * @param orderKey The order number.
    * @return The email message.
    */
    private static final String createMessage(String orderKey) 
    {
       StringBuffer msg = new StringBuffer();
       try
       {
          OrderHome orderHome = (OrderHome) Util.getEJBLocalHome("java:comp/env/ejb/Order",
                        com.ibm.websphere.samples.plantsbywebsphereejb.OrderHome.class);
          Order order = orderHome.findByPrimaryKey(new OrderKey(orderKey));
          msg.append("Thank you for your order " + orderKey + ".\n");
          msg.append("Your order will be shipped to: " + order.getShipName() + "\n");
          msg.append("                               " + order.getShipAddr1() + " " 
                                                       + order.getShipAddr2() + "\n");
          msg.append("                               " + order.getShipCity() + ", " 
                                                       + order.getShipState() + " "
                                                       + order.getShipZip() + "\n\n");
          msg.append("Please save it for your records.\n");
       }
       catch(FinderException e) { e.printStackTrace(); }

       return msg.toString();
    }

   /**
    * Create the Subject line.
    *
    * @param orderKey The order number.
    * @return The Order number string.
    */
    private static final String createSubjectLine(String orderKey) 
    {
       StringBuffer msg = new StringBuffer();
       msg.append("Your order number " + orderKey);

       return msg.toString();
    }

}

//
// "This sample program is provided AS IS and may be used, executed, copied and modified without royalty payment by customer (a) for its own 
// instruction and study, (b) in order to develop applications designed to run with an IBM WebSphere product, either for customer's own internal use 
// or for redistribution by customer, as part of such an application, in customer's own products. " 
//
// Product 5630-A36,  (C) COPYRIGHT International Business Machines Corp., 2003,2003
// All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.samples.plantsbywebspherewar;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import java.util.Vector;
import java.util.Iterator;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ibm.websphere.samples.plantsbywebsphereejb.BackOrderStock;
import com.ibm.websphere.samples.plantsbywebsphereejb.BackOrderStockHome;
import com.ibm.websphere.samples.plantsbywebsphereejb.BackOrderItem;
import com.ibm.websphere.samples.plantsbywebsphereejb.Util;

/**
 * Servlet to handle Administration actions
 */
public class AdminServlet extends HttpServlet
{

   private BackOrderStockHome backOrderStockHome = null;
   //private ReceiveOrdersHome receiveOrdersHome = null;

   // Servlet action codes.
   public static final String ACTION_ORDERSTOCK = "orderstock";
   public static final String ACTION_UPDATESTOCK = "updatestock";
   public static final String ACTION_GETBACKORDERS = "getbackorders";
   public static final String ACTION_UPDATEQUANTITY = "updatequantity";
   public static final String ACTION_CANCEL = "cancel";

   /**
    * @see javax.servlet.Servlet#init(ServletConfig)
    */
   /**
    * Servlet initialization.
    */
   public void init(ServletConfig config) throws ServletException
   {
      super.init(config);
      // Uncomment the following to generated debug code.
      // Util.setDebug(true);
      try
      {
         backOrderStockHome = (BackOrderStockHome) Util.getEJBHome("java:comp/env/ejb/BackOrderStock", com.ibm.websphere.samples.plantsbywebsphereejb.BackOrderStockHome.class);
      }
      catch (Exception e)
      {
         Util.debug("AdminServlet.init() -  Exception: " + e);
      }
   }
   /**
    * Process incoming HTTP GET requests
    *
    * @param request Object that encapsulates the request to the servlet
    * @param response Object that encapsulates the response from the servlet
    */
   public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
   {
      performTask(req, resp);
   }
   /**
    * Process incoming HTTP POST requests
    *
    * @param request Object that encapsulates the request to the servlet
    * @param response Object that encapsulates the response from the servlet
    */
   public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
   {
      performTask(req, resp);
   }

   /**
    * Method performTask.
    * @param req
    * @param resp
    * @throws ServletException
    * @throws IOException
    */
   public void performTask(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
   {
      String admintype = null;

      admintype = req.getParameter(Util.ATTR_ADMINTYPE);
      if ((admintype == null) || (admintype.equals("")))
      {
         // Invalid Admin
         requestDispatch(getServletConfig().getServletContext(), req, resp, Util.PAGE_ADMINHOME);
      }
      if (admintype.equals(Util.ADMIN_BACKORDER))
      {
         performBackOrder(req, resp);
      }
   }

   /**
    * Method performBackOrder.
    * @param req
    * @param resp
    * @throws ServletException
    * @throws IOException
    */
   public void performBackOrder(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
   {
      String action = null;
      action = req.getParameter(Util.ATTR_ACTION);
      if ((action == null) || (action.equals("")))
         action = ACTION_GETBACKORDERS;
      Util.debug("AdminServlet.performBackOrder() - action=" + action);
      HttpSession session = req.getSession(true);
      if (action.equals(ACTION_GETBACKORDERS))
      {
         getBackOrders(session);
         requestDispatch(getServletConfig().getServletContext(), req, resp, Util.PAGE_BACKADMIN);
      }
      else
         if (action.equals(ACTION_ORDERSTOCK))
         {
            String[] backOrderIDs = (String[]) req.getParameterValues("selectedObjectIds");
            if (backOrderIDs != null)
            {
               for (int i = 0; i < backOrderIDs.length; i++)
               {
                  String backOrderID = backOrderIDs[i];
                  Util.debug("AdminServlet.performBackOrder() - Selected BackOrder backOrderID: " + backOrderID);

                  try
                  {
                     BackOrderStock backOrderStock = backOrderStockHome.create();
                     String inventoryID = backOrderStock.getBackOrderInventoryID(backOrderID);
                     Util.debug("AdminServlet.performBackOrder() - backOrderID = " + inventoryID);
                     int quantity = backOrderStock.getBackOrderQuantity(backOrderID);
                     String inputQuantity = req.getParameter("itemqty" +backOrderID);
                     Util.debug("AdminServlet.performBackOrder() - itemqty"+backOrderID +" = " + inputQuantity);
                     if ((inputQuantity != null) && (!inputQuantity.equals("")))
                     {
                         if (!inputQuantity.equals(new String().valueOf(quantity)))
                         {
                            // Administrator has modified the quantity on the form for this Back Order
                            quantity = new Integer(inputQuantity).intValue();
                            backOrderStock.setBackOrderQuantity(backOrderID, quantity);

                         }
                     }                      
                     Util.debug("AdminServlet.performBackOrder() - quantity: " + quantity);
         
                     backOrderStock.orderStock(backOrderID, quantity);
                     backOrderStock.remove();

                     purchaseInventory(backOrderID, inventoryID, quantity);
                  }
                  catch (Exception e)
                  {
                     Util.debug("AdminServlet.performBackOrder() - Exception: " + e);
                  }
               }
            }
            getBackOrders(session);
            requestDispatch(getServletConfig().getServletContext(), req, resp, Util.PAGE_BACKADMIN);
         }
         else
            if (action.equals(ACTION_UPDATESTOCK))
            {
               Util.debug("AdminServlet.performBackOrder() - AdminServlet(performTask):  Update Stock Action");
               String[] backOrderIDs = (String[]) req.getParameterValues("selectedObjectIds");
               if (backOrderIDs != null)
               {
                  for (int i = 0; i < backOrderIDs.length; i++)
                  {
                     String backOrderID = backOrderIDs[i];
                     Util.debug("AdminServlet.performBackOrder() - Selected BackOrder backOrderID: " + backOrderID);
                     try
                     {
                        BackOrderStock backOrderStock = backOrderStockHome.create();
                        String inventoryID = backOrderStock.getBackOrderInventoryID(backOrderID);
                        Util.debug("AdminServlet.performBackOrder() - backOrderID = " + inventoryID);
                        int quantity = backOrderStock.getBackOrderQuantity(backOrderID);
                        Util.debug("AdminServlet.performBackOrder() - quantity: " + quantity);
                        backOrderStock.updateStock(backOrderID, quantity);
                        backOrderStock.remove();
                     }
                     catch (Exception e)
                     {
                        Util.debug("AdminServlet.performBackOrder() - Exception: " + e);
                     }
                  }
               }
               getBackOrders(session);
               requestDispatch(getServletConfig().getServletContext(), req, resp, Util.PAGE_BACKADMIN);
            }
            else
               if (action.equals(ACTION_CANCEL))
               {
                  Util.debug("AdminServlet.performBackOrder() - AdminServlet(performTask):  Cancel Action");
                  String[] backOrderIDs = (String[]) req.getParameterValues("selectedObjectIds");
                  if (backOrderIDs != null)
                  {
                     for (int i = 0; i < backOrderIDs.length; i++)
                     {
                        String backOrderID = backOrderIDs[i];
                        Util.debug("AdminServlet.performBackOrder() - Selected BackOrder backOrderID: " + backOrderID);
                        try
                        {
                           BackOrderStock backOrderStock = backOrderStockHome.create();
                           backOrderStock.deleteBackOrder(backOrderID);
                           backOrderStock.remove();
                        }
                        catch (Exception e)
                        {
                           Util.debug("AdminServlet.performBackOrder() - Exception: " + e);
                        }
                     }
                  }
                  getBackOrders(session);
                  requestDispatch(getServletConfig().getServletContext(), req, resp, Util.PAGE_BACKADMIN);
               }
               else
                  if (action.equals(ACTION_UPDATEQUANTITY))
                  {
                     Util.debug("AdminServlet.performBackOrder() -  Update Quantity Action");
                     try
                     {
                        BackOrderStock backOrderStock = backOrderStockHome.create();
                        String backOrderID = req.getParameter("backOrderID");
                        if (backOrderID != null)
                        {
                           Util.debug("AdminServlet.performBackOrder() - backOrderID = " + backOrderID);
                           String paramquantity = req.getParameter("itemqty");
                           if (paramquantity != null)
                           {
                              int quantity = new Integer(paramquantity).intValue();
                              Util.debug("AdminServlet.performBackOrder() - quantity: " + quantity);

                              backOrderStock.setBackOrderQuantity(backOrderID, quantity);
                              backOrderStock.remove();
                           }
                        }
                     }
                     catch (Exception e)
                     {
                        Util.debug("AdminServlet.performBackOrder() - Exception: " + e);
                     }

                     getBackOrders(session);
                     requestDispatch(getServletConfig().getServletContext(), req, resp, Util.PAGE_BACKADMIN);
                  }
                  else
                  {
                     // Unknown Backup Admin Action so go back to the Administration home page
                     requestDispatch(getServletConfig().getServletContext(), req, resp, "/PlantsByWebSphere/" + Util.PAGE_ADMINHOME);
                  }
   }

   /**
    * Method getBackOrders.
    * @param session
    */
   public void getBackOrders(HttpSession session)
   {
      try
      {
         // Get the list of back order items.
         Util.debug("AdminServlet.getBackOrders() - Looking for BackOrders");
         BackOrderStock backOrderStock = backOrderStockHome.create();
         Vector backOrderItems = backOrderStock.findBackOrderItems();
         if (backOrderItems != null)
         {
            Util.debug("AdminServlet.getBackOrders() - BackOrders found!");
            Iterator i = backOrderItems.iterator();
            while (i.hasNext())
            {
               BackOrderItem backOrderItem = (BackOrderItem) i.next();
               String backOrderID = backOrderItem.getBackOrderID();
               String invID = backOrderItem.getInventoryID();
               String name = backOrderItem.getName();
               int quantity = backOrderItem.getQuantity();
               String status = backOrderItem.getStatus();
               String lowDate = new Long(backOrderItem.getLowDate()).toString();
               String orderDate = new Long(backOrderItem.getOrderDate()).toString();
               Util.debug("AdminServlet.getBackOrders() - backOrderID = " + backOrderID);
               Util.debug("AdminServlet.getBackOrders() -    invID = " + invID);
               Util.debug("AdminServlet.getBackOrders() -    name = " + name);
               Util.debug("AdminServlet.getBackOrders() -    quantity = " + quantity);
               Util.debug("AdminServlet.getBackOrders() -    status = " + status);
               Util.debug("AdminServlet.getBackOrders() -    lowDate = " + lowDate);
               Util.debug("AdminServlet.getBackOrders() -    orderDate = " + orderDate);
            }
         }
         else
         {
            Util.debug("AdminServlet.getBackOrders() - NO BackOrders found!");
         }
         session.setAttribute("backorderitems", backOrderItems);
      }
      catch (Exception e)
      {
         Util.debug("AdminServlet.getBackOrders() - Exception: " + e);
      }
   }

   /**
    * Method purchaseInventory.
    * @param invID
    * @param amountToOrder
    */
   private void purchaseInventory(String backOrderID, String invID, int amountToOrder)
   {
      String customerID = "PBW0001";
      try
      {
         ReceiveOrdersProxy receiveOrdersProxy = new ReceiveOrdersProxy();
         receiveOrdersProxy.sendOrder(customerID, backOrderID, invID, amountToOrder);
      }
      catch (Exception e)
      {
         Util.debug("AdminServlet.purchaseInventory() - Exception: " + e);
      }
   }

   /**
    * Method sendRedirect.
    * @param resp
    * @param page
    * @throws ServletException
    * @throws IOException
    */
   /** 
    * Send redirect
    */
   private void sendRedirect(HttpServletResponse resp, String page) throws ServletException, IOException
   {
      resp.sendRedirect(resp.encodeRedirectURL(page));
   }

   /**
    * Method requestDispatch.
    * @param ctx
    * @param req
    * @param resp
    * @param page
    * @throws ServletException
    * @throws IOException
    */
   /** 
    * Request dispatch
    */

   private void requestDispatch(ServletContext ctx, HttpServletRequest req, HttpServletResponse resp, String page) throws ServletException, IOException
   {
      resp.setContentType("text/html");
      ctx.getRequestDispatcher(page).forward(req, resp);
   }
}
